// privacy_screen.dart - UPDATED WITH TWO MODES
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'info_collector/info_student.dart' as student_info;
import 'info_collector/info_teacher.dart' as teacher_info;

class PrivacyScreen extends StatefulWidget {
  final String userType;
  final bool isFromAuth; // true = requires acceptance, false = just viewing

  const PrivacyScreen({
    super.key,
    required this.userType,
    this.isFromAuth = true,
  });

  @override
  State<PrivacyScreen> createState() => _PrivacyScreenState();
}

class _PrivacyScreenState extends State<PrivacyScreen> {
  final ScrollController _scrollController = ScrollController();
  bool _isAccepting = false;

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _onAgree() {
    setState(() => _isAccepting = true);

    Future.delayed(const Duration(milliseconds: 300), () {
      if (!mounted) return;

      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (context) {
            if (widget.userType == 'student') {
              return student_info.InfoStudent() as Widget;
            } else {
              return teacher_info.InfoTeacher() as Widget;
            }
          },
        ),
        (route) => false,
      );
    });
  }

  void _onDecline() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text(
          'Exit App?',
          style: TextStyle(
            color: Color(0xFF8B4513),
            fontWeight: FontWeight.bold,
          ),
        ),
        content: const Text(
          'You must accept the Privacy Policy to use Ilmify. Would you like to exit?',
          style: TextStyle(fontSize: 15),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Go Back',
              style: TextStyle(color: Colors.grey.shade700),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              SystemNavigator.pop();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: const Text(
              'Exit App',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B4513),
        elevation: 0,
        automaticallyImplyLeading: !widget.isFromAuth,
        leading: widget.isFromAuth
            ? null
            : IconButton(
                icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              ),
        title: const Text(
          'Privacy Policy',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              controller: _scrollController,
              padding: const EdgeInsets.all(20.0),
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Center(
                      child: Icon(
                        Icons.privacy_tip_outlined,
                        size: 60,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 16),
                    
                    const Center(
                      child: Text(
                        'Privacy Policy for Ilmify',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF8B4513),
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(height: 6),
                    const Center(
                      child: Text(
                        'Effective Date: 12/30/2025',
                        style: TextStyle(
                          fontSize: 13,
                          color: Colors.grey,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    
                    _buildParagraph(
                      'Ilmify ("we", "our", "us") respects your privacy and is committed to protecting your personal information. This Privacy Policy explains how information is collected, used, stored, and shared when you use the Ilmify mobile application.',
                    ),
                    
                    _buildSection(
                      '1. About the App',
                      'Ilmify is a platform that connects:\n\n'
                      '• Students who are looking for home tuition\n'
                      '• Teachers who offer paid teaching services\n\n'
                      'The app allows students and teachers to find, contact, and meet each other for educational purposes.',
                    ),
                    
                    _buildSection(
                      '2. Information We Collect',
                      '',
                    ),
                    
                    _buildSubSection(
                      'A. Teacher Information (Required for Security)',
                      'To maintain safety, trust, and authenticity on the platform, teachers are required to provide:\n\n'
                      '• Full name\n'
                      '• CNIC number\n'
                      '• CNIC image\n'
                      '• Live photograph (identity verification)\n'
                      '• Basic contact and teaching-related information\n\n'
                      'This information is collected strictly for verification and security purposes.',
                    ),
                    
                    _buildSubSection(
                      'B. Student Information',
                      'Students may provide limited personal information such as:\n\n'
                      '• Name\n'
                      '• Contact details\n'
                      '• Location (optional, for better matching)',
                    ),
                    
                    _buildSection(
                      '3. How We Use Your Information',
                      'Collected information is used only to:\n\n'
                      '• Verify teacher identities\n'
                      '• Ensure platform safety and trust\n'
                      '• Enable matching between students and teachers\n'
                      '• Prevent fraud, impersonation, or misuse\n\n'
                      '👉 We do NOT:\n\n'
                      '• Sell personal data\n'
                      '• Use data for advertising\n'
                      '• Use data for analytics or research\n'
                      '• Share data for commercial purposes',
                    ),
                    
                    _buildSection(
                      '4. Data Sharing & Legal Disclosure',
                      'Ilmify does not access or use user data under normal circumstances.\n\n'
                      'User data may be shared only when legally required, including:\n\n'
                      '• Emergency situations\n'
                      '• Requests from legal or government authorities\n'
                      '• Compliance with applicable laws\n\n'
                      'This is done solely for user safety and legal compliance.',
                    ),
                    
                    _buildSection(
                      '5. Data Storage & Security',
                      'We apply reasonable security measures to protect personal data against:\n\n'
                      '• Unauthorized access\n'
                      '• Alteration or misuse\n'
                      '• Loss or disclosure\n\n'
                      'Sensitive identity data is handled carefully and accessed only when absolutely necessary.',
                    ),
                    
                    _buildSection(
                      '6. Camera & Media Access',
                      'Ilmify uses camera and media permissions only to:\n\n'
                      '• Capture live verification photos\n'
                      '• Upload CNIC images\n'
                      '• Upload profile images\n\n'
                      'These permissions are used only with user consent and for stated purposes.',
                    ),
                    
                    _buildSection(
                      '7. Children\'s Privacy',
                      'Ilmify is not intended for children under the age of 13. We do not knowingly collect personal data from children.',
                    ),
                    
                    _buildSection(
                      '8. User Rights & Control',
                      'Users may request:\n\n'
                      '• Account deletion\n'
                      '• Removal of personal data\n\n'
                      'Requests can be made through the app or via the contact information below.',
                    ),
                    
                    _buildSection(
                      '9. Changes to This Privacy Policy',
                      'This policy may be updated from time to time. Any changes will be posted on this page with an updated effective date.',
                    ),
                    
                    _buildSection(
                      '10. Contact Us',
                      'If you have any questions about this Privacy Policy, contact us at:\n\n'
                      '• App Name: Ilmify\n'
                      '• Developer: Flux-Spark\n'
                      '• Email: ilmify00@gmail.com',
                    ),
                    
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
          
          // Only show buttons if isFromAuth is true
          if (widget.isFromAuth)
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 10,
                    offset: const Offset(0, -2),
                  ),
                ],
              ),
              child: SafeArea(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: ElevatedButton(
                        onPressed: _isAccepting ? null : _onAgree,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF8B4513),
                          disabledBackgroundColor: Colors.grey.shade300,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                          elevation: 2,
                        ),
                        child: _isAccepting
                            ? const SizedBox(
                                height: 24,
                                width: 24,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2.5,
                                ),
                              )
                            : const Text(
                                'I Agree to Privacy Policy',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextButton(
                      onPressed: _isAccepting ? null : _onDecline,
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: Text(
                        'Decline',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey.shade600,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildParagraph(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 14.5,
          height: 1.5,
          color: Colors.black87,
        ),
      ),
    );
  }

  Widget _buildSection(String title, String content) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.bold,
              color: Color(0xFF8B4513),
            ),
          ),
          if (content.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(
              content,
              style: const TextStyle(
                fontSize: 14.5,
                height: 1.5,
                color: Colors.black87,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildSubSection(String title, String content) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14, left: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 15.5,
              fontWeight: FontWeight.w600,
              color: Color(0xFF8B4513),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            content,
            style: const TextStyle(
              fontSize: 14.5,
              height: 1.5,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }
}
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'dart:io';

// NotificationService
//
// OneSignal.initialize() lives ONLY in main.dart.
// This class only handles: linking user identity + saving token to DB.
//
// Usage:
//   • After login/signup:  await NotificationService.linkUser()
//   • On logout:           await NotificationService.unlinkUser()

class NotificationService {
  static final _dbRef = FirebaseDatabase.instance.ref();

  /// Links the currently signed-in Firebase user to OneSignal and saves
  /// the push token to the DB. Safe to call multiple times (idempotent).
  /// If no user is signed in, returns silently — no crash.
  static Future<void> linkUser() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return; // not logged in yet — called too early, ignore

      final emailKey =
          user.email!.replaceAll('.', '_').replaceAll('@', '_at_');

      final teacherSnap =
          await _dbRef.child('teachers').child(emailKey).get();
      final isTeacher = teacherSnap.exists;

      // Link Firebase UID as OneSignal external identity
      await OneSignal.login(user.uid);

      // Tag role for segmented dashboard pushes
      OneSignal.User.addTags({
        'role':     isTeacher ? 'teacher' : 'student',
        'emailKey': emailKey,
      });

      // Save token immediately if already available
      final currentId = OneSignal.User.pushSubscription.id;
      if (currentId != null) {
        await _writeToken(
          subscriptionId: currentId,
          uid:            user.uid,
          emailKey:       emailKey,
          isTeacher:      isTeacher,
        );
      }

      // Also listen for future token rotations
      OneSignal.User.pushSubscription.addObserver((state) {
        _writeToken(
          subscriptionId: state.current.id,
          uid:            user.uid,
          emailKey:       emailKey,
          isTeacher:      isTeacher,
        );
      });
    } catch (_) {
      // Silent — push is best-effort, app works without it
    }
  }

  static Future<void> _writeToken({
    required String? subscriptionId,
    required String  uid,
    required String  emailKey,
    required bool    isTeacher,
  }) async {
    if (subscriptionId == null) return;
    try {
      final data = {
        'oneSignalId':     subscriptionId,
        'firebaseUid':     uid,
        'platform':        Platform.isAndroid ? 'android' : 'ios',
        'lastTokenUpdate': DateTime.now().toIso8601String(),
      };
      if (isTeacher) {
        await _dbRef.child('teachers').child(emailKey).update(data);
      } else {
        await _dbRef.child('students').child(emailKey).update(data);
      }
    } catch (_) {}
  }

  /// Unlinks the user from OneSignal. Call on logout.
  static Future<void> unlinkUser() async {
    try {
      await OneSignal.logout();
    } catch (_) {}
  }

  /// Notification tap handler — register once in main.dart:
  /// OneSignal.Notifications.addClickListener(NotificationService.handleClick)
  static void handleClick(OSNotificationClickEvent event) {
    final data = event.notification.additionalData;
    if (data == null) return;
    switch (data['type'] as String?) {
      case 'new_student':       break; // navigate to students list
      case 'received_request':  break; // navigate to received requests
      case 'request_accepted':  break; // navigate to connections
      case 'request_rejected':  break; // navigate to requests
      case 'chat_message':      break; // navigate to chat: data['chatId']
    }
  }

  // ── Backward-compat instance stubs ────────────────────────────────────────
  // These let old call sites like NotificationService().initialize() still
  // compile without changes — they just forward to the static methods.
  Future<void> initialize()      async => linkUser();
  Future<void> startMonitoring() async => linkUser();
  Future<void> stopMonitoring()  async {}
  Future<void> logout()          async => unlinkUser();
}
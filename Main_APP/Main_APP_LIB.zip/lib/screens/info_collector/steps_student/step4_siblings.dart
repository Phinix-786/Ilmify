import 'package:flutter/material.dart';

class StudentStep4Siblings extends StatefulWidget {
  final Function(Map<String, dynamic>) onNext;
  final VoidCallback onBack;
  final Map<String, dynamic> initialData;

  const StudentStep4Siblings({
    super.key,
    required this.onNext,
    required this.onBack,
    required this.initialData,
  });

  @override
  State<StudentStep4Siblings> createState() => _StudentStep4SiblingsState();
}

class _StudentStep4SiblingsState extends State<StudentStep4Siblings> {
  bool? _siblingsWantToStudy; // Changed to nullable
  List<Map<String, dynamic>> _siblingsData = [];

  final List<String> _classes = [
    'Class 5', 'Class 6', 'Class 7', 'Class 8', 'Class 9', 'Class 10',
    'O-Levels (Year 1)', 'O-Levels (Year 2)', 'O-Levels (Year 3)',
    'Class 11', 'Class 12', 'A-Levels (Year 1)', 'A-Levels (Year 2)',
  ];

  final Map<String, List<String>> _classToSubjects = {
    'Class 5': ['Mathematics', 'English', 'Urdu', 'Science', 'Social Studies', 'Islamiyat'],
    'Class 6': ['Mathematics', 'English', 'Urdu', 'Science', 'Social Studies', 'Islamiyat'],
    'Class 7': ['Mathematics', 'English', 'Urdu', 'Science', 'Social Studies', 'Islamiyat'],
    'Class 8': ['Mathematics', 'English', 'Urdu', 'Science', 'Social Studies', 'Islamiyat', 'Computer Science'],
    'Class 9': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Urdu', 'Computer Science', 'Pakistan Studies', 'Islamiyat'],
    'Class 10': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Urdu', 'Computer Science', 'Pakistan Studies', 'Islamiyat'],
    'O-Levels (Year 1)': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Urdu', 'Computer Science', 'Pakistan Studies', 'Islamiyat', 'Economics', 'Accounting', 'Business Studies'],
    'O-Levels (Year 2)': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Urdu', 'Computer Science', 'Pakistan Studies', 'Islamiyat', 'Economics', 'Accounting', 'Business Studies'],
    'O-Levels (Year 3)': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Urdu', 'Computer Science', 'Pakistan Studies', 'Islamiyat', 'Economics', 'Accounting', 'Business Studies'],
    'Class 11': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Urdu', 'Computer Science', 'Pakistan Studies', 'Islamiyat', 'Economics', 'Statistics'],
    'Class 12': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Urdu', 'Computer Science', 'Pakistan Studies', 'Islamiyat', 'Economics', 'Statistics'],
    'A-Levels (Year 1)': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Computer Science', 'Economics', 'Accounting', 'Business Studies', 'Psychology', 'Sociology'],
    'A-Levels (Year 2)': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Computer Science', 'Economics', 'Accounting', 'Business Studies', 'Psychology', 'Sociology'],
  };

  @override
  void initState() {
    super.initState();
    // Only set from initialData if it exists, otherwise leave as null
    if (widget.initialData.containsKey('siblingsWantToStudy')) {
      _siblingsWantToStudy = widget.initialData['siblingsWantToStudy'];
    }
    _siblingsData = List<Map<String, dynamic>>.from(
        widget.initialData['siblingsData'] ?? []);
  }

  void _addSibling() {
    setState(() {
      _siblingsData.add({
        'name': '',
        'class': '',
        'subjects': <String>[],
      });
    });
  }

  void _removeSibling(int index) {
    setState(() {
      _siblingsData.removeAt(index);
    });
  }

  void _handleNext() {
    // Check if user has made a selection
    if (_siblingsWantToStudy == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select Yes or No'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    if (_siblingsWantToStudy == true) {
      if (_siblingsData.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Please add at least one sibling or select "No"'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: Colors.orange,
          ),
        );
        return;
      }

      for (var i = 0; i < _siblingsData.length; i++) {
        final sibling = _siblingsData[i];
        if (sibling['name'].toString().trim().isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Please enter name for Sibling ${i + 1}'),
              behavior: SnackBarBehavior.floating,
              backgroundColor: Colors.orange,
            ),
          );
          return;
        }
        if (sibling['class'].toString().isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Please select class for Sibling ${i + 1}'),
              behavior: SnackBarBehavior.floating,
              backgroundColor: Colors.orange,
            ),
          );
          return;
        }
        if ((sibling['subjects'] as List).isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Please select subjects for Sibling ${i + 1}'),
              behavior: SnackBarBehavior.floating,
              backgroundColor: Colors.orange,
            ),
          );
          return;
        }
      }
    }

    widget.onNext({
      'siblingsWantToStudy': _siblingsWantToStudy,
      'siblingsData': _siblingsData,
    });
  }

  void _showSubjectSelector(int index) {
    final siblingClass = _siblingsData[index]['class'] ?? '';
    if (siblingClass.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select class first'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    final availableSubjects = _classToSubjects[siblingClass] ?? [];
    final selectedSubjects =
        List<String>.from(_siblingsData[index]['subjects'] ?? []);

    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFFFFF8E7),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 50,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.brown.shade300,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'Select Subjects',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF8B4513),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Expanded(
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: availableSubjects.length,
                      itemBuilder: (context, subIndex) {
                        final subject = availableSubjects[subIndex];
                        final isSelected = selectedSubjects.contains(subject);

                        return CheckboxListTile(
                          title: Text(
                            subject,
                            style: TextStyle(color: Colors.brown.shade700),
                          ),
                          value: isSelected,
                          activeColor: const Color(0xFF8B4513),
                          checkColor: Colors.white,
                          onChanged: (bool? value) {
                            setModalState(() {
                              if (value == true) {
                                selectedSubjects.add(subject);
                              } else {
                                selectedSubjects.remove(subject);
                              }
                            });
                            setState(() {
                              _siblingsData[index]['subjects'] = selectedSubjects;
                            });
                          },
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF8B4513),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(
                        'Done (${selectedSubjects.length} selected)',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Container(
                constraints: const BoxConstraints(maxWidth: 500),
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.brown.shade300.withOpacity(0.3),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: const BoxDecoration(
                        color: Color(0xFFFFF8E7),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.people_outline,
                        size: 50,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Siblings Information',
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Do your siblings want to study too?',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.brown.shade600,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 28),
                    Row(
                      children: [
                        Expanded(
                          child: _buildChoiceButton(
                            label: 'Yes',
                            isSelected: _siblingsWantToStudy == true,
                            onTap: () => setState(() => _siblingsWantToStudy = true),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _buildChoiceButton(
                            label: 'No',
                            isSelected: _siblingsWantToStudy == false,
                            onTap: () => setState(() {
                              _siblingsWantToStudy = false;
                              _siblingsData.clear();
                            }),
                          ),
                        ),
                      ],
                    ),
                    if (_siblingsWantToStudy == true) ...[
                      const SizedBox(height: 24),
                      ..._siblingsData.asMap().entries.map((entry) {
                        final index = entry.key;
                        final sibling = entry.value;
                        return _buildSiblingCard(index, sibling);
                      }),
                      const SizedBox(height: 16),
                      OutlinedButton.icon(
                        onPressed: _addSibling,
                        icon: const Icon(Icons.add),
                        label: const Text('Add Another Sibling'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: const Color(0xFF8B4513),
                          side: const BorderSide(color: Color(0xFF8B4513), width: 2),
                          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 100),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, -2),
              ),
            ],
          ),
          child: SafeArea(
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: widget.onBack,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF8B4513),
                      side: const BorderSide(color: Color(0xFF8B4513), width: 2),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    child: const Text(
                      'Back',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: ElevatedButton(
                    onPressed: _handleNext,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF8B4513),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      elevation: 2,
                    ),
                    child: const Text(
                      'Continue',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildChoiceButton({
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF8B4513) : const Color(0xFFFFF8E7),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: const Color(0xFF8B4513),
            width: 2,
          ),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: isSelected ? Colors.white : const Color(0xFF8B4513),
          ),
        ),
      ),
    );
  }

  Widget _buildSiblingCard(int index, Map<String, dynamic> sibling) {
    final selectedSubjects = List<String>.from(sibling['subjects'] ?? []);

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF8E7),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.brown.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Sibling ${index + 1}',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF8B4513),
                ),
              ),
              const Spacer(),
              IconButton(
                onPressed: () => _removeSibling(index),
                icon: const Icon(Icons.delete_outline, color: Colors.red),
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextFormField(
            initialValue: sibling['name'],
            onChanged: (value) {
              setState(() {
                _siblingsData[index]['name'] = value;
              });
            },
            decoration: InputDecoration(
              labelText: 'Full Name',
              labelStyle: TextStyle(color: Colors.brown.shade600, fontSize: 13),
              filled: true,
              fillColor: Colors.white,
              contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color: Color(0xFF8B4513), width: 2),
              ),
            ),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: sibling['class'].isEmpty ? null : sibling['class'],
            decoration: InputDecoration(
              labelText: 'Class',
              labelStyle: TextStyle(color: Colors.brown.shade600, fontSize: 13),
              filled: true,
              fillColor: Colors.white,
              contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color: Color(0xFF8B4513), width: 2),
              ),
            ),
            items: _classes.map((cls) {
              return DropdownMenuItem(
                value: cls,
                child: Text(cls, style: const TextStyle(fontSize: 14)),
              );
            }).toList(),
            onChanged: (value) {
              setState(() {
                _siblingsData[index]['class'] = value!;
                _siblingsData[index]['subjects'] = [];
              });
            },
            isExpanded: true,
          ),
          const SizedBox(height: 12),
          InkWell(
            onTap: () => _showSubjectSelector(index),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      selectedSubjects.isEmpty
                          ? 'Select Subjects'
                          : '${selectedSubjects.length} subject(s) selected',
                      style: TextStyle(
                        fontSize: 14,
                        color: selectedSubjects.isEmpty
                            ? Colors.grey.shade600
                            : const Color(0xFF8B4513),
                      ),
                    ),
                  ),
                  const Icon(Icons.arrow_forward_ios, size: 14, color: Color(0xFF8B4513)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class StudentStep3Pricing extends StatefulWidget {
  final Function(Map<String, dynamic>) onNext;
  final VoidCallback onBack;
  final Map<String, dynamic> initialData;

  const StudentStep3Pricing({
    super.key,
    required this.onNext,
    required this.onBack,
    required this.initialData,
  });

  @override
  State<StudentStep3Pricing> createState() => _StudentStep3PricingState();
}

class _StudentStep3PricingState extends State<StudentStep3Pricing> {
  final _formKey = GlobalKey<FormState>();
  final _hourlyPayController = TextEditingController();
  final _hoursController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _hourlyPayController.text = widget.initialData['hourlyPay'] ?? '';
    _hoursController.text = widget.initialData['hoursPerDay'] ?? '';
  }

  @override
  void dispose() {
    _hourlyPayController.dispose();
    _hoursController.dispose();
    super.dispose();
  }

  void _handleNext() {
    if (!_formKey.currentState!.validate()) return;
    widget.onNext({
      'hourlyPay': _hourlyPayController.text.trim(),
      'hoursPerDay': _hoursController.text.trim(),
      'minutesPerDay': '0', // Default to 0 minutes
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Container(
                constraints: const BoxConstraints(maxWidth: 500),
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.brown.shade300.withOpacity(0.3),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: const BoxDecoration(
                          color: Color(0xFFFFF8E7),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.attach_money_outlined,
                          size: 50,
                          color: Color(0xFF8B4513),
                        ),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        'Pricing & Hours',
                        style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF8B4513),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Set your budget and study hours',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.brown.shade600,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 28),
                      TextFormField(
                        controller: _hourlyPayController,
                        keyboardType: TextInputType.number,
                        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                        style: const TextStyle(fontSize: 15),
                        decoration: InputDecoration(
                          labelText: 'Per Hour Pay (PKR/month)',
                          labelStyle: TextStyle(color: Colors.brown.shade600, fontSize: 14),
                          prefixIcon: Padding(
                            padding: const EdgeInsets.only(left: 16, right: 8),
                            child: Align(
                              alignment: Alignment.centerLeft,
                              widthFactor: 1.0,
                              child: Text(
                                'Rs',
                                style: TextStyle(
                                  color: Color(0xFF8B4513),
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          filled: true,
                          fillColor: const Color(0xFFFFF8E7),
                          contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: const BorderSide(color: Color(0xFF8B4513), width: 2),
                          ),
                          errorBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: const BorderSide(color: Colors.red, width: 2),
                          ),
                        ),
                        validator: (v) {
                          if (v!.isEmpty) return 'Required';
                          final pay = int.tryParse(v);
                          if (pay == null || pay <= 0) return 'Invalid amount';
                          return null;
                        },
                      ),
                      const SizedBox(height: 20),
                      Text(
                        'Daily Study Hours',
                        style: TextStyle(
                          fontSize: 15,
                          color: Colors.brown.shade800,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _hoursController,
                        keyboardType: TextInputType.number,
                        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                        style: const TextStyle(fontSize: 15),
                        decoration: InputDecoration(
                          labelText: 'Hours (0-8)',
                          labelStyle: TextStyle(color: Colors.brown.shade600, fontSize: 14),
                          prefixIcon: const Icon(Icons.access_time_outlined, color: Color(0xFF8B4513), size: 22),
                          filled: true,
                          fillColor: const Color(0xFFFFF8E7),
                          contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: const BorderSide(color: Color(0xFF8B4513), width: 2),
                          ),
                          errorBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: const BorderSide(color: Colors.red, width: 2),
                          ),
                        ),
                        validator: (v) {
                          if (v!.isEmpty) return 'Required';
                          final hrs = int.tryParse(v);
                          if (hrs == null || hrs < 0 || hrs > 8) return 'Enter hours between 0-8';
                          return null;
                        },
                      ),
                      const SizedBox(height: 20),
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFF8E7),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.brown.shade300),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.info_outline, color: Colors.brown.shade600, size: 20),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                'This will help teachers understand your budget and time availability',
                                style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.brown.shade700,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 100),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, -2),
              ),
            ],
          ),
          child: SafeArea(
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: widget.onBack,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF8B4513),
                      side: const BorderSide(color: Color(0xFF8B4513), width: 2),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    child: const Text(
                      'Back',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: ElevatedButton(
                    onPressed: _handleNext,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF8B4513),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      elevation: 2,
                    ),
                    child: const Text(
                      'Continue',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
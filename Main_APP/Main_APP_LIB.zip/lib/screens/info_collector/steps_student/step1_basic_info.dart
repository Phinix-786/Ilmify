import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class StudentStep1BasicInfo extends StatefulWidget {
  final Function(Map<String, dynamic>) onNext;
  final Map<String, dynamic> initialData;

  const StudentStep1BasicInfo({
    super.key,
    required this.onNext,
    required this.initialData,
  });

  @override
  State<StudentStep1BasicInfo> createState() => _StudentStep1BasicInfoState();
}

class _StudentStep1BasicInfoState extends State<StudentStep1BasicInfo> {
  final _formKey = GlobalKey<FormState>();
  final _fullNameController = TextEditingController();
  final _fatherNameController = TextEditingController();
  final _phoneController = TextEditingController();
  String _selectedCity = '';
  String _selectedClass = '';
  String _selectedSiblings = '';

  final List<String> _pakistanCities = [
    'Karachi', 'Lahore', 'Islamabad', 'Rawalpindi', 'Faisalabad', 'Multan',
    'Peshawar', 'Quetta', 'Sialkot', 'Gujranwala', 'Hyderabad', 'Bahawalpur',
    'Sargodha', 'Sukkur', 'Larkana', 'Mardan', 'Mingora', 'Abbottabad',
    'Sahiwal', 'Okara', 'Other',
  ];

  final List<String> _classes = [
    'Class 5', 'Class 6', 'Class 7', 'Class 8', 'Class 9', 'Class 10',
    'O-Levels (Year 1)', 'O-Levels (Year 2)', 'O-Levels (Year 3)',
    'Class 11', 'Class 12', 'A-Levels (Year 1)', 'A-Levels (Year 2)',
  ];

  final List<String> _siblingsOptions = [
    '0', '1', '2', '3', '4', '5', 'More than 5',
  ];

  @override
  void initState() {
    super.initState();
    _fullNameController.text = widget.initialData['fullName'] ?? '';
    _fatherNameController.text = widget.initialData['fatherName'] ?? '';
    _selectedCity = widget.initialData['city'] ?? '';
    _selectedClass = widget.initialData['class'] ?? '';
    _selectedSiblings = widget.initialData['siblings'] ?? '';
    
    // Parse phone number if exists
    final existingPhone = widget.initialData['phoneNumber'] ?? '';
    if (existingPhone.isNotEmpty && existingPhone.startsWith('+92')) {
      _phoneController.text = existingPhone.substring(3);
    }
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _fatherNameController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  void _handleNext() {
    if (!_formKey.currentState!.validate()) return;

    if (_selectedCity.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select your city'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    if (_selectedClass.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select your class'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    if (_selectedSiblings.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select number of siblings'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    final fullPhoneNumber = '+92${_phoneController.text.trim()}';

    widget.onNext({
      'fullName': _fullNameController.text.trim(),
      'fatherName': _fatherNameController.text.trim(),
      'phoneNumber': fullPhoneNumber,
      'city': _selectedCity,
      'class': _selectedClass,
      'siblings': _selectedSiblings,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Container(
                constraints: const BoxConstraints(maxWidth: 500),
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.brown.shade300.withOpacity(0.3),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: const BoxDecoration(
                          color: Color(0xFFFFF8E7),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.school_outlined,
                          size: 50,
                          color: Color(0xFF8B4513),
                        ),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        'Student Information',
                        style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF8B4513),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Let\'s start with your basic details',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.brown.shade600,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 28),
                      _buildTextField(
                        controller: _fullNameController,
                        label: 'Student Full Name',
                        icon: Icons.person_outline,
                        validator: (v) => v!.isEmpty ? 'Required' : null,
                      ),
                      const SizedBox(height: 16),
                      _buildTextField(
                        controller: _fatherNameController,
                        label: 'Father\'s Full Name',
                        icon: Icons.supervisor_account_outlined,
                        validator: (v) => v!.isEmpty ? 'Required' : null,
                      ),
                      const SizedBox(height: 16),
                      
                      // Phone Number Field with +92
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 16,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFF8E7),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  '🇵🇰',
                                  style: TextStyle(fontSize: 20),
                                ),
                                SizedBox(width: 4),
                                Text(
                                  '+92',
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                    color: Color(0xFF8B4513),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: TextFormField(
                              controller: _phoneController,
                              keyboardType: TextInputType.phone,
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly,
                                LengthLimitingTextInputFormatter(10),
                              ],
                              validator: (v) {
                                if (v!.isEmpty) return 'Required';
                                if (v.length < 10) return 'Enter valid number';
                                return null;
                              },
                              style: const TextStyle(fontSize: 15),
                              decoration: InputDecoration(
                                labelText: 'Mobile Number',
                                labelStyle: TextStyle(
                                  color: Colors.brown.shade600,
                                  fontSize: 14,
                                ),
                                prefixIcon: const Icon(
                                  Icons.phone_outlined,
                                  color: Color(0xFF8B4513),
                                  size: 22,
                                ),
                                filled: true,
                                fillColor: const Color(0xFFFFF8E7),
                                contentPadding: const EdgeInsets.symmetric(
                                  vertical: 16,
                                  horizontal: 16,
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                  borderSide: BorderSide.none,
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                  borderSide: const BorderSide(
                                    color: Color(0xFF8B4513),
                                    width: 2,
                                  ),
                                ),
                                errorBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                  borderSide: const BorderSide(
                                    color: Colors.red,
                                    width: 2,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      _buildDropdown(
                        value: _selectedClass.isEmpty ? null : _selectedClass,
                        label: 'Class',
                        icon: Icons.class_outlined,
                        items: _classes,
                        onChanged: (value) => setState(() => _selectedClass = value!),
                      ),
                      const SizedBox(height: 16),
                      _buildDropdown(
                        value: _selectedSiblings.isEmpty ? null : _selectedSiblings,
                        label: 'Number of Siblings',
                        icon: Icons.people_outline,
                        items: _siblingsOptions,
                        onChanged: (value) => setState(() => _selectedSiblings = value!),
                      ),
                      const SizedBox(height: 16),
                      _buildDropdown(
                        value: _selectedCity.isEmpty ? null : _selectedCity,
                        label: 'City',
                        icon: Icons.location_city_outlined,
                        items: _pakistanCities,
                        onChanged: (value) => setState(() => _selectedCity = value!),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 100),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, -2),
              ),
            ],
          ),
          child: SafeArea(
            child: SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _handleNext,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF8B4513),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  elevation: 2,
                ),
                child: const Text(
                  'Continue',
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      validator: validator,
      style: const TextStyle(fontSize: 15),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: Colors.brown.shade600, fontSize: 14),
        prefixIcon: Icon(icon, color: const Color(0xFF8B4513), size: 22),
        filled: true,
        fillColor: const Color(0xFFFFF8E7),
        contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFF8B4513), width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Colors.red, width: 2),
        ),
      ),
    );
  }

  Widget _buildDropdown({
    required String? value,
    required String label,
    required IconData icon,
    required List<String> items,
    required void Function(String?) onChanged,
  }) {
    return DropdownButtonFormField<String>(
      value: value,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: Colors.brown.shade600, fontSize: 14),
        prefixIcon: Icon(icon, color: const Color(0xFF8B4513), size: 22),
        filled: true,
        fillColor: const Color(0xFFFFF8E7),
        contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFF8B4513), width: 2),
        ),
      ),
      items: items.map((item) {
        return DropdownMenuItem(
          value: item,
          child: Text(item, style: const TextStyle(fontSize: 15)),
        );
      }).toList(),
      onChanged: onChanged,
      isExpanded: true,
      icon: const Icon(Icons.arrow_drop_down, size: 28, color: Color(0xFF8B4513)),
    );
  }
}
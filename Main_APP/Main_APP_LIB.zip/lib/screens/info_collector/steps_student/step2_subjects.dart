import 'package:flutter/material.dart';

class StudentStep2Subjects extends StatefulWidget {
  final Function(Map<String, dynamic>) onNext;
  final VoidCallback onBack;
  final Map<String, dynamic> initialData;

  const StudentStep2Subjects({
    super.key,
    required this.onNext,
    required this.onBack,
    required this.initialData,
  });

  @override
  State<StudentStep2Subjects> createState() => _StudentStep2SubjectsState();
}

class _StudentStep2SubjectsState extends State<StudentStep2Subjects> {
  late List<String> _selectedSubjects;
  late String _selectedClass;

  // Subjects based on class level
  final Map<String, List<String>> _classToSubjects = {
    'Class 5': ['Mathematics', 'English', 'Urdu', 'Science', 'Social Studies', 'Islamiyat'],
    'Class 6': ['Mathematics', 'English', 'Urdu', 'Science', 'Social Studies', 'Islamiyat'],
    'Class 7': ['Mathematics', 'English', 'Urdu', 'Science', 'Social Studies', 'Islamiyat'],
    'Class 8': ['Mathematics', 'English', 'Urdu', 'Science', 'Social Studies', 'Islamiyat', 'Computer Science'],
    'Class 9': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Urdu', 'Computer Science', 'Pakistan Studies', 'Islamiyat'],
    'Class 10': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Urdu', 'Computer Science', 'Pakistan Studies', 'Islamiyat'],
    'O-Levels (Year 1)': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Urdu', 'Computer Science', 'Pakistan Studies', 'Islamiyat', 'Economics', 'Accounting', 'Business Studies'],
    'O-Levels (Year 2)': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Urdu', 'Computer Science', 'Pakistan Studies', 'Islamiyat', 'Economics', 'Accounting', 'Business Studies'],
    'O-Levels (Year 3)': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Urdu', 'Computer Science', 'Pakistan Studies', 'Islamiyat', 'Economics', 'Accounting', 'Business Studies'],
    'Class 11': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Urdu', 'Computer Science', 'Pakistan Studies', 'Islamiyat', 'Economics', 'Statistics'],
    'Class 12': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Urdu', 'Computer Science', 'Pakistan Studies', 'Islamiyat', 'Economics', 'Statistics'],
    'A-Levels (Year 1)': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Computer Science', 'Economics', 'Accounting', 'Business Studies', 'Psychology', 'Sociology'],
    'A-Levels (Year 2)': ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Computer Science', 'Economics', 'Accounting', 'Business Studies', 'Psychology', 'Sociology'],
  };

  @override
  void initState() {
    super.initState();
    _selectedClass = widget.initialData['class'] ?? '';
    _selectedSubjects = List<String>.from(widget.initialData['subjects'] ?? []);
  }

  List<String> _getAvailableSubjects() {
    return _classToSubjects[_selectedClass] ?? [];
  }

  void _handleNext() {
    if (_selectedSubjects.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select at least one subject'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }
    widget.onNext({'subjects': _selectedSubjects});
  }

  @override
  Widget build(BuildContext context) {
    final availableSubjects = _getAvailableSubjects();

    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Container(
                constraints: const BoxConstraints(maxWidth: 500),
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.brown.shade300.withOpacity(0.3),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: const BoxDecoration(
                        color: Color(0xFFFFF8E7),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.menu_book_outlined,
                        size: 50,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Select Subjects',
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Choose the subjects you want to study',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.brown.shade600,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF8E7),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.brown.shade300),
                      ),
                      child: Text(
                        'Class: $_selectedClass',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: Colors.brown.shade700,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Container(
                      constraints: const BoxConstraints(maxHeight: 220),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF8E7),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: availableSubjects.isEmpty
                          ? const Padding(
                              padding: EdgeInsets.all(20),
                              child: Text(
                                'No subjects available for this class',
                                textAlign: TextAlign.center,
                                style: TextStyle(color: Colors.grey),
                              ),
                            )
                          : ListView.builder(
                              shrinkWrap: true,
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              itemCount: availableSubjects.length,
                              itemBuilder: (context, index) {
                                final subject = availableSubjects[index];
                                final isSelected = _selectedSubjects.contains(subject);

                                return CheckboxListTile(
                                  title: Text(
                                    subject,
                                    style: TextStyle(
                                      color: Colors.brown.shade800,
                                      fontSize: 15,
                                      fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                                    ),
                                  ),
                                  value: isSelected,
                                  activeColor: const Color(0xFF8B4513),
                                  checkColor: Colors.white,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  onChanged: (bool? value) {
                                    setState(() {
                                      if (value == true) {
                                        _selectedSubjects.add(subject);
                                      } else {
                                        _selectedSubjects.remove(subject);
                                      }
                                    });
                                  },
                                );
                              },
                            ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF8E7),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: const Color(0xFF8B4513), width: 1.5),
                      ),
                      child: Text(
                        '${_selectedSubjects.length} subject(s) selected',
                        style: const TextStyle(
                          fontSize: 14,
                          color: Color(0xFF8B4513),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 100),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, -2),
              ),
            ],
          ),
          child: SafeArea(
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: widget.onBack,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF8B4513),
                      side: const BorderSide(color: Color(0xFF8B4513), width: 2),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    child: const Text(
                      'Back',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: ElevatedButton(
                    onPressed: _handleNext,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF8B4513),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      elevation: 2,
                    ),
                    child: const Text(
                      'Continue',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
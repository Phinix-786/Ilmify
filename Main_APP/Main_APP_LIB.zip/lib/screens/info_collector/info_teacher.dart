import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'steps_teacher/step1_basic_info.dart';
import 'steps_teacher/step2_subjects.dart';
import 'steps_teacher/step3_degrees.dart';
import 'steps_teacher/step4_experience.dart';
import 'steps_teacher/step5_pricing.dart';
import 'steps_teacher/step6_location.dart';
import '../home/teacher/home_teacher.dart'; // ✅ Import the HomeTeacher screen

class InfoTeacher extends StatefulWidget {
  const InfoTeacher({super.key});

  @override
  State<InfoTeacher> createState() => _InfoTeacherState();
}

class _InfoTeacherState extends State<InfoTeacher> {
  int _currentStep = 0;
  final Map<String, dynamic> _formData = {};
  bool _isSubmitting = false;

  void _nextStep(Map<String, dynamic> data) {
    setState(() {
      _formData.addAll(data);
      _currentStep++;
    });
  }

  Future<void> _submitData(Map<String, dynamic> finalData) async {
    setState(() => _isSubmitting = true);

    try {
      _formData.addAll(finalData);
      
      // Get current user
      final user = FirebaseAuth.instance.currentUser;
      
      // Check if user is authenticated
      if (user == null) {
        throw Exception('No authenticated user found. Please log in again.');
      }

      final dbRef = FirebaseDatabase.instance.ref();
      final emailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');

      // Save teacher data to database
      await dbRef.child('teachers').child(emailKey).set({
        ..._formData,
        'email': user.email,
        'createdAt': DateTime.now().toIso8601String(),
        'isActive': true,
        'userType': 'teacher',
      });

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Profile created successfully!'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 2),
        ),
      );

      await Future.delayed(const Duration(milliseconds: 500));
      if (!mounted) return;
      
      // ✅ Navigate to HomeTeacher screen using MaterialPageRoute
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (context) => const HomeTeacher(),
        ),
        (route) => false, // This removes all previous routes from the stack
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 4),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    // Using teacher-specific steps with correct class names
    final steps = [
      Step1BasicInfo(
        onNext: _nextStep,
        initialData: _formData,
      ),
      Step2Subjects(
        onNext: _nextStep,
        onBack: () {}, // Disabled back
        initialData: _formData,
      ),
      Step3Degrees(
        onNext: _nextStep,
        onBack: () {}, // Disabled back
        initialData: _formData,
      ),
      Step4Experience(
        onNext: _nextStep,
        onBack: () {}, // Disabled back
        initialData: _formData,
      ),
      Step5Pricing(
        onNext: _nextStep,
        onBack: () {}, // Disabled back
        initialData: _formData,
      ),
      Step6Location(
        onSubmit: _submitData,
        onBack: () {}, // Disabled back
        initialData: _formData,
        isSubmitting: _isSubmitting,
      ),
    ];

    return PopScope(
      canPop: false, // Disable back button completely
      child: Scaffold(
        backgroundColor: const Color(0xFFFFF8E7),
        appBar: AppBar(
          backgroundColor: const Color(0xFF8B4513),
          automaticallyImplyLeading: false, // Remove back button
          title: Column(
            children: [
              const Text(
                'Teacher Profile Setup',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                  letterSpacing: 0.5,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Step ${_currentStep + 1} of ${steps.length}',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w400,
                  color: Colors.white.withValues(alpha: 0.9),
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
          elevation: 0,
          centerTitle: true,
          toolbarHeight: 80,
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(4),
            child: Container(
              height: 4,
              margin: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(2),
              ),
              child: FractionallySizedBox(
                alignment: Alignment.centerLeft,
                widthFactor: (_currentStep + 1) / steps.length,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white.withValues(alpha: 0.5),
                        blurRadius: 8,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        body: _isSubmitting
            ? const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(
                      color: Color(0xFF8B4513),
                      strokeWidth: 3,
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Creating your profile...',
                      style: TextStyle(
                        fontSize: 16,
                        color: Color(0xFF8B4513),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              )
            : steps[_currentStep],
      ),
    );
  }
}
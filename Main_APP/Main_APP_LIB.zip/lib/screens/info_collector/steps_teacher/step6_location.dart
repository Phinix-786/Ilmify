import 'package:flutter/material.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart';

class Step6Location extends StatefulWidget {
  final Function(Map<String, dynamic>) onSubmit;
  final VoidCallback? onBack;
  final Map<String, dynamic> initialData;
  final bool isSubmitting;

  const Step6Location({
    super.key,
    required this.onSubmit,
    this.onBack,
    required this.initialData,
    required this.isSubmitting,
  });

  @override
  State<Step6Location> createState() => _Step6LocationState();
}

class _Step6LocationState extends State<Step6Location> {
  GeoPoint? _selectedLocation;

  @override
  void initState() {
    super.initState();
    if (widget.initialData['latitude'] != null && widget.initialData['longitude'] != null) {
      _selectedLocation = GeoPoint(
        latitude: double.parse(widget.initialData['latitude']),
        longitude: double.parse(widget.initialData['longitude']),
      );
    }
  }

  Future<void> _selectLocationOnMap() async {
    final result = await Navigator.push<GeoPoint>(
      context,
      MaterialPageRoute(
        builder: (context) => const LocationPickerScreen(),
      ),
    );

    if (result != null) {
      setState(() => _selectedLocation = result);
    }
  }

  void _handleSubmit() {
    if (_selectedLocation == null) {
      _showErrorDialog(
        'Location Required',
        'Please select your location on the map to continue.',
      );
      return;
    }

    widget.onSubmit({
      'latitude': _selectedLocation!.latitude.toString(),
      'longitude': _selectedLocation!.longitude.toString(),
    });
  }

  void _showErrorDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            const Icon(Icons.error_outline, color: Colors.orange, size: 28),
            const SizedBox(width: 12),
            Text(
              title,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF8B4513),
              ),
            ),
          ],
        ),
        content: Text(
          message,
          style: TextStyle(
            fontSize: 15,
            color: Colors.brown.shade700,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'OK',
              style: TextStyle(
                color: Color(0xFF8B4513),
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Container(
                constraints: const BoxConstraints(maxWidth: 500),
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.brown.shade300.withOpacity(0.3),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: const BoxDecoration(
                        color: Color(0xFFFFF8E7),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.location_on_outlined,
                        size: 50,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Select Location',
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Choose your teaching location on the map',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.brown.shade600,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 28),
                    InkWell(
                      onTap: _selectLocationOnMap,
                      borderRadius: BorderRadius.circular(14),
                      child: Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFF8E7),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: _selectedLocation == null
                                ? Colors.brown.shade300
                                : Colors.green,
                            width: 2,
                          ),
                        ),
                        child: Column(
                          children: [
                            Icon(
                              _selectedLocation == null
                                  ? Icons.add_location_alt_outlined
                                  : Icons.check_circle_outline,
                              size: 64,
                              color: _selectedLocation == null
                                  ? const Color(0xFF8B4513)
                                  : Colors.green,
                            ),
                            const SizedBox(height: 12),
                            Text(
                              _selectedLocation == null
                                  ? 'Tap to Select Location'
                                  : 'Location Selected ✓',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: _selectedLocation == null
                                    ? const Color(0xFF8B4513)
                                    : Colors.green.shade700,
                              ),
                            ),
                            if (_selectedLocation != null) ...[
                              const SizedBox(height: 8),
                              Text(
                                'Lat: ${_selectedLocation!.latitude.toStringAsFixed(5)}',
                                style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.brown.shade600,
                                ),
                              ),
                              Text(
                                'Long: ${_selectedLocation!.longitude.toStringAsFixed(5)}',
                                style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.brown.shade600,
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF8E7),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.brown.shade300),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.info_outline, color: Colors.brown.shade600, size: 20),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              'This location will be visible to students looking for teachers nearby.',
                              style: TextStyle(
                                fontSize: 13,
                                color: Colors.brown.shade700,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 100),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, -2),
              ),
            ],
          ),
          child: SafeArea(
            child: SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: widget.isSubmitting ? null : _handleSubmit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF8B4513),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  elevation: 2,
                ),
                child: widget.isSubmitting
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2,
                        ),
                      )
                    : const Text(
                        'Complete Profile',
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// =============================================================================
// Location Picker Screen
// =============================================================================

class LocationPickerScreen extends StatefulWidget {
  const LocationPickerScreen({super.key});

  @override
  State<LocationPickerScreen> createState() => _LocationPickerScreenState();
}

class _LocationPickerScreenState extends State<LocationPickerScreen> {
  late MapController mapController;
  GeoPoint selectedLocation = GeoPoint(latitude: 33.5651, longitude: 73.0169);
  bool isMapReady = false;
  GeoPoint? currentMarker;
  bool hasSetLocation = false;

  @override
  void initState() {
    super.initState();
    mapController = MapController(
      initPosition: GeoPoint(latitude: 33.5651, longitude: 73.0169),
    );
  }

  @override
  void dispose() {
    mapController.dispose();
    super.dispose();
  }

  Future<void> _updateMarker(GeoPoint point) async {
    if (currentMarker != null) {
      try {
        await mapController.removeMarker(currentMarker!);
      } catch (e) {
        // Silently handle error
      }
    }

    setState(() {
      selectedLocation = point;
      currentMarker = point;
      hasSetLocation = true;
    });

    try {
      await mapController.addMarker(
        point,
        markerIcon: const MarkerIcon(
          icon: Icon(
            Icons.location_on,
            color: Colors.red,
            size: 80,
          ),
        ),
      );
    } catch (e) {
      // Silently handle error
    }
  }

  Future<void> _setCurrentLocation() async {
    try {
      final center = await mapController.centerMap;
      await _updateMarker(center);
    } catch (e) {
      _showErrorDialog(
        'Location Error',
        'Unable to set location. Please try again.',
      );
    }
  }

  void _confirmLocation() {
    if (!hasSetLocation) {
      _showErrorDialog(
        'No Location Set',
        'Please choose a location on the map before confirming.',
      );
      return;
    }
    Navigator.pop(context, selectedLocation);
  }

  void _showErrorDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            const Icon(Icons.error_outline, color: Colors.orange, size: 28),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF8B4513),
                ),
              ),
            ),
          ],
        ),
        content: Text(
          message,
          style: TextStyle(
            fontSize: 15,
            color: Colors.brown.shade700,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'OK',
              style: TextStyle(
                color: Color(0xFF8B4513),
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B4513),
        title: const Text(
          'Select Location',
          style: TextStyle(fontSize: 18, color: Colors.white),
        ),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Stack(
        children: [
          OSMFlutter(
            controller: mapController,
            osmOption: OSMOption(
              zoomOption: const ZoomOption(
                initZoom: 14,
                minZoomLevel: 3,
                maxZoomLevel: 19,
                stepZoom: 1.0,
              ),
              userTrackingOption: const UserTrackingOption(
                enableTracking: false,
                unFollowUser: true,
              ),
            ),
            onMapIsReady: (ready) async {
              if (ready) {
                setState(() => isMapReady = true);
              }
            },
            mapIsLoading: const Center(
              child: CircularProgressIndicator(color: Color(0xFF8B4513)),
            ),
          ),
          if (isMapReady)
            Center(
              child: IgnorePointer(
                child: Icon(
                  Icons.add,
                  size: 40,
                  color: Colors.red.withOpacity(0.7),
                ),
              ),
            ),
          Positioned(
            bottom: 16,
            left: 16,
            right: 16,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (hasSetLocation) ...[
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF8E7),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Column(
                            children: [
                              Text(
                                'Latitude',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.brown.shade600,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                selectedLocation.latitude.toStringAsFixed(5),
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFF8B4513),
                                ),
                              ),
                            ],
                          ),
                          Container(
                            width: 1,
                            height: 30,
                            color: Colors.brown.shade300,
                          ),
                          Column(
                            children: [
                              Text(
                                'Longitude',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.brown.shade600,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                selectedLocation.longitude.toStringAsFixed(5),
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFF8B4513),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: isMapReady ? _setCurrentLocation : null,
                          icon: const Icon(Icons.location_searching, size: 18),
                          label: const Text(
                            'Choose Location',
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: const Color(0xFF8B4513),
                            side: const BorderSide(color: Color(0xFF8B4513), width: 2),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: hasSetLocation ? _confirmLocation : null,
                          icon: const Icon(Icons.check_circle, size: 18),
                          label: const Text(
                            'Confirm',
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF8B4513),
                            foregroundColor: Colors.white,
                            disabledBackgroundColor: Colors.brown.shade200,
                            disabledForegroundColor: Colors.white60,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
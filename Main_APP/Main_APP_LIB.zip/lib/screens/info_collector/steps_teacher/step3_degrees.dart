import 'package:flutter/material.dart';

class Step3Degrees extends StatefulWidget {
  final Function(Map<String, dynamic>) onNext;
  final VoidCallback onBack;
  final Map<String, dynamic> initialData;

  const Step3Degrees({
    super.key,
    required this.onNext,
    required this.onBack,
    required this.initialData,
  });

  @override
  State<Step3Degrees> createState() => _Step3DegreesState();
}

class _Step3DegreesState extends State<Step3Degrees> {
  final Map<String, List<String>> _subjectToDegrees = {
    'Mathematics': ['B.Sc Mathematics', 'M.Sc Mathematics', 'BS Mathematics', 'M.Phil Mathematics', 'PhD Mathematics', 'B.Ed (Math)', 'M.Ed (Math)'],
    'Physics': ['B.Sc Physics', 'M.Sc Physics', 'BS Physics', 'M.Phil Physics', 'PhD Physics', 'B.Ed (Physics)', 'M.Ed (Physics)'],
    'Chemistry': ['B.Sc Chemistry', 'M.Sc Chemistry', 'BS Chemistry', 'M.Phil Chemistry', 'PhD Chemistry', 'B.Ed (Chemistry)', 'M.Ed (Chemistry)'],
    'Biology': ['B.Sc Biology', 'M.Sc Biology', 'BS Biology', 'BS Zoology', 'BS Botany', 'M.Phil Biology', 'PhD Biology', 'MBBS', 'BDS', 'Pharm-D', 'DVM'],
    'English': ['B.A English', 'M.A English', 'BS English', 'M.Phil English', 'PhD English', 'B.Ed (English)', 'M.Ed (English)'],
    'Urdu': ['B.A Urdu', 'M.A Urdu', 'BS Urdu', 'M.Phil Urdu', 'PhD Urdu', 'B.Ed (Urdu)', 'M.Ed (Urdu)'],
    'Computer Science': ['BS Computer Science', 'BSCS', 'BCS', 'MCS', 'MS Computer Science', 'MSCS', 'M.Phil CS', 'PhD CS', 'BS Software Engineering', 'BS IT'],
    'Islamiyat': ['B.A Islamiyat', 'M.A Islamiyat', 'BS Islamic Studies', 'M.Phil Islamiyat', 'PhD Islamiyat', 'Shahadatul Aalimiya', 'Dars-e-Nizami'],
    'Pakistan Studies': ['B.A Pakistan Studies', 'M.A Pakistan Studies', 'BS Political Science', 'M.Phil Pakistan Studies', 'PhD Pakistan Studies'],
    'Economics': ['B.A Economics', 'M.A Economics', 'BS Economics', 'M.Phil Economics', 'PhD Economics', 'MBA Finance'],
    'Accounting': ['B.Com', 'M.Com', 'BBA (Finance)', 'MBA (Finance)', 'CA (Chartered Accountant)', 'ACCA', 'CMA', 'ICMAP'],
    'Business Studies': ['BBA', 'MBA', 'B.Com', 'M.Com', 'BS Business Administration', 'MS Business Administration'],
    'Statistics': ['B.Sc Statistics', 'M.Sc Statistics', 'BS Statistics', 'M.Phil Statistics', 'PhD Statistics'],
    'History': ['B.A History', 'M.A History', 'BS History', 'M.Phil History', 'PhD History'],
    'Geography': ['B.A Geography', 'M.A Geography', 'BS Geography', 'M.Phil Geography', 'PhD Geography'],
  };

  final List<String> _generalDegrees = [
    'Matriculation (SSC)', 'Intermediate (HSSC)', 'FSc Pre-Engineering',
    'FSc Pre-Medical', 'ICS', 'FA', 'B.Ed', 'M.Ed', 'B.A', 'M.A',
  ];

  late List<String> _selectedDegrees;
  late List<String> _selectedSubjects;

  @override
  void initState() {
    super.initState();
    _selectedDegrees = List<String>.from(widget.initialData['degrees'] ?? []);
    _selectedSubjects = List<String>.from(widget.initialData['subjects'] ?? []);
  }

  List<String> _getAvailableDegrees() {
    if (_selectedSubjects.isEmpty) return _generalDegrees;

    Set<String> degrees = {};
    for (var subject in _selectedSubjects) {
      if (_subjectToDegrees.containsKey(subject)) {
        degrees.addAll(_subjectToDegrees[subject]!);
      }
    }
    degrees.addAll(_generalDegrees);
    return degrees.toList()..sort();
  }

  void _handleNext() {
    if (_selectedDegrees.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select at least one degree')),
      );
      return;
    }
    widget.onNext({'degrees': _selectedDegrees});
  }

  @override
  Widget build(BuildContext context) {
    final availableDegrees = _getAvailableDegrees();

    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Container(
                constraints: const BoxConstraints(maxWidth: 500),
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.brown.shade300.withOpacity(0.3),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: const BoxDecoration(
                        color: Color(0xFFFFF8E7),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.school_outlined,
                        size: 50,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Select Degrees',
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Choose your educational qualifications',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.brown.shade600,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    if (_selectedSubjects.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 12),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFFF8E7),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: Colors.brown.shade300),
                          ),
                          child: Text(
                            'Based on: ${_selectedSubjects.join(", ")}',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.brown.shade700,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                    const SizedBox(height: 24),
                    Container(
                      constraints: const BoxConstraints(maxHeight: 180),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF8E7),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: ListView.builder(
                        shrinkWrap: true,
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        itemCount: availableDegrees.length,
                        itemBuilder: (context, index) {
                          final degree = availableDegrees[index];
                          final isSelected = _selectedDegrees.contains(degree);

                          return CheckboxListTile(
                            title: Text(
                              degree,
                              style: TextStyle(
                                color: Colors.brown.shade800,
                                fontSize: 14,
                                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                              ),
                            ),
                            value: isSelected,
                            activeColor: const Color(0xFF8B4513),
                            checkColor: Colors.white,
                            dense: true,
                            onChanged: (bool? value) {
                              setState(() {
                                if (value == true) {
                                  _selectedDegrees.add(degree);
                                } else {
                                  _selectedDegrees.remove(degree);
                                }
                              });
                            },
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF8E7),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: const Color(0xFF8B4513), width: 1.5),
                      ),
                      child: Text(
                        '${_selectedDegrees.length} degree(s) selected',
                        style: const TextStyle(
                          fontSize: 14,
                          color: Color(0xFF8B4513),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 100),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, -2),
              ),
            ],
          ),
          child: SafeArea(
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: widget.onBack,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF8B4513),
                      side: const BorderSide(color: Color(0xFF8B4513), width: 2),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    child: const Text(
                      'Back',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: ElevatedButton(
                    onPressed: _handleNext,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF8B4513),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      elevation: 2,
                    ),
                    child: const Text(
                      'Continue',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
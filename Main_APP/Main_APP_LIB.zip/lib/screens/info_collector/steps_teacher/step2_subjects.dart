import 'package:flutter/material.dart';

class Step2Subjects extends StatefulWidget {
  final Function(Map<String, dynamic>) onNext;
  final VoidCallback? onBack; // Made nullable
  final Map<String, dynamic> initialData;

  const Step2Subjects({
    super.key,
    required this.onNext,
    this.onBack, // Now optional
    required this.initialData,
  });

  @override
  State<Step2Subjects> createState() => _Step2SubjectsState();
}

class _Step2SubjectsState extends State<Step2Subjects> {
  final List<String> _availableSubjects = [
    'Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Urdu',
    'Computer Science', 'Islamiyat', 'Pakistan Studies', 'Economics',
    'Accounting', 'Business Studies', 'Statistics', 'History', 'Geography',
  ];

  late List<String> _selectedSubjects;

  @override
  void initState() {
    super.initState();
    _selectedSubjects = List<String>.from(widget.initialData['subjects'] ?? []);
  }

  void _handleNext() {
    if (_selectedSubjects.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select at least one subject')),
      );
      return;
    }
    widget.onNext({'subjects': _selectedSubjects});
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Container(
                constraints: const BoxConstraints(maxWidth: 500),
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.brown.shade300.withOpacity(0.3),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: const BoxDecoration(
                        color: Color(0xFFFFF8E7),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.subject_outlined,
                        size: 50,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Select Subjects',
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Choose the subjects you want to teach',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.brown.shade600,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 28),
                    Container(
                      constraints: const BoxConstraints(maxHeight: 180),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF8E7),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: ListView.builder(
                        shrinkWrap: true,
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        itemCount: _availableSubjects.length,
                        itemBuilder: (context, index) {
                          final subject = _availableSubjects[index];
                          final isSelected = _selectedSubjects.contains(subject);

                          return CheckboxListTile(
                            title: Text(
                              subject,
                              style: TextStyle(
                                color: Colors.brown.shade800,
                                fontSize: 15,
                                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                              ),
                            ),
                            value: isSelected,
                            activeColor: const Color(0xFF8B4513),
                            checkColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            onChanged: (bool? value) {
                              setState(() {
                                if (value == true) {
                                  _selectedSubjects.add(subject);
                                } else {
                                  _selectedSubjects.remove(subject);
                                }
                              });
                            },
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF8E7),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: const Color(0xFF8B4513), width: 1.5),
                      ),
                      child: Text(
                        '${_selectedSubjects.length} subject(s) selected',
                        style: const TextStyle(
                          fontSize: 14,
                          color: Color(0xFF8B4513),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 100),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, -2),
              ),
            ],
          ),
          child: SafeArea(
            child: SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _handleNext,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF8B4513),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  elevation: 2,
                ),
                child: const Text(
                  'Continue',
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'steps_student/step1_basic_info.dart';
import 'steps_student/step2_subjects.dart';
import 'steps_student/step3_pricing.dart';
import 'steps_student/step4_siblings.dart';
import 'steps_student/step5_location.dart';
import '../home/student/home_student.dart'; // ✅ Import the HomeStudent screen

class InfoStudent extends StatefulWidget {
  const InfoStudent({super.key});

  @override
  State<InfoStudent> createState() => _InfoStudentState();
}

class _InfoStudentState extends State<InfoStudent> {
  int _currentStep = 0;
  final Map<String, dynamic> _formData = {};
  bool _isSubmitting = false;

  void _nextStep(Map<String, dynamic> data) {
    setState(() {
      _formData.addAll(data);
      _currentStep++;
    });
  }

  void _previousStep() {
    if (_currentStep > 0) {
      setState(() {
        _currentStep--;
      });
    }
  }

  Future<void> _submitData(Map<String, dynamic> finalData) async {
    setState(() => _isSubmitting = true);

    try {
      _formData.addAll(finalData);
      
      // Get current user
      final user = FirebaseAuth.instance.currentUser;
      
      // Check if user is authenticated
      if (user == null) {
        throw Exception('No authenticated user found. Please log in again.');
      }

      final dbRef = FirebaseDatabase.instance.ref();
      final emailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');

      // Save student data to database
      await dbRef.child('students').child(emailKey).set({
        ..._formData,
        'email': user.email,
        'createdAt': DateTime.now().toIso8601String(),
        'isActive': true,
        'userType': 'student',
      });

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Profile created successfully!'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 2),
        ),
      );

      await Future.delayed(const Duration(milliseconds: 500));
      if (!mounted) return;
      
      // ✅ Navigate to HomeStudent screen using MaterialPageRoute
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (context) => const HomeStudent(),
        ),
        (route) => false, // This removes all previous routes from the stack
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 4),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final steps = [
      StudentStep1BasicInfo(
        onNext: _nextStep,
        initialData: _formData,
      ),
      StudentStep2Subjects(
        onNext: _nextStep,
        onBack: _previousStep,
        initialData: _formData,
      ),
      StudentStep3Pricing(
        onNext: _nextStep,
        onBack: _previousStep,
        initialData: _formData,
      ),
      StudentStep4Siblings(
        onNext: _nextStep,
        onBack: _previousStep,
        initialData: _formData,
      ),
      StudentStep5Location(
        onSubmit: _submitData,
        onBack: _previousStep,
        initialData: _formData,
        isSubmitting: _isSubmitting,
      ),
    ];

    return WillPopScope(
      onWillPop: () async {
        if (_currentStep > 0) {
          _previousStep();
          return false;
        }
        return true;
      },
      child: Scaffold(
        backgroundColor: const Color(0xFFFFF8E7),
        appBar: AppBar(
          backgroundColor: const Color(0xFF8B4513),
          automaticallyImplyLeading: _currentStep == 0,
          leading: _currentStep > 0
              ? IconButton(
                  icon: const Icon(Icons.arrow_back, color: Colors.white),
                  onPressed: _previousStep,
                )
              : null,
          title: Column(
            children: [
              const Text(
                'Student Profile Setup',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                  letterSpacing: 0.5,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Step ${_currentStep + 1} of ${steps.length}',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w400,
                  color: Colors.white.withOpacity(0.9),
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
          elevation: 0,
          centerTitle: true,
          toolbarHeight: 80,
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(4),
            child: Container(
              height: 4,
              margin: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(2),
              ),
              child: FractionallySizedBox(
                alignment: Alignment.centerLeft,
                widthFactor: (_currentStep + 1) / steps.length,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white.withOpacity(0.5),
                        blurRadius: 8,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        body: _isSubmitting
            ? const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(
                      color: Color(0xFF8B4513),
                      strokeWidth: 3,
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Creating your profile...',
                      style: TextStyle(
                        fontSize: 16,
                        color: Color(0xFF8B4513),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              )
            : steps[_currentStep],
      ),
    );
  }
}
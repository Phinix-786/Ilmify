import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'teacher_request_student_info.dart';

class StudentsListTeacher extends StatefulWidget {
  const StudentsListTeacher({super.key});

  @override
  State<StudentsListTeacher> createState() => _StudentsListTeacherState();
}

class _StudentsListTeacherState extends State<StudentsListTeacher> {
  final _dbRef = FirebaseDatabase.instance.ref();
  String _teacherCity = '';
  String _teacherEmailKey = '';
  bool _isLoading = true;
  Set<String> _excludedStudentKeys = {};

  @override
  void initState() {
    super.initState();
    _loadTeacherData();
    _listenToAllRequests();
  }

  Future<void> _loadTeacherData() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      _teacherEmailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');
      
      final snapshot = await _dbRef.child('teachers').child(_teacherEmailKey).child('city').get();

      if (snapshot.exists) {
        setState(() {
          _teacherCity = snapshot.value.toString();
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  void _listenToAllRequests() {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final emailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');

    // Listen to all request types to exclude students
    // 1. Requests teacher has sent
    _dbRef.child('teacherSentRequests').child(emailKey).onValue.listen((event) {
      _updateExcludedStudents(event, 'sent');
    });

    // 2. Requests teacher has received
    _dbRef.child('teacherRequests').child(emailKey).onValue.listen((event) {
      _updateExcludedStudents(event, 'received');
    });
  }

  void _updateExcludedStudents(DatabaseEvent event, String type) {
    final Set<String> studentKeys = {};
    
    if (event.snapshot.value != null) {
      final data = Map<String, dynamic>.from(event.snapshot.value as Map);
      data.forEach((key, value) {
        final request = Map<String, dynamic>.from(value as Map);
        final studentEmailKey = request['studentEmailKey'] as String?;
        
        if (studentEmailKey != null) {
          // Exclude students with ANY status (pending, accepted, rejected)
          // This ensures no duplicate interactions
          studentKeys.add(studentEmailKey);
        }
      });
    }
    
    setState(() {
      if (type == 'sent') {
        _excludedStudentKeys.addAll(studentKeys);
      } else if (type == 'received') {
        _excludedStudentKeys.addAll(studentKeys);
      }
    });
  }

  Stream<List<Map<String, dynamic>>> _getStudentsStream() {
    return _dbRef.child('students').onValue.map((event) {
      final List<Map<String, dynamic>> students = [];
      
      if (event.snapshot.value != null) {
        final data = Map<String, dynamic>.from(event.snapshot.value as Map);
        
        data.forEach((key, value) {
          final studentData = Map<String, dynamic>.from(value as Map);
          final studentCity = studentData['city'] ?? '';
          
          // Filter conditions:
          // 1. Same city as teacher
          // 2. Not in excluded list (no existing requests of any kind)
          if (studentCity == _teacherCity && !_excludedStudentKeys.contains(key)) {
            students.add({
              'key': key,
              ...studentData,
            });
          }
        });
      }
      
      return students;
    });
  }

  String _maskPhoneNumber(String phone) {
    if (phone.length < 4) return phone;
    final start = phone.substring(0, 4); // +923
    final end = phone.substring(phone.length - 1);
    final masked = '*' * (phone.length - 5);
    return '$start$masked$end';
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        backgroundColor: Color(0xFFFFF8E7),
        body: Center(
          child: CircularProgressIndicator(
            color: Color(0xFF8B4513),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B4513),
        automaticallyImplyLeading: false,
        title: const Text(
          'Find Students',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        elevation: 0,
        centerTitle: true,
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: _getStudentsStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(
                color: Color(0xFF8B4513),
              ),
            );
          }

          if (snapshot.hasError) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(
                    Icons.error_outline,
                    size: 64,
                    color: Colors.red,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Error loading students',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.brown.shade600,
                    ),
                  ),
                ],
              ),
            );
          }

          final students = snapshot.data ?? [];

          if (students.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(40),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(32),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.brown.shade200.withOpacity(0.3),
                            blurRadius: 20,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.person_search_rounded,
                        size: 80,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 32),
                    const Text(
                      'No Students Available',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'There are no new students looking for teachers in $_teacherCity.\nCheck back later!',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.brown.shade600,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: students.length,
            itemBuilder: (context, index) {
              final student = students[index];
              final subjects = List<String>.from(student['subjects'] ?? []);
              final hasSiblings = student['siblingsWantToStudy'] == true;
              
              return Card(
                margin: const EdgeInsets.only(bottom: 16),
                elevation: 3,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => TeacherRequestStudentInfo(
                          studentData: student,
                          hasRequestSent: false,
                        ),
                      ),
                    );
                  },
                  borderRadius: BorderRadius.circular(16),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: const Color(0xFFFFF8E7),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Icon(
                                Icons.school_outlined,
                                color: Color(0xFF8B4513),
                                size: 28,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    student['fullName'] ?? 'Unknown',
                                    style: const TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFF8B4513),
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    student['class'] ?? '',
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.brown.shade600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            if (hasSiblings)
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 6,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.blue.shade50,
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: Colors.blue.shade200),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(
                                      Icons.people_outline,
                                      size: 16,
                                      color: Colors.blue.shade700,
                                    ),
                                    const SizedBox(width: 4),
                                    Text(
                                      'Siblings',
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.blue.shade700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFFF8E7),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Icon(
                                    Icons.menu_book_outlined,
                                    size: 18,
                                    color: Color(0xFF8B4513),
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    'Subjects (${subjects.length})',
                                    style: const TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                      color: Color(0xFF8B4513),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Wrap(
                                spacing: 6,
                                runSpacing: 6,
                                children: subjects.take(3).map((subject) {
                                  return Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 6,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(6),
                                      border: Border.all(
                                        color: Colors.brown.shade300,
                                      ),
                                    ),
                                    child: Text(
                                      subject,
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.brown.shade700,
                                      ),
                                    ),
                                  );
                                }).toList()
                                  ..addAll(subjects.length > 3
                                      ? [
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 10,
                                              vertical: 6,
                                            ),
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius: BorderRadius.circular(6),
                                              border: Border.all(
                                                color: Colors.brown.shade300,
                                              ),
                                            ),
                                            child: Text(
                                              '+${subjects.length - 3} more',
                                              style: TextStyle(
                                                fontSize: 12,
                                                fontWeight: FontWeight.w600,
                                                color: Colors.brown.shade700,
                                              ),
                                            ),
                                          ),
                                        ]
                                      : []),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: _buildInfoChip(
                                icon: Icons.attach_money,
                                label: '${student['hourlyPay'] ?? 'N/A'} PKR/hr',
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: _buildInfoChip(
                                icon: Icons.access_time_outlined,
                                label: '${student['hoursPerDay'] ?? '0'}h ${student['minutesPerDay'] ?? '0'}m',
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        _buildInfoChip(
                          icon: Icons.phone_outlined,
                          label: _maskPhoneNumber(student['phoneNumber'] ?? ''),
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => TeacherRequestStudentInfo(
                                    studentData: student,
                                    hasRequestSent: false,
                                  ),
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF8B4513),
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                            child: const Text(
                              'View Details',
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildInfoChip({required IconData icon, required String label}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.brown.shade300),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: const Color(0xFF8B4513)),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 12,
                color: Colors.brown.shade700,
                fontWeight: FontWeight.w500,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'student_chat_info.dart';

const _kOneSignalAppId      = 'your-onesignal-app-id'; // Dashboard → Settings → Keys & IDs
const _kOneSignalRestApiKey = 'YOUR_ONESIGNAL_REST_API_KEY';

class StudentTeacherChat extends StatefulWidget {
  final Map<String, dynamic> studentData;

  const StudentTeacherChat({
    super.key,
    required this.studentData,
  });

  @override
  State<StudentTeacherChat> createState() => _StudentTeacherChatState();
}

class _StudentTeacherChatState extends State<StudentTeacherChat> {
  final _dbRef = FirebaseDatabase.instance.ref();
  String _teacherEmailKey = '';
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _chatScrollController = ScrollController();
  String? _studentProfileImageUrl;

  @override
  void initState() {
    super.initState();
    _loadTeacherData();
    _loadStudentProfileImage();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _chatScrollController.dispose();
    super.dispose();
  }

  Future<void> _loadTeacherData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final emailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');
      try {
        final snapshot = await _dbRef.child('teachers').child(emailKey).get();
        if (snapshot.exists) setState(() => _teacherEmailKey = emailKey);
      } catch (e) {
        setState(() => _teacherEmailKey = emailKey);
      }
    }
  }

  Future<void> _loadStudentProfileImage() async {
    try {
      final studentEmailKey = widget.studentData['studentEmailKey'];
      final snapshot = await _dbRef
          .child('students')
          .child(studentEmailKey)
          .child('profileImageUrl')
          .get();
      if (snapshot.exists && mounted) {
        setState(() => _studentProfileImageUrl = snapshot.value?.toString());
      }
    } catch (_) {}
  }

  Stream<List<Map<String, dynamic>>> _getChatMessagesStream(String studentEmailKey) {
    if (_teacherEmailKey.isEmpty || studentEmailKey.isEmpty) return Stream.value([]);

    final chatId = _generateChatId(_teacherEmailKey, studentEmailKey);

    return _dbRef
        .child('chats')
        .child(chatId)
        .child('messages')
        .onValue
        .map((event) {
      final List<Map<String, dynamic>> messages = [];
      if (event.snapshot.value != null) {
        final data = Map<String, dynamic>.from(event.snapshot.value as Map);
        data.forEach((key, value) {
          messages.add({'messageId': key, ...Map<String, dynamic>.from(value as Map)});
        });
        messages.sort((a, b) => (a['timestamp'] ?? 0).compareTo(b['timestamp'] ?? 0));
      }
      return messages;
    }).asBroadcastStream();
  }

  String _generateChatId(String teacherKey, String studentKey) {
    final keys = [teacherKey, studentKey]..sort();
    return '${keys[0]}_${keys[1]}';
  }

  // ── Push notification helper ───────────────────────────────────────────────
  Future<void> _sendPush({
    required String recipientOneSignalId,
    required String title,
    required String body,
  }) async {
    try {
      await http.post(
        Uri.parse('https://onesignal.com/api/v1/notifications'),
        headers: {
          'Content-Type':  'application/json',
          'Authorization': 'Basic $_kOneSignalRestApiKey',
        },
        body: jsonEncode({
          'app_id':                   _kOneSignalAppId,
          'include_subscription_ids': [recipientOneSignalId],
          'headings':                 {'en': title},
          'contents':                 {'en': body},
          'data':                     {'type': 'chat_message'},
        }),
      );
    } catch (_) {
      // Non-fatal — message was already saved
    }
  }
  // ──────────────────────────────────────────────────────────────────────────

  Future<void> _sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;

    try {
      final chatId = _generateChatId(
        _teacherEmailKey,
        widget.studentData['studentEmailKey'],
      );

      final messageRef = _dbRef.child('chats').child(chatId).child('messages').push();

      await messageRef.set({
        'text':           text,
        'senderType':     'teacher',
        'senderEmailKey': _teacherEmailKey,
        'timestamp':      DateTime.now().millisecondsSinceEpoch,
        'read':           false,
      });

      await _dbRef.child('chats').child(chatId).update({
        'teacherEmailKey':   _teacherEmailKey,
        'studentEmailKey':   widget.studentData['studentEmailKey'],
        'lastMessage':       text,
        'lastMessageTime':   DateTime.now().millisecondsSinceEpoch,
        'lastMessageSender': 'teacher',
      });

      _messageController.clear();

      // ── Notify the student ──────────────────────────────────────────────
      final studentEmailKey = widget.studentData['studentEmailKey'] as String;
      final studentSnapshot = await _dbRef.child('students').child(studentEmailKey).get();

      if (studentSnapshot.exists) {
        final studentRecord   = Map<String, dynamic>.from(studentSnapshot.value as Map);
        final studentOsId     = studentRecord['oneSignalId'] as String?;

        if (studentOsId != null) {
          // Get teacher's display name for the notification
          final teacherSnapshot = await _dbRef.child('teachers').child(_teacherEmailKey).get();
          final teacherName = teacherSnapshot.exists
              ? (Map<String, dynamic>.from(teacherSnapshot.value as Map)['fullName'] ?? 'A teacher')
              : 'A teacher';

          await _sendPush(
            recipientOneSignalId: studentOsId,
            title: teacherName,
            body:  text,
          );
        }
      }
      // ───────────────────────────────────────────────────────────────────

      Future.delayed(const Duration(milliseconds: 100), () {
        if (_chatScrollController.hasClients) {
          _chatScrollController.animateTo(
            _chatScrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
          );
        }
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error sending message: ${e.toString()}'), backgroundColor: Colors.red),
        );
      }
    }
  }

  String _formatMessageTime(int timestamp) {
    final dateTime   = DateTime.fromMillisecondsSinceEpoch(timestamp);
    final now        = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inDays == 0) {
      final hour        = dateTime.hour;
      final minute      = dateTime.minute.toString().padLeft(2, '0');
      final period      = hour >= 12 ? 'PM' : 'AM';
      final displayHour = hour > 12 ? hour - 12 : (hour == 0 ? 12 : hour);
      return '$displayHour:$minute $period';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return '${dateTime.day}/${dateTime.month}/${dateTime.year}';
    }
  }

  @override
  Widget build(BuildContext context) {
    final profileImageUrl =
        _studentProfileImageUrl ?? widget.studentData['studentProfileImage'];

    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B4513),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
              ),
              child: ClipOval(
                child: profileImageUrl != null && profileImageUrl.toString().isNotEmpty
                    ? Image.network(
                        profileImageUrl, fit: BoxFit.cover, width: 36, height: 36,
                        loadingBuilder: (_, child, progress) => progress == null
                            ? child
                            : Container(color: Colors.white,
                                child: const Center(child: SizedBox(width: 16, height: 16,
                                    child: CircularProgressIndicator(color: Color(0xFF8B4513), strokeWidth: 2)))),
                        errorBuilder: (_, __, ___) => Container(color: Colors.white,
                            child: Center(child: Text(
                                (widget.studentData['studentName'] ?? 'S')[0].toUpperCase(),
                                style: const TextStyle(color: Color(0xFF8B4513), fontWeight: FontWeight.bold, fontSize: 16)))),
                      )
                    : Container(color: Colors.white,
                        child: Center(child: Text(
                            (widget.studentData['studentName'] ?? 'S')[0].toUpperCase(),
                            style: const TextStyle(color: Color(0xFF8B4513), fontWeight: FontWeight.bold, fontSize: 16)))),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.studentData['studentName'] ?? 'Unknown',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  Text(widget.studentData['studentClass'] ?? '',
                      style: const TextStyle(fontSize: 12, color: Colors.white70),
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline, color: Colors.white),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => StudentChatInfo(studentData: widget.studentData))),
          ),
        ],
        elevation: 0,
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<List<Map<String, dynamic>>>(
              stream: _getChatMessagesStream(widget.studentData['studentEmailKey']),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator(color: Color(0xFF8B4513)));
                }

                final messages = snapshot.data ?? [];

                if (messages.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.message_outlined, size: 64, color: Colors.grey.shade400),
                        const SizedBox(height: 20),
                        Text('No messages yet', style: TextStyle(fontSize: 17, color: Colors.grey.shade600)),
                        const SizedBox(height: 10),
                        Text('Start the conversation!', style: TextStyle(fontSize: 15, color: Colors.grey.shade500)),
                      ],
                    ),
                  );
                }

                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (_chatScrollController.hasClients) {
                    _chatScrollController.animateTo(
                      _chatScrollController.position.maxScrollExtent,
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeOut,
                    );
                  }
                });

                return ListView.builder(
                  controller: _chatScrollController,
                  padding: const EdgeInsets.all(20),
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    final message = messages[index];
                    return _buildMessageBubble(message, message['senderType'] == 'teacher');
                  },
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 5, offset: const Offset(0, -2))],
            ),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF8E7),
                      borderRadius: BorderRadius.circular(26),
                      border: Border.all(color: Colors.brown.shade200),
                    ),
                    child: TextField(
                      controller: _messageController,
                      decoration: InputDecoration(
                        hintText: 'Type a message...',
                        hintStyle: TextStyle(color: Colors.grey.shade500, fontSize: 15),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
                      ),
                      maxLines: null,
                      textCapitalization: TextCapitalization.sentences,
                      onSubmitted: (_) => _sendMessage(),
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Container(
                  decoration: const BoxDecoration(color: Color(0xFF8B4513), shape: BoxShape.circle),
                  child: IconButton(
                    icon: const Icon(Icons.send, color: Colors.white, size: 22),
                    onPressed: _sendMessage,
                    padding: const EdgeInsets.all(12),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(Map<String, dynamic> message, bool isTeacher) {
    return Align(
      alignment: isTeacher ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.65),
        child: Column(
          crossAxisAlignment: isTeacher ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
              decoration: BoxDecoration(
                color: isTeacher ? const Color(0xFF8B4513) : Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft:     const Radius.circular(18),
                  topRight:    const Radius.circular(18),
                  bottomLeft:  isTeacher ? const Radius.circular(18) : const Radius.circular(4),
                  bottomRight: isTeacher ? const Radius.circular(4)  : const Radius.circular(18),
                ),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 6, offset: const Offset(0, 2))],
              ),
              child: Text(message['text'] ?? '',
                  style: TextStyle(fontSize: 15, color: isTeacher ? Colors.white : Colors.black87, height: 1.4)),
            ),
            const SizedBox(height: 6),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Text(_formatMessageTime(message['timestamp'] ?? 0),
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
            ),
          ],
        ),
      ),
    );
  }
}
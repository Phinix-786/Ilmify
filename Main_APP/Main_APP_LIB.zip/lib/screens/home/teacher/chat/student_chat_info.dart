import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'student_info_location.dart';

class StudentChatInfo extends StatefulWidget {
  final Map<String, dynamic> studentData;

  const StudentChatInfo({
    super.key,
    required this.studentData,
  });

  @override
  State<StudentChatInfo> createState() => _StudentChatInfoState();
}

class _StudentChatInfoState extends State<StudentChatInfo> {
  final _dbRef = FirebaseDatabase.instance.ref();
  Map<String, dynamic>? _fullStudentData;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadFullStudentData();
  }

  Future<void> _loadFullStudentData() async {
    try {
      final studentEmailKey = widget.studentData['studentEmailKey'];
      final snapshot = await _dbRef.child('students').child(studentEmailKey).get();

      if (snapshot.exists) {
        setState(() {
          _fullStudentData = Map<String, dynamic>.from(snapshot.value as Map);
          _isLoading = false;
        });
      } else {
        setState(() => _isLoading = false);
      }
    } catch (e) {
      print('Error loading student data: $e');
      setState(() => _isLoading = false);
    }
  }

  void _viewLocation() {
    if (_fullStudentData?['latitude'] != null && 
        _fullStudentData?['longitude'] != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => StudentInfoLocation(
            studentName: _fullStudentData?['fullName'] ?? 'Student',
            latitude: double.parse(_fullStudentData!['latitude']),
            longitude: double.parse(_fullStudentData!['longitude']),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B4513),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Student Information',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        elevation: 0,
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF8B4513)),
            )
          : SingleChildScrollView(
              child: Column(
                children: [
                  // Profile Header
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(24),
                    decoration: const BoxDecoration(
                      color: Color(0xFF8B4513),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(30),
                        bottomRight: Radius.circular(30),
                      ),
                    ),
                    child: Column(
                      children: [
                        Container(
                          width: 100,
                          height: 100,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 3),
                          ),
                          child: ClipOval(
                            child: _fullStudentData?['profileImageUrl'] != null &&
                                    _fullStudentData!['profileImageUrl'].toString().isNotEmpty
                                ? Image.network(
                                    _fullStudentData!['profileImageUrl'],
                                    fit: BoxFit.cover,
                                    loadingBuilder: (context, child, loadingProgress) {
                                      if (loadingProgress == null) return child;
                                      return Container(
                                        color: Colors.white,
                                        child: const Center(
                                          child: CircularProgressIndicator(
                                            color: Color(0xFF8B4513),
                                            strokeWidth: 2,
                                          ),
                                        ),
                                      );
                                    },
                                    errorBuilder: (context, error, stackTrace) {
                                      return Container(
                                        color: Colors.white,
                                        child: Center(
                                          child: Text(
                                            (_fullStudentData?['fullName'] ?? 'S')[0].toUpperCase(),
                                            style: const TextStyle(
                                              color: Color(0xFF8B4513),
                                              fontWeight: FontWeight.bold,
                                              fontSize: 40,
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  )
                                : Container(
                                    color: Colors.white,
                                    child: Center(
                                      child: Text(
                                        (_fullStudentData?['fullName'] ?? 'S')[0].toUpperCase(),
                                        style: const TextStyle(
                                          color: Color(0xFF8B4513),
                                          fontWeight: FontWeight.bold,
                                          fontSize: 40,
                                        ),
                                      ),
                                    ),
                                  ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          _fullStudentData?['fullName'] ?? 'Student',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _fullStudentData?['class'] ?? '',
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.white70,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Information Cards
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildInfoCard(
                          icon: Icons.person_outline,
                          title: 'Personal Information',
                          children: [
                            _buildInfoRow('Full Name', _fullStudentData?['fullName']),
                            _buildInfoRow('Father\'s Name', _fullStudentData?['fatherName']),
                            _buildInfoRow('Phone', _fullStudentData?['phoneNumber']),
                            _buildInfoRow('City', _fullStudentData?['city']),
                            _buildInfoRow('Number of Siblings', _fullStudentData?['siblings']),
                          ],
                        ),
                        const SizedBox(height: 16),
                        _buildInfoCard(
                          icon: Icons.school_outlined,
                          title: 'Academic Details',
                          children: [
                            _buildInfoRow('Class', _fullStudentData?['class']),
                            _buildSubjectsRow('Subjects', _fullStudentData?['subjects']),
                          ],
                        ),
                        const SizedBox(height: 16),
                        _buildInfoCard(
                          icon: Icons.attach_money_outlined,
                          title: 'Pricing & Hours',
                          children: [
                            _buildInfoRow('Hourly Pay', 'Rs ${_fullStudentData?['hourlyPay']}/month'),
                            _buildInfoRow('Study Hours per Day', '${_fullStudentData?['hoursPerDay']} hours'),
                          ],
                        ),
                        const SizedBox(height: 16),
                        if (_fullStudentData?['siblingsWantToStudy'] == true &&
                            _fullStudentData?['siblingsData'] != null &&
                            (_fullStudentData!['siblingsData'] as List).isNotEmpty)
                          _buildSiblingsCard(),
                        const SizedBox(height: 16),
                        // Location Button
                        if (_fullStudentData?['latitude'] != null &&
                            _fullStudentData?['longitude'] != null)
                          InkWell(
                            onTap: _viewLocation,
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.05),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFFFF8E7),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: const Icon(
                                      Icons.location_on_outlined,
                                      color: Color(0xFF8B4513),
                                      size: 24,
                                    ),
                                  ),
                                  const SizedBox(width: 16),
                                  const Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'View Location',
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                            color: Color(0xFF8B4513),
                                          ),
                                        ),
                                        SizedBox(height: 4),
                                        Text(
                                          'See student\'s location on map',
                                          style: TextStyle(
                                            fontSize: 13,
                                            color: Colors.grey,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const Icon(
                                    Icons.arrow_forward_ios,
                                    size: 16,
                                    color: Colors.grey,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        const SizedBox(height: 24),
                      ],
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildInfoCard({
    required IconData icon,
    required String title,
    required List<Widget> children,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF8E7),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: const Color(0xFF8B4513), size: 20),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF8B4513),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...children,
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, dynamic value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value?.toString() ?? 'N/A',
              style: const TextStyle(
                fontSize: 14,
                color: Colors.black87,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSubjectsRow(String label, dynamic subjects) {
    final subjectList = subjects is List ? subjects : [];
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[600],
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: subjectList.map<Widget>((subject) {
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF8E7),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.brown.shade300),
                ),
                child: Text(
                  subject.toString(),
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF8B4513),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildSiblingsCard() {
    final siblingsData = _fullStudentData!['siblingsData'] as List;
    
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF8E7),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.people_outline, color: Color(0xFF8B4513), size: 20),
              ),
              const SizedBox(width: 12),
              const Text(
                'Siblings Information',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF8B4513),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...siblingsData.asMap().entries.map((entry) {
            final index = entry.key;
            final sibling = entry.value as Map<String, dynamic>;
            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF8E7),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.brown.shade200),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Sibling ${index + 1}: ${sibling['name']}',
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF8B4513),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Class: ${sibling['class']}',
                    style: TextStyle(
                      fontSize: 13,
                      color: Colors.grey[700],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: (sibling['subjects'] as List).map<Widget>((subject) {
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          subject.toString(),
                          style: const TextStyle(
                            fontSize: 11,
                            color: Color(0xFF8B4513),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}
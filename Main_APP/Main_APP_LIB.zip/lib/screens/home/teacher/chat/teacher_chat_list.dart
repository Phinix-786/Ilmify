import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'teacher_student_chat.dart';

class TeacherChatList extends StatefulWidget {
  const TeacherChatList({super.key});

  @override
  State<TeacherChatList> createState() => _TeacherChatListState();
}

class _TeacherChatListState extends State<TeacherChatList> {
  final _dbRef = FirebaseDatabase.instance.ref();
  String _teacherEmailKey = '';

  @override
  void initState() {
    super.initState();
    _loadTeacherData();
  }

  Future<void> _loadTeacherData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final emailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');
      
      try {
        final snapshot = await _dbRef.child('teachers').child(emailKey).get();
        if (snapshot.exists) {
          setState(() {
            _teacherEmailKey = emailKey;
          });
        }
      } catch (e) {
        print('Error loading teacher data: $e');
        setState(() {
          _teacherEmailKey = emailKey;
        });
      }
    }
  }

  // Generate unique chat ID for teacher-student pair
  String _generateChatId(String teacherKey, String studentKey) {
    final keys = [teacherKey, studentKey]..sort();
    return '${keys[0]}_${keys[1]}';
  }

  // Delete student and all related data
  Future<void> _deleteStudent(Map<String, dynamic> student) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.orange),
            SizedBox(width: 8),
            Text('Delete Student?'),
          ],
        ),
        content: Text(
          'Are you sure you want to delete ${student['studentName']}?\n\n'
          'This will permanently delete:\n'
          '• All chat messages\n'
          '• Request history\n'
          '• Connection with this student\n\n'
          'You can send a new request later if needed.',
          style: const TextStyle(fontSize: 14),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text('Delete', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    try {
      // Show loading indicator
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const Center(
          child: Card(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(color: Color(0xFF8B4513)),
                  SizedBox(height: 16),
                  Text('Deleting...'),
                ],
              ),
            ),
          ),
        ),
      );

      final studentEmailKey = student['studentEmailKey'];
      
      // 1. Delete chat messages
      final chatId = _generateChatId(_teacherEmailKey, studentEmailKey);
      await _dbRef.child('chats').child(chatId).remove();

      // 2. Delete from teacherRequests (received from student)
      final receivedSnapshot = await _dbRef
          .child('teacherRequests')
          .child(_teacherEmailKey)
          .get();
      
      if (receivedSnapshot.exists) {
        final data = Map<String, dynamic>.from(receivedSnapshot.value as Map);
        for (var entry in data.entries) {
          final request = Map<String, dynamic>.from(entry.value as Map);
          if (request['studentEmailKey'] == studentEmailKey) {
            await _dbRef
                .child('teacherRequests')
                .child(_teacherEmailKey)
                .child(entry.key)
                .remove();
          }
        }
      }

      // 3. Delete from teacherSentRequests (sent to student)
      final sentSnapshot = await _dbRef
          .child('teacherSentRequests')
          .child(_teacherEmailKey)
          .get();
      
      if (sentSnapshot.exists) {
        final data = Map<String, dynamic>.from(sentSnapshot.value as Map);
        for (var entry in data.entries) {
          final request = Map<String, dynamic>.from(entry.value as Map);
          if (request['studentEmailKey'] == studentEmailKey) {
            await _dbRef
                .child('teacherSentRequests')
                .child(_teacherEmailKey)
                .child(entry.key)
                .remove();
          }
        }
      }

      // 4. Delete from studentRequests (student's received requests)
      final studentReceivedSnapshot = await _dbRef
          .child('studentRequests')
          .child(studentEmailKey)
          .get();
      
      if (studentReceivedSnapshot.exists) {
        final data = Map<String, dynamic>.from(studentReceivedSnapshot.value as Map);
        for (var entry in data.entries) {
          final request = Map<String, dynamic>.from(entry.value as Map);
          if (request['teacherEmailKey'] == _teacherEmailKey) {
            await _dbRef
                .child('studentRequests')
                .child(studentEmailKey)
                .child(entry.key)
                .remove();
          }
        }
      }

      // 5. Delete from studentSentRequests (student's sent requests)
      final studentSentSnapshot = await _dbRef
          .child('studentSentRequests')
          .child(studentEmailKey)
          .get();
      
      if (studentSentSnapshot.exists) {
        final data = Map<String, dynamic>.from(studentSentSnapshot.value as Map);
        for (var entry in data.entries) {
          final request = Map<String, dynamic>.from(entry.value as Map);
          if (request['teacherEmailKey'] == _teacherEmailKey) {
            await _dbRef
                .child('studentSentRequests')
                .child(studentEmailKey)
                .child(entry.key)
                .remove();
          }
        }
      }

      if (mounted) {
        Navigator.pop(context); // Close loading dialog
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${student['studentName']} deleted successfully'),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context); // Close loading dialog
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error deleting student: ${e.toString()}'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    }
  }

  // Get all accepted students (both sent and received requests)
  Stream<List<Map<String, dynamic>>> _getAcceptedStudentsStream() {
    if (_teacherEmailKey.isEmpty) {
      return Stream.value([]);
    }

    return Stream.value([]).asyncMap((_) async {
      final List<Map<String, dynamic>> acceptedStudents = [];
      final Set<String> addedStudents = {};

      try {
        // Get accepted requests from students (received by teacher)
        final receivedSnapshot = await _dbRef
            .child('teacherRequests')
            .child(_teacherEmailKey)
            .get();

        if (receivedSnapshot.exists) {
          final data = Map<String, dynamic>.from(receivedSnapshot.value as Map);
          for (var entry in data.entries) {
            final request = Map<String, dynamic>.from(entry.value as Map);
            if (request['status'] == 'accepted' && 
                !addedStudents.contains(request['studentEmailKey'])) {
              
              // Load student profile image from students database
              String? profileImageUrl;
              try {
                final studentSnapshot = await _dbRef
                    .child('students')
                    .child(request['studentEmailKey'])
                    .child('profileImageUrl')
                    .get();
                
                if (studentSnapshot.exists) {
                  profileImageUrl = studentSnapshot.value?.toString();
                }
              } catch (e) {
                print('Error loading profile image: $e');
              }

              acceptedStudents.add({
                'studentName': request['studentName'],
                'studentEmail': request['studentEmail'],
                'studentEmailKey': request['studentEmailKey'],
                'studentClass': request['studentClass'],
                'studentProfileImage': profileImageUrl ?? request['studentProfileImage'],
              });
              addedStudents.add(request['studentEmailKey']);
            }
          }
        }

        // Get accepted requests sent to students (sent by teacher)
        final sentSnapshot = await _dbRef
            .child('teacherSentRequests')
            .child(_teacherEmailKey)
            .get();

        if (sentSnapshot.exists) {
          final data = Map<String, dynamic>.from(sentSnapshot.value as Map);
          for (var entry in data.entries) {
            final request = Map<String, dynamic>.from(entry.value as Map);
            if (request['status'] == 'accepted' && 
                !addedStudents.contains(request['studentEmailKey'])) {
              
              // Load student profile image from students database
              String? profileImageUrl;
              try {
                final studentSnapshot = await _dbRef
                    .child('students')
                    .child(request['studentEmailKey'])
                    .child('profileImageUrl')
                    .get();
                
                if (studentSnapshot.exists) {
                  profileImageUrl = studentSnapshot.value?.toString();
                }
              } catch (e) {
                print('Error loading profile image: $e');
              }

              acceptedStudents.add({
                'studentName': request['studentName'],
                'studentEmail': request['studentEmail'],
                'studentEmailKey': request['studentEmailKey'],
                'studentClass': request['studentClass'],
                'studentProfileImage': profileImageUrl ?? request['studentProfileImage'],
              });
              addedStudents.add(request['studentEmailKey']);
            }
          }
        }

        // Sort by student name
        acceptedStudents.sort((a, b) => 
          (a['studentName'] ?? '').compareTo(b['studentName'] ?? ''));
      } catch (e) {
        print('Error fetching accepted students: $e');
      }

      return acceptedStudents;
    }).asBroadcastStream();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B4513),
        automaticallyImplyLeading: false,
        title: const Text(
          'Messages',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        elevation: 0,
        centerTitle: true,
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: _getAcceptedStudentsStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(color: Color(0xFF8B4513)),
            );
          }

          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Text(
                  'Error loading students',
                  style: TextStyle(color: Colors.red.shade700),
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }

          final students = snapshot.data ?? [];

          if (students.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(40),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(32),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.brown.shade200.withOpacity(0.3),
                            blurRadius: 20,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.contacts_outlined,
                        size: 80,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 32),
                    const Text(
                      'No Students Yet',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Accept student requests to start chatting',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.brown.shade600,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }

          return ListView.builder(
            itemCount: students.length,
            itemBuilder: (context, index) {
              final student = students[index];
              return InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => StudentTeacherChat(
                        studentData: student,
                      ),
                    ),
                  );
                },
                onLongPress: () => _deleteStudent(student),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border(
                      bottom: BorderSide(
                        color: Colors.grey.shade200,
                        width: 1,
                      ),
                    ),
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  child: Row(
                    children: [
                      // Profile Picture
                      Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: const Color(0xFF8B4513).withOpacity(0.2),
                            width: 2,
                          ),
                        ),
                        child: ClipOval(
                          child: student['studentProfileImage'] != null &&
                                  student['studentProfileImage'].toString().isNotEmpty
                              ? Image.network(
                                  student['studentProfileImage'],
                                  fit: BoxFit.cover,
                                  width: 56,
                                  height: 56,
                                  loadingBuilder: (context, child, loadingProgress) {
                                    if (loadingProgress == null) return child;
                                    return Container(
                                      color: const Color(0xFF8B4513),
                                      child: const Center(
                                        child: CircularProgressIndicator(
                                          color: Colors.white,
                                          strokeWidth: 2,
                                        ),
                                      ),
                                    );
                                  },
                                  errorBuilder: (context, error, stackTrace) {
                                    return Container(
                                      color: const Color(0xFF8B4513),
                                      child: Center(
                                        child: Text(
                                          (student['studentName'] ?? 'S')[0].toUpperCase(),
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 24,
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                )
                              : Container(
                                  color: const Color(0xFF8B4513),
                                  child: Center(
                                    child: Text(
                                      (student['studentName'] ?? 'S')[0].toUpperCase(),
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 24,
                                      ),
                                    ),
                                  ),
                                ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              student['studentName'] ?? 'Unknown',
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Colors.black87,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              student['studentClass'] ?? '',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey.shade600,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      Icon(
                        Icons.chevron_right,
                        color: Colors.grey.shade400,
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
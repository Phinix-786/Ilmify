import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:shared_preferences/shared_preferences.dart';
import './student_list_teacher.dart';
import 'requests_teacher.dart';
import 'account_page_teacher.dart';
import 'chat/teacher_chat_list.dart';  // Changed from student_teacher_chat.dart

class HomeTeacher extends StatefulWidget {
  const HomeTeacher({super.key});

  @override
  State<HomeTeacher> createState() => _HomeTeacherState();
}

class _HomeTeacherState extends State<HomeTeacher> {
  int _selectedIndex = 0;
  Map<String, dynamic>? _teacherData;
  bool _isLoading = true;
  bool _hasProfilePic = false;
  bool _isFirstVisit = true;
  int _pendingRequestsCount = 0;
  
  // Stream subscriptions for cleanup
  StreamSubscription? _pendingRequestsSubscription;
  StreamSubscription? _profilePicSubscription;

  @override
  void initState() {
    super.initState();
    _checkFirstVisit();
    _loadTeacherData();
    _listenToPendingRequests();
    _listenToProfilePicChanges();
  }

  @override
  void dispose() {
    // Cancel subscriptions to prevent memory leaks and setState after dispose
    _pendingRequestsSubscription?.cancel();
    _profilePicSubscription?.cancel();
    super.dispose();
  }

  Future<void> _checkFirstVisit() async {
    final prefs = await SharedPreferences.getInstance();
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final key = 'teacher_first_visit_${user.uid}';
      final hasVisitedBefore = prefs.getBool(key) ?? false;
      
      if (mounted) {
        setState(() {
          _isFirstVisit = !hasVisitedBefore;
        });
      }

      if (!hasVisitedBefore) {
        await prefs.setBool(key, true);
      }
    }
  }

  void _listenToProfilePicChanges() {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final emailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');
    _profilePicSubscription = FirebaseDatabase.instance
        .ref()
        .child('teachers')
        .child(emailKey)
        .child('profileImageUrl')
        .onValue
        .listen((event) {
      if (mounted) {
        setState(() {
          _hasProfilePic = event.snapshot.value != null && 
                          event.snapshot.value.toString().isNotEmpty;
        });
      }
    });
  }

  void _listenToPendingRequests() {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final emailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');
    _pendingRequestsSubscription = FirebaseDatabase.instance
        .ref()
        .child('teacherRequests')
        .child(emailKey)
        .onValue
        .listen((event) {
      if (mounted) {
        if (event.snapshot.value != null) {
          final data = Map<String, dynamic>.from(event.snapshot.value as Map);
          int count = 0;
          data.forEach((key, value) {
            final request = Map<String, dynamic>.from(value as Map);
            if (request['status'] == 'pending') {
              count++;
            }
          });
          setState(() => _pendingRequestsCount = count);
        } else {
          setState(() => _pendingRequestsCount = 0);
        }
      }
    });
  }

  Future<void> _loadTeacherData() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final emailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');
      final snapshot = await FirebaseDatabase.instance
          .ref()
          .child('teachers')
          .child(emailKey)
          .get();

      if (snapshot.exists) {
        final data = Map<String, dynamic>.from(snapshot.value as Map);
        if (mounted) {
          setState(() {
            _teacherData = data;
            _hasProfilePic = data['profileImageUrl'] != null && 
                            data['profileImageUrl'].toString().isNotEmpty;
            _isLoading = false;
          });
        }
      } else {
        if (mounted) {
          setState(() => _isLoading = false);
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  Future<bool> _onWillPop() async {
    // If not on home page, go back to home
    if (_selectedIndex != 0) {
      setState(() {
        _selectedIndex = 0;
      });
      return false; // Don't exit app
    }
    
    // If on home page, show exit confirmation
    final shouldExit = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text(
          'Exit App',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Color(0xFF8B4513),
          ),
        ),
        content: const Text('Do you want to exit the app?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text(
              'Cancel',
              style: TextStyle(color: Colors.grey),
            ),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF8B4513),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: const Text(
              'Exit',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
    
    if (shouldExit == true) {
      // Exit the app
      SystemNavigator.pop();
    }
    
    return false; // Always return false to handle exit manually
  }

  void _navigateToChat() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const TeacherChatList(),  // Changed here
      ),
    );
  }

  Widget _buildHomePage() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(
          color: Color(0xFF8B4513),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () async {
        await _loadTeacherData();
      },
      color: const Color(0xFF8B4513),
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Welcome Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: const BoxDecoration(
                color: Color(0xFF8B4513),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(30),
                  bottomRight: Radius.circular(30),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _isFirstVisit ? 'Welcome!' : 'Welcome Back!',
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _teacherData?['fullName'] ?? 'Teacher',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white.withValues(alpha: 0.9),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Profile Photo Alert - Only show if profile pic is not set
            if (!_hasProfilePic)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: GestureDetector(
                  onTap: () => _onItemTapped(4), // Changed to index 4 for Account
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.orange[50],
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.orange[200]!),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.orange[100],
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            Icons.camera_alt,
                            color: Colors.orange[700],
                            size: 24,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Complete Your Profile',
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.orange[800],
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Add a profile photo to help students recognize you',
                                style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.orange[700],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 16,
                          color: Colors.orange[400],
                        ),
                      ],
                    ),
                  ),
                ),
              ),

            if (!_hasProfilePic) const SizedBox(height: 20),

            // Quick Actions Row
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  Expanded(
                    child: _buildQuickActionCard(
                      icon: Icons.search,
                      label: 'Find Students',
                      color: const Color(0xFF8B4513),
                      onTap: () => setState(() => _selectedIndex = 1),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildQuickActionCard(
                      icon: Icons.inbox,
                      label: 'Requests',
                      color: Colors.blue.shade700,
                      badge: _pendingRequestsCount > 0 ? _pendingRequestsCount : null,
                      onTap: () => setState(() => _selectedIndex = 2),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Quick Actions
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Quick Actions',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF8B4513),
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildActionCard(
                    icon: Icons.schedule,
                    title: 'Availability',
                    subtitle: _teacherData?['isAvailable'] == true
                        ? 'Currently available'
                        : 'Currently unavailable',
                    trailing: Switch(
                      value: _teacherData?['isAvailable'] ?? true,
                      onChanged: _toggleAvailability,
                      activeTrackColor: Colors.green,
                    ),
                    onTap: null,
                  ),
                  const SizedBox(height: 12),
                  _buildActionCard(
                    icon: Icons.chat_bubble_outline,
                    title: 'Messages',
                    subtitle: 'Chat with your students',
                    onTap: _navigateToChat,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActionCard({
    required IconData icon,
    required String label,
    required Color color,
    int? badge,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: color, size: 28),
                ),
                if (badge != null)
                  Positioned(
                    right: -6,
                    top: -6,
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 2),
                      ),
                      constraints: const BoxConstraints(minWidth: 20, minHeight: 20),
                      child: Text(
                        badge > 9 ? '9+' : badge.toString(),
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: color,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    Widget? trailing,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF8E7),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                icon,
                color: const Color(0xFF8B4513),
                size: 24,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF8B4513),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 13,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
            if (trailing != null)
              trailing
            else if (onTap != null)
              const Icon(
                Icons.arrow_forward_ios,
                size: 16,
                color: Colors.grey,
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _toggleAvailability(bool value) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final emailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');
      await FirebaseDatabase.instance
          .ref()
          .child('teachers')
          .child(emailKey)
          .update({'isAvailable': value});

      if (mounted) {
        setState(() {
          _teacherData?['isAvailable'] = value;
        });
      }

      if (mounted) {
        ScaffoldMessenger.of(context).clearSnackBars();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(
                  value ? Icons.check_circle : Icons.info_outline,
                  color: Colors.white,
                  size: 20,
                ),
                const SizedBox(width: 12),
                Text(
                  value
                      ? 'You are now available for new students'
                      : 'You are now set as unavailable',
                ),
              ],
            ),
            backgroundColor: value ? const Color(0xFF4CAF50) : const Color(0xFFFF9800),
            behavior: SnackBarBehavior.floating,
            margin: const EdgeInsets.all(16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).clearSnackBars();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Row(
              children: [
                Icon(Icons.error_outline, color: Colors.white, size: 20),
                SizedBox(width: 12),
                Text('Unable to update availability. Please try again.'),
              ],
            ),
            backgroundColor: const Color(0xFFE53935),
            behavior: SnackBarBehavior.floating,
            margin: const EdgeInsets.all(16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      _buildHomePage(),
      const StudentsListTeacher(),
      const RequestsTeacher(),
      // Chat page - Changed to TeacherChatList
      const TeacherChatList(),
      const AccountPageTeacher(),
    ];

    return PopScope(  // Changed from WillPopScope
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        final shouldPop = await _onWillPop();
        if (shouldPop && context.mounted) {
          Navigator.of(context).pop();
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xFFFFF8E7),
        appBar: _selectedIndex == 0
            ? AppBar(
                backgroundColor: const Color(0xFF8B4513),
                automaticallyImplyLeading: false,
                title: const Text(
                  'Teacher Dashboard',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                elevation: 0,
                centerTitle: true,
              )
            : null,
        body: pages[_selectedIndex],
        bottomNavigationBar: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.08),
                blurRadius: 10,
                offset: const Offset(0, -2),
              ),
            ],
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildNavItem(
                    index: 0,
                    icon: Icons.home_outlined,
                    activeIcon: Icons.home,
                    label: 'Home',
                  ),
                  _buildNavItem(
                    index: 1,
                    icon: Icons.search_outlined,
                    activeIcon: Icons.search,
                    label: 'Students',
                  ),
                  _buildNavItem(
                    index: 2,
                    icon: Icons.inbox_outlined,
                    activeIcon: Icons.inbox,
                    label: 'Requests',
                    badgeCount: _pendingRequestsCount,
                  ),
                  _buildNavItem(
                    index: 3,
                    icon: Icons.chat_outlined,
                    activeIcon: Icons.chat,
                    label: 'Chat',
                  ),
                  _buildNavItem(
                    index: 4,
                    icon: Icons.person_outline,
                    activeIcon: Icons.person,
                    label: 'Account',
                    showBadge: !_hasProfilePic,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem({
    required int index,
    required IconData icon,
    required IconData activeIcon,
    required String label,
    bool showBadge = false,
    int badgeCount = 0,
  }) {
    final isSelected = _selectedIndex == index;
    return InkWell(
      onTap: () => _onItemTapped(index),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected
              ? const Color(0xFF8B4513).withValues(alpha: 0.1)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Icon(
                  isSelected ? activeIcon : icon,
                  color: isSelected ? const Color(0xFF8B4513) : Colors.grey,
                  size: 26,
                ),
                if (showBadge || badgeCount > 0)
                  Positioned(
                    right: -4,
                    top: -4,
                    child: Container(
                      padding: EdgeInsets.all(badgeCount > 0 ? 4 : 0),
                      constraints: BoxConstraints(
                        minWidth: badgeCount > 0 ? 16 : 10,
                        minHeight: badgeCount > 0 ? 16 : 10,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 1.5),
                      ),
                      child: badgeCount > 0
                          ? Text(
                              badgeCount > 9 ? '9+' : badgeCount.toString(),
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 9,
                                fontWeight: FontWeight.bold,
                              ),
                            )
                          : null,
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                color: isSelected ? const Color(0xFF8B4513) : Colors.grey,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:io';
import 'dart:convert';
import '../home_teacher.dart';

class Ver3Teacher extends StatefulWidget {
  final String fullName;
  final String cnicNumber;
  final String dateOfBirth;
  final XFile livePhoto;

  const Ver3Teacher({
    super.key,
    required this.fullName,
    required this.cnicNumber,
    required this.dateOfBirth,
    required this.livePhoto,
  });

  @override
  State<Ver3Teacher> createState() => _Ver3TeacherState();
}

class _Ver3TeacherState extends State<Ver3Teacher> {
  final ImagePicker _picker = ImagePicker();
  XFile? _cnicFront;
  XFile? _cnicBack;
  bool _isSubmitting = false;

  /// Convert image file to base64 with compression
  Future<String> _imageToBase64(XFile xfile) async {
    final bytes = await File(xfile.path).readAsBytes();
    return base64Encode(bytes);
  }

  Future<void> _pickCnicFront() async {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'CNIC Front Photo',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF8B4513),
              ),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Color(0xFF8B4513)),
              title: const Text('Take Photo'),
              onTap: () async {
                Navigator.pop(context);
                final photo = await _picker.pickImage(
                  source: ImageSource.camera,
                  imageQuality: 50,
                  maxWidth: 800,
                  maxHeight: 600,
                );
                if (photo != null) setState(() => _cnicFront = photo);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Color(0xFF8B4513)),
              title: const Text('Choose from Gallery'),
              onTap: () async {
                Navigator.pop(context);
                final photo = await _picker.pickImage(
                  source: ImageSource.gallery,
                  imageQuality: 50,
                  maxWidth: 800,
                  maxHeight: 600,
                );
                if (photo != null) setState(() => _cnicFront = photo);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickCnicBack() async {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'CNIC Back Photo',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF8B4513),
              ),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Color(0xFF8B4513)),
              title: const Text('Take Photo'),
              onTap: () async {
                Navigator.pop(context);
                final photo = await _picker.pickImage(
                  source: ImageSource.camera,
                  imageQuality: 50,
                  maxWidth: 800,
                  maxHeight: 600,
                );
                if (photo != null) setState(() => _cnicBack = photo);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Color(0xFF8B4513)),
              title: const Text('Choose from Gallery'),
              onTap: () async {
                Navigator.pop(context);
                final photo = await _picker.pickImage(
                  source: ImageSource.gallery,
                  imageQuality: 50,
                  maxWidth: 800,
                  maxHeight: 600,
                );
                if (photo != null) setState(() => _cnicBack = photo);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _submitVerification() async {
    if (_cnicFront == null || _cnicBack == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please upload both CNIC photos'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('User not logged in');

      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final userId = user.uid;
      final emailKey =
          user.email!.replaceAll('.', '_').replaceAll('@', '_at_');

      // Show progress dialog
      if (mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => const Center(
            child: Card(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(color: Color(0xFF8B4513)),
                    SizedBox(height: 16),
                    Text('Uploading documents...'),
                  ],
                ),
              ),
            ),
          ),
        );
      }

      // Convert all 3 images to base64 concurrently
      final results = await Future.wait([
        _imageToBase64(widget.livePhoto),
        _imageToBase64(_cnicFront!),
        _imageToBase64(_cnicBack!),
      ]);

      final livePhotoBase64 = results[0];
      final cnicFrontBase64 = results[1];
      final cnicBackBase64 = results[2];

      // Save verification images to Firestore (separate doc to keep it clean)
      await FirebaseFirestore.instance
          .collection('verification_images')
          .doc(userId)
          .set({
        'livePhoto': livePhotoBase64,
        'cnicFront': cnicFrontBase64,
        'cnicBack': cnicBackBase64,
        'submittedAt': FieldValue.serverTimestamp(),
        'email': user.email,
        'userId': userId,
      });

      // Save verification metadata to Realtime DB (no images here)
      final verificationData = {
        'id': userId,
        'fullName': widget.fullName,
        'cnicNumber': widget.cnicNumber,
        'dateOfBirth': widget.dateOfBirth,
        'email': user.email,
        'userId': userId,
        'submittedAt': timestamp,
        'status': 'pending',
        'isVerified': false,
        // Store a reference instead of image URLs
        'imagesStoredIn': 'firestore/verification_images/$userId',
      };

      await FirebaseDatabase.instance
          .ref()
          .child('pending_verifications')
          .child(userId)
          .set(verificationData);

      // Update teacher profile in Realtime DB
      await FirebaseDatabase.instance
          .ref()
          .child('teachers')
          .child(emailKey)
          .update({
        'verificationStatus': 'pending',
        'isVerified': false,
        'verificationSubmittedAt': timestamp,
        'fullName': widget.fullName,
        'cnicNumber': widget.cnicNumber,
        'dateOfBirth': widget.dateOfBirth,
      });

      // Close progress dialog
      if (mounted) Navigator.pop(context);

      if (mounted) {
        Navigator.of(context).popUntil((route) => route.isFirst);

        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) => Dialog(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            insetPadding:
                const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.check_circle,
                        color: Colors.green, size: 64),
                    const SizedBox(height: 16),
                    const Text(
                      'Submitted Successfully!',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF8B4513),
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Your verification request has been submitted. We will review your information and notify you once verified.',
                      style: TextStyle(fontSize: 14, color: Colors.black87),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const HomeTeacher()),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF8B4513),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8)),
                        ),
                        child: const Text('OK',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted && Navigator.canPop(context)) Navigator.pop(context);
      setState(() => _isSubmitting = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 5),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B4513),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: _isSubmitting ? null : () => Navigator.pop(context),
        ),
        title: const Text(
          'Step 3 of 3',
          style: TextStyle(
              fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        elevation: 0,
        centerTitle: true,
      ),
      body: Column(
        children: [
          Container(
            height: 4,
            color: Colors.grey[300],
            child: Container(color: const Color(0xFF8B4513)),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'CNIC Photos',
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF8B4513)),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Upload clear photos of both sides of your CNIC',
                    style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                  ),
                  const SizedBox(height: 32),

                  // CNIC Front
                  const Text(
                    'CNIC Front Side',
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF8B4513)),
                  ),
                  const SizedBox(height: 12),
                  GestureDetector(
                    onTap: _isSubmitting ? null : _pickCnicFront,
                    child: Container(
                      width: double.infinity,
                      height: 180,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: _cnicFront != null
                              ? Colors.green
                              : Colors.grey[300]!,
                          width: 2,
                        ),
                      ),
                      child: _cnicFront != null
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(14),
                              child: Image.file(File(_cnicFront!.path),
                                  fit: BoxFit.cover),
                            )
                          : Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.add_photo_alternate_outlined,
                                    size: 48, color: Colors.grey[400]),
                                const SizedBox(height: 12),
                                Text('Tap to upload front side',
                                    style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.grey[600])),
                              ],
                            ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // CNIC Back
                  const Text(
                    'CNIC Back Side',
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF8B4513)),
                  ),
                  const SizedBox(height: 12),
                  GestureDetector(
                    onTap: _isSubmitting ? null : _pickCnicBack,
                    child: Container(
                      width: double.infinity,
                      height: 180,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: _cnicBack != null
                              ? Colors.green
                              : Colors.grey[300]!,
                          width: 2,
                        ),
                      ),
                      child: _cnicBack != null
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(14),
                              child: Image.file(File(_cnicBack!.path),
                                  fit: BoxFit.cover),
                            )
                          : Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.add_photo_alternate_outlined,
                                    size: 48, color: Colors.grey[400]),
                                const SizedBox(height: 12),
                                Text('Tap to upload back side',
                                    style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.grey[600])),
                              ],
                            ),
                    ),
                  ),
                  const SizedBox(height: 32),

                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.blue.shade200),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(Icons.security,
                            color: Colors.blue.shade700, size: 20),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Your documents are stored securely and only accessible by admins for verification.',
                            style: TextStyle(
                                fontSize: 13, color: Colors.blue.shade900),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Submit Button
          Container(
            padding: const EdgeInsets.all(24),
            child: SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: _isSubmitting ? null : _submitVerification,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF8B4513),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  elevation: 2,
                ),
                child: _isSubmitting
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                            color: Colors.white, strokeWidth: 2))
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('Submit for Verification',
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white)),
                          SizedBox(width: 8),
                          Icon(Icons.check_circle,
                              color: Colors.white, size: 20),
                        ],
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

// ── Your OneSignal credentials ─────────────────────────────────────────────
const _kOneSignalAppId      = 'your-onesignal-app-id'; // Dashboard → Settings → Keys & IDs
const _kOneSignalRestApiKey = 'YOUR_ONESIGNAL_REST_API_KEY'; // Dashboard → Settings → Keys & IDs
// ──────────────────────────────────────────────────────────────────────────

class TeacherRequestStudentInfo extends StatefulWidget {
  final Map<String, dynamic> studentData;
  final bool hasRequestSent;

  const TeacherRequestStudentInfo({
    super.key,
    required this.studentData,
    this.hasRequestSent = false,
  });

  @override
  State<TeacherRequestStudentInfo> createState() => _TeacherRequestStudentInfoState();
}

class _TeacherRequestStudentInfoState extends State<TeacherRequestStudentInfo> {
  bool _isSendingRequest = false;
  final _dbRef = FirebaseDatabase.instance.ref();
  late bool _hasRequestSent;

  @override
  void initState() {
    super.initState();
    _hasRequestSent = widget.hasRequestSent;
  }

  String _maskPhoneNumber(String phone) {
    if (phone.length < 4) return phone;
    final start = phone.substring(0, 4);
    final end = phone.substring(phone.length - 1);
    final masked = '*' * (phone.length - 5);
    return '$start$masked$end';
  }

  /// Sends a OneSignal push to [recipientFirebaseUid].
  /// We use external_id targeting — this works because on login each device
  /// calls OneSignal.login(user.uid), which links their UID to their push token.
  Future<void> _sendPush({
    required String recipientFirebaseUid,
    required String title,
    required String body,
    Map<String, String> data = const {},
  }) async {
    try {
      await http.post(
        Uri.parse('https://onesignal.com/api/v1/notifications'),
        headers: {
          'Content-Type':  'application/json',
          'Authorization': 'Basic $_kOneSignalRestApiKey',
        },
        body: jsonEncode({
          'app_id':          _kOneSignalAppId,
          'include_aliases': {'external_id': [recipientFirebaseUid]},
          'target_channel':  'push',
          'headings':        {'en': title},
          'contents':        {'en': body},
          'data':            data,
        }),
      );
    } catch (_) {
      // Notification failure is non-fatal — request was already saved
    }
  }

  Future<void> _sendRequest() async {
    setState(() => _isSendingRequest = true);

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('Not authenticated');

      final teacherEmailKey  = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');
      final studentEmailKey  = widget.studentData['key'] as String;

      // Fetch teacher data
      final teacherSnapshot = await _dbRef.child('teachers').child(teacherEmailKey).get();
      if (!teacherSnapshot.exists) throw Exception('Teacher data not found');
      final teacherData = Map<String, dynamic>.from(teacherSnapshot.value as Map);

      final requestId = '${DateTime.now().millisecondsSinceEpoch}';

      // 1. Write request into student's inbox
      await _dbRef
          .child('studentRequests')
          .child(studentEmailKey)
          .child(requestId)
          .set({
        'teacherEmailKey':      teacherEmailKey,
        'teacherName':          teacherData['fullName'] ?? 'Unknown Teacher',
        'teacherEmail':         user.email,
        'teacherPhone':         teacherData['phoneNumber'] ?? '',
        'teacherExperience':    teacherData['experience'] ?? '',
        'teacherQualification': teacherData['qualification'] ?? '',
        'teacherSubjects':      teacherData['subjects'] ?? [],
        'requestedAt':          DateTime.now().toIso8601String(),
        'status':               'pending',
      });

      // 2. Write into teacher's sent log
      await _dbRef
          .child('teacherSentRequests')
          .child(teacherEmailKey)
          .child(requestId)
          .set({
        'studentEmailKey': studentEmailKey,
        'studentName':     widget.studentData['fullName'] ?? 'Unknown Student',
        'studentClass':    widget.studentData['class'] ?? '',
        'requestedAt':     DateTime.now().toIso8601String(),
        'status':          'pending',
      });

      // 3. Look up the student's Firebase UID (stored when they logged in)
      //    then fire the push notification
      final studentSnapshot = await _dbRef.child('students').child(studentEmailKey).get();
      if (studentSnapshot.exists) {
        final studentRecord = Map<String, dynamic>.from(studentSnapshot.value as Map);
        final studentFirebaseUid = studentRecord['firebaseUid'] as String?;

        if (studentFirebaseUid != null) {
          await _sendPush(
            recipientFirebaseUid: studentFirebaseUid,
            title: 'New Request',
            body:  '${teacherData['fullName'] ?? 'A teacher'} sent you a request',
            data:  {'type': 'new_request'},
          );
        }
      }

      if (!mounted) return;
      setState(() => _hasRequestSent = true);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Request sent successfully!'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 2),
        ),
      );

      Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSendingRequest = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final subjects    = List<String>.from(widget.studentData['subjects'] ?? []);
    final hasSiblings = widget.studentData['siblingsWantToStudy'] == true;
    final siblingsData = List<Map<String, dynamic>>.from(
      widget.studentData['siblingsData'] ?? [],
    );

    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B4513),
        title: const Text(
          'Student Details',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Student Info Card
          Card(
            elevation: 3,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFF8E7),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.person_outline, color: Color(0xFF8B4513), size: 36),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              widget.studentData['fullName'] ?? 'Unknown',
                              style: const TextStyle(
                                fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF8B4513),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              widget.studentData['class'] ?? '',
                              style: TextStyle(fontSize: 15, color: Colors.brown.shade600),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  _buildInfoRow(icon: Icons.location_city_outlined, label: 'City',           value: widget.studentData['city'] ?? 'N/A'),
                  const SizedBox(height: 12),
                  _buildInfoRow(icon: Icons.phone_outlined,          label: 'Phone',          value: _maskPhoneNumber(widget.studentData['phoneNumber'] ?? '')),
                  const SizedBox(height: 12),
                  _buildInfoRow(icon: Icons.person_outline,          label: "Father's Name",  value: widget.studentData['fatherName'] ?? 'N/A'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Subjects Card
          Card(
            elevation: 3,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.menu_book_outlined, color: Color(0xFF8B4513), size: 24),
                      const SizedBox(width: 12),
                      const Text('Subjects', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF8B4513))),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(color: const Color(0xFFFFF8E7), borderRadius: BorderRadius.circular(8)),
                        child: Text('${subjects.length}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF8B4513))),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Wrap(
                    spacing: 8, runSpacing: 8,
                    children: subjects.map((s) => Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF8E7),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.brown.shade300),
                      ),
                      child: Text(s, style: TextStyle(fontSize: 13, color: Colors.brown.shade700, fontWeight: FontWeight.w500)),
                    )).toList(),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Budget & Time Card
          Card(
            elevation: 3,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(children: [
                    Icon(Icons.attach_money, color: Color(0xFF8B4513), size: 24),
                    SizedBox(width: 12),
                    Text('Budget & Time', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF8B4513))),
                  ]),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: const Color(0xFFFFF8E7), borderRadius: BorderRadius.circular(10)),
                    child: Column(children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Hourly Rate', style: TextStyle(fontSize: 14, color: Colors.brown.shade600)),
                          Text('${widget.studentData['hourlyPay'] ?? 'N/A'} PKR/hour',
                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF8B4513))),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Daily Hours', style: TextStyle(fontSize: 14, color: Colors.brown.shade600)),
                          Text('${widget.studentData['hoursPerDay'] ?? '0'}h ${widget.studentData['minutesPerDay'] ?? '0'}m',
                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF8B4513))),
                        ],
                      ),
                    ]),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Siblings Card
          Card(
            elevation: 3,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(children: [
                    Icon(Icons.people_outline, color: Color(0xFF8B4513), size: 24),
                    SizedBox(width: 12),
                    Text('Siblings', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF8B4513))),
                  ]),
                  const SizedBox(height: 16),
                  if (!hasSiblings)
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(color: const Color(0xFFFFF8E7), borderRadius: BorderRadius.circular(10)),
                      child: Row(children: [
                        Icon(Icons.info_outline, size: 20, color: Colors.brown.shade600),
                        const SizedBox(width: 12),
                        Text('No siblings want to study', style: TextStyle(fontSize: 14, color: Colors.brown.shade600)),
                      ]),
                    )
                  else
                    ...siblingsData.map((sibling) {
                      final siblingSubjects = List<String>.from(sibling['subjects'] ?? []);
                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFF8E7),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.brown.shade300),
                        ),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(sibling['name'] ?? 'Unknown',
                              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Color(0xFF8B4513))),
                          const SizedBox(height: 6),
                          Text(sibling['class'] ?? '', style: TextStyle(fontSize: 13, color: Colors.brown.shade600)),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 6, runSpacing: 6,
                            children: siblingSubjects.map((s) => Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(color: Colors.brown.shade300),
                              ),
                              child: Text(s, style: TextStyle(fontSize: 11, color: Colors.brown.shade700)),
                            )).toList(),
                          ),
                        ]),
                      );
                    }),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Send Request / Already Sent
          if (_hasRequestSent)
            Container(
              width: double.infinity, height: 54,
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.green.shade200, width: 2),
              ),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.check_circle, color: Colors.green.shade700, size: 24),
                const SizedBox(width: 12),
                Text('Request Already Sent',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.green.shade700)),
              ]),
            )
          else
            SizedBox(
              width: double.infinity, height: 54,
              child: ElevatedButton(
                onPressed: _isSendingRequest ? null : _sendRequest,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF8B4513),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  elevation: 3,
                ),
                child: _isSendingRequest
                    ? const SizedBox(height: 24, width: 24,
                        child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                    : const Text('Send Request',
                        style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.white)),
              ),
            ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildInfoRow({required IconData icon, required String label, required String value}) {
    return Row(children: [
      Icon(icon, size: 20, color: Colors.brown.shade600),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: TextStyle(fontSize: 12, color: Colors.brown.shade600)),
        const SizedBox(height: 2),
        Text(value, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Color(0xFF8B4513))),
      ])),
    ]);
  }
}
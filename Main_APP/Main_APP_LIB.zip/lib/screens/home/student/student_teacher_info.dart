import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

// ── Your OneSignal credentials ─────────────────────────────────────────────
const _kOneSignalAppId      = 'your-onesignal-app-id'; // Dashboard → Settings → Keys & IDs
const _kOneSignalRestApiKey = 'YOUR_ONESIGNAL_REST_API_KEY'; // Dashboard → Settings → Keys & IDs
// ──────────────────────────────────────────────────────────────────────────

class StudentTeacherInfo extends StatefulWidget {
  final Map<String, dynamic> teacherData;

  const StudentTeacherInfo({
    super.key,
    required this.teacherData,
  });

  @override
  State<StudentTeacherInfo> createState() => _StudentTeacherInfoState();
}

class _StudentTeacherInfoState extends State<StudentTeacherInfo> {
  bool _isSendingRequest = false;
  bool _hasRequestSent   = false;
  final _dbRef = FirebaseDatabase.instance.ref();

  @override
  void initState() {
    super.initState();
    _checkIfRequestSent();
  }

  Future<void> _checkIfRequestSent() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final studentEmailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');
      final teacherEmailKey = widget.teacherData['key'];

      final snapshot = await _dbRef.child('studentSentRequests').child(studentEmailKey).get();
      if (snapshot.exists) {
        final data = Map<String, dynamic>.from(snapshot.value as Map);
        bool found = false;
        data.forEach((key, value) {
          final request = Map<String, dynamic>.from(value as Map);
          if (request['teacherEmailKey'] == teacherEmailKey) found = true;
        });
        setState(() => _hasRequestSent = found);
      }
    } catch (_) {}
  }

  String _maskPhoneNumber(String phone) {
    if (phone.length < 4) return phone;
    final start  = phone.substring(0, 4);
    final end    = phone.substring(phone.length - 1);
    final masked = '*' * (phone.length - 5);
    return '$start$masked$end';
  }

  String _getExperienceText() {
    final years  = int.tryParse(widget.teacherData['experienceYears']?.toString()  ?? '0') ?? 0;
    final months = int.tryParse(widget.teacherData['experienceMonths']?.toString() ?? '0') ?? 0;
    if (years == 0 && months == 0) return 'New to teaching';
    if (years  == 0) return '$months month${months > 1 ? 's' : ''} of experience';
    if (months == 0) return '$years year${years > 1 ? 's' : ''} of experience';
    return '$years year${years > 1 ? 's' : ''} and $months month${months > 1 ? 's' : ''} of experience';
  }

  /// Sends a OneSignal push to [recipientFirebaseUid].
  Future<void> _sendPush({
    required String recipientFirebaseUid,
    required String title,
    required String body,
    Map<String, String> data = const {},
  }) async {
    try {
      await http.post(
        Uri.parse('https://onesignal.com/api/v1/notifications'),
        headers: {
          'Content-Type':  'application/json',
          'Authorization': 'Basic $_kOneSignalRestApiKey',
        },
        body: jsonEncode({
          'app_id':          _kOneSignalAppId,
          'include_aliases': {'external_id': [recipientFirebaseUid]},
          'target_channel':  'push',
          'headings':        {'en': title},
          'contents':        {'en': body},
          'data':            data,
        }),
      );
    } catch (_) {
      // Notification failure is non-fatal — request was already saved
    }
  }

  Future<void> _sendRequest() async {
    setState(() => _isSendingRequest = true);

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('Not authenticated');

      final studentEmailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');
      final teacherEmailKey = widget.teacherData['key'] as String;

      // Fetch student data
      final studentSnapshot = await _dbRef.child('students').child(studentEmailKey).get();
      if (!studentSnapshot.exists) throw Exception('Student data not found');
      final studentData = Map<String, dynamic>.from(studentSnapshot.value as Map);

      final requestId = '${DateTime.now().millisecondsSinceEpoch}';

      // 1. Write request into teacher's inbox
      await _dbRef
          .child('teacherRequests')
          .child(teacherEmailKey)
          .child(requestId)
          .set({
        'studentEmailKey':       studentEmailKey,
        'studentName':           studentData['fullName'] ?? 'Unknown Student',
        'studentEmail':          user.email,
        'studentPhone':          studentData['phoneNumber'] ?? '',
        'studentClass':          studentData['class'] ?? '',
        'studentSubjects':       studentData['subjects'] ?? [],
        'studentCity':           studentData['city'] ?? '',
        'studentHourlyPay':      studentData['hourlyPay'] ?? '',
        'studentHoursPerDay':    studentData['hoursPerDay'] ?? '',
        'studentMinutesPerDay':  studentData['minutesPerDay'] ?? '',
        'hasSiblings':           studentData['siblingsWantToStudy'] ?? false,
        'siblingsData':          studentData['siblingsData'] ?? [],
        'requestedAt':           DateTime.now().toIso8601String(),
        'status':                'pending',
      });

      // 2. Write into student's sent log
      await _dbRef
          .child('studentSentRequests')
          .child(studentEmailKey)
          .child(requestId)
          .set({
        'teacherEmailKey':   teacherEmailKey,
        'teacherName':       widget.teacherData['fullName'] ?? 'Unknown Teacher',
        'teacherSubjects':   widget.teacherData['subjects'] ?? [],
        'teacherExperience': '${widget.teacherData['experienceYears'] ?? '0'} years',
        'requestedAt':       DateTime.now().toIso8601String(),
        'status':            'pending',
      });

      // 3. Look up the teacher's Firebase UID then fire the push notification
      final teacherSnapshot = await _dbRef.child('teachers').child(teacherEmailKey).get();
      if (teacherSnapshot.exists) {
        final teacherRecord      = Map<String, dynamic>.from(teacherSnapshot.value as Map);
        final teacherFirebaseUid = teacherRecord['firebaseUid'] as String?;

        if (teacherFirebaseUid != null) {
          await _sendPush(
            recipientFirebaseUid: teacherFirebaseUid,
            title: 'New Request',
            body:  '${studentData['fullName'] ?? 'A student'} sent you a request',
            data:  {'type': 'new_request'},
          );
        }
      }

      if (!mounted) return;
      setState(() => _hasRequestSent = true);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Request sent successfully!'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 2),
        ),
      );

      Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSendingRequest = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final subjects       = List<String>.from(widget.teacherData['subjects'] ?? []);
    final degrees        = List<String>.from(widget.teacherData['degrees']  ?? []);
    final profileImageUrl = widget.teacherData['profileImageUrl'];

    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B4513),
        title: const Text('Teacher Details',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Teacher Info Card
          Card(
            elevation: 3,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 70, height: 70,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xFFFFF8E7),
                          border: Border.all(color: const Color(0xFF8B4513), width: 3),
                        ),
                        child: ClipOval(
                          child: profileImageUrl != null
                              ? Image.network(profileImageUrl, fit: BoxFit.cover, width: 70, height: 70,
                                  loadingBuilder: (_, child, progress) =>
                                      progress == null ? child : const Center(child: CircularProgressIndicator(color: Color(0xFF8B4513), strokeWidth: 2)),
                                  errorBuilder: (_, __, ___) => const Icon(Icons.person, size: 36, color: Color(0xFF8B4513)))
                              : const Icon(Icons.person, size: 36, color: Color(0xFF8B4513)),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(widget.teacherData['fullName'] ?? 'Unknown',
                              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF8B4513))),
                          const SizedBox(height: 4),
                          Text(_getExperienceText(),
                              style: TextStyle(fontSize: 14, color: Colors.brown.shade600)),
                        ]),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  _buildInfoRow(icon: Icons.location_city_outlined, label: 'City',          value: widget.teacherData['city'] ?? 'N/A'),
                  const SizedBox(height: 12),
                  _buildInfoRow(icon: Icons.phone_outlined,          label: 'Phone',         value: _maskPhoneNumber(widget.teacherData['phoneNumber'] ?? '')),
                  const SizedBox(height: 12),
                  _buildInfoRow(icon: Icons.cake_outlined,           label: 'Date of Birth', value: widget.teacherData['dateOfBirth'] ?? 'N/A'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Subjects Card
          Card(
            elevation: 3,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    const Icon(Icons.menu_book_outlined, color: Color(0xFF8B4513), size: 24),
                    const SizedBox(width: 12),
                    const Text('Teaching Subjects', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF8B4513))),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(color: const Color(0xFFFFF8E7), borderRadius: BorderRadius.circular(8)),
                      child: Text('${subjects.length}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF8B4513))),
                    ),
                  ]),
                  const SizedBox(height: 16),
                  Wrap(
                    spacing: 8, runSpacing: 8,
                    children: subjects.map((s) => Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF8E7),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.brown.shade300),
                      ),
                      child: Text(s, style: TextStyle(fontSize: 13, color: Colors.brown.shade700, fontWeight: FontWeight.w500)),
                    )).toList(),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Qualifications Card
          Card(
            elevation: 3,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    const Icon(Icons.school_outlined, color: Color(0xFF8B4513), size: 24),
                    const SizedBox(width: 12),
                    const Text('Qualifications', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF8B4513))),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(color: const Color(0xFFFFF8E7), borderRadius: BorderRadius.circular(8)),
                      child: Text('${degrees.length}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF8B4513))),
                    ),
                  ]),
                  const SizedBox(height: 16),
                  ...degrees.map((degree) => Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF8E7),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.brown.shade300),
                    ),
                    child: Row(children: [
                      Icon(Icons.check_circle_outline, size: 18, color: Colors.brown.shade600),
                      const SizedBox(width: 10),
                      Expanded(child: Text(degree, style: TextStyle(fontSize: 13, color: Colors.brown.shade700))),
                    ]),
                  )),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Pricing Card
          Card(
            elevation: 3,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(children: [
                    Icon(Icons.attach_money, color: Color(0xFF8B4513), size: 24),
                    SizedBox(width: 12),
                    Text('Pricing & Availability', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF8B4513))),
                  ]),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: const Color(0xFFFFF8E7), borderRadius: BorderRadius.circular(10)),
                    child: Column(children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Monthly Charge', style: TextStyle(fontSize: 14, color: Colors.brown.shade600)),
                          Text('Rs ${widget.teacherData['chargePerStudent'] ?? 'N/A'}/student',
                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF8B4513))),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Daily Hours', style: TextStyle(fontSize: 14, color: Colors.brown.shade600)),
                          Text('${widget.teacherData['hoursPerDay'] ?? '0'}h ${widget.teacherData['minutesPerDay'] ?? '0'}m',
                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF8B4513))),
                        ],
                      ),
                    ]),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Send Request / Already Sent
          if (_hasRequestSent)
            Container(
              width: double.infinity, height: 54,
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.green.shade200, width: 2),
              ),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.check_circle, color: Colors.green.shade700, size: 24),
                const SizedBox(width: 12),
                Text('Request Already Sent',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.green.shade700)),
              ]),
            )
          else
            SizedBox(
              width: double.infinity, height: 54,
              child: ElevatedButton(
                onPressed: _isSendingRequest ? null : _sendRequest,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF8B4513),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  elevation: 3,
                ),
                child: _isSendingRequest
                    ? const SizedBox(height: 24, width: 24,
                        child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                    : const Text('Send Request',
                        style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.white)),
              ),
            ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildInfoRow({required IconData icon, required String label, required String value}) {
    return Row(children: [
      Icon(icon, size: 20, color: Colors.brown.shade600),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: TextStyle(fontSize: 12, color: Colors.brown.shade600)),
        const SizedBox(height: 2),
        Text(value, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Color(0xFF8B4513))),
      ])),
    ]);
  }
}
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'dart:convert';

class AccountPageStudent extends StatefulWidget {
  const AccountPageStudent({super.key});

  @override
  State<AccountPageStudent> createState() => _AccountPageStudentState();
}

class _AccountPageStudentState extends State<AccountPageStudent> {
  Map<String, dynamic>? _studentData;
  bool _isLoading = true;
  String? _profileImageBase64; // base64 string
  final ImagePicker _picker = ImagePicker();
  bool _isUploadingImage = false;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    await _loadStudentData();
  }

  Future<void> _loadStudentData() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final emailKey =
          user.email!.replaceAll('.', '_').replaceAll('@', '_at_');

      // Load profile info from Realtime DB
      final snapshot = await FirebaseDatabase.instance
          .ref()
          .child('students')
          .child(emailKey)
          .get();

      // Load base64 image from Firestore
      final firestoreDoc = await FirebaseFirestore.instance
          .collection('profile_images')
          .doc(emailKey)
          .get();

      if (mounted) {
        setState(() {
          if (snapshot.exists) {
            _studentData =
                Map<String, dynamic>.from(snapshot.value as Map);
          }
          if (firestoreDoc.exists) {
            _profileImageBase64 = firestoreDoc.data()?['imageBase64'];
          }
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message,
            style: const TextStyle(color: Colors.white, fontSize: 14)),
        backgroundColor:
            isError ? Colors.red.shade700 : Colors.green.shade700,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  /// Compress + convert image to base64. Keeps size small for Firestore.
  Future<String> _imageToBase64(XFile xfile) async {
    final bytes = await File(xfile.path).readAsBytes();
    return base64Encode(bytes);
  }

  Future<void> _saveImageToFirestore(String base64String) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final emailKey =
        user.email!.replaceAll('.', '_').replaceAll('@', '_at_');

    await FirebaseFirestore.instance
        .collection('profile_images')
        .doc(emailKey)
        .set({
      'imageBase64': base64String,
      'updatedAt': FieldValue.serverTimestamp(),
      'role': 'student',
    });
  }

  Future<void> _deleteImageFromFirestore() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final emailKey =
        user.email!.replaceAll('.', '_').replaceAll('@', '_at_');

    await FirebaseFirestore.instance
        .collection('profile_images')
        .doc(emailKey)
        .delete();
  }

  Future<void> _pickImage() async {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const Text(
              'Update Profile Photo',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF8B4513),
              ),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF8E7),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.camera_alt, color: Color(0xFF8B4513)),
              ),
              title: const Text('Take a Photo'),
              subtitle: const Text('Use your camera'),
              onTap: () async {
                Navigator.pop(context);
                await _handleImagePick(ImageSource.camera);
              },
            ),
            const SizedBox(height: 8),
            ListTile(
              leading: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF8E7),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.photo_library,
                    color: Color(0xFF8B4513)),
              ),
              title: const Text('Choose from Gallery'),
              subtitle: const Text('Select an existing photo'),
              onTap: () async {
                Navigator.pop(context);
                await _handleImagePick(ImageSource.gallery);
              },
            ),
            if (_profileImageBase64 != null) ...[
              const SizedBox(height: 8),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.red.shade50,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child:
                      const Icon(Icons.delete_outline, color: Colors.red),
                ),
                title: const Text('Remove Photo',
                    style: TextStyle(color: Colors.red)),
                subtitle: const Text('Delete current photo'),
                onTap: () async {
                  Navigator.pop(context);
                  await _deleteProfilePicture();
                },
              ),
            ],
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Future<void> _handleImagePick(ImageSource source) async {
    try {
      // Low quality + small dimensions to keep base64 under 1MB
      final XFile? image = await _picker.pickImage(
        source: source,
        imageQuality: 50,
        maxWidth: 400,
        maxHeight: 400,
      );

      if (image == null) return;

      setState(() => _isUploadingImage = true);

      if (mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => WillPopScope(
            onWillPop: () async => false,
            child: const Center(
              child: Card(
                margin: EdgeInsets.all(20),
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CircularProgressIndicator(color: Color(0xFF8B4513)),
                      SizedBox(height: 16),
                      Text('Saving...', style: TextStyle(fontSize: 16)),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      }

      final base64Str = await _imageToBase64(image);
      await _saveImageToFirestore(base64Str);

      if (mounted) Navigator.pop(context);

      setState(() {
        _profileImageBase64 = base64Str;
        _isUploadingImage = false;
      });

      _showSnackBar('Profile picture updated successfully!');
    } catch (e) {
      if (mounted) Navigator.of(context, rootNavigator: true).pop();
      setState(() => _isUploadingImage = false);
      _showSnackBar('Failed to upload image', isError: true);
    }
  }

  Future<void> _deleteProfilePicture() async {
    try {
      setState(() => _isUploadingImage = true);
      await _deleteImageFromFirestore();
      setState(() {
        _profileImageBase64 = null;
        _isUploadingImage = false;
      });
      _showSnackBar('Profile picture removed');
    } catch (e) {
      setState(() => _isUploadingImage = false);
      _showSnackBar('Failed to remove picture', isError: true);
    }
  }

  Future<void> _logout() async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child:
                const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              await FirebaseAuth.instance.signOut();
              if (mounted) {
                Navigator.of(context)
                    .pushNamedAndRemoveUntil('/', (route) => false);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
            ),
            child:
                const Text('Logout', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Widget _buildAvatar() {
    return Container(
      width: 100,
      height: 100,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 3),
        color: Colors.white,
      ),
      child: ClipOval(
        child: _isUploadingImage
            ? const Center(
                child: CircularProgressIndicator(
                  color: Color(0xFF8B4513),
                  strokeWidth: 2,
                ),
              )
            : _profileImageBase64 != null
                ? Image.memory(
                    base64Decode(_profileImageBase64!),
                    fit: BoxFit.cover,
                    width: 100,
                    height: 100,
                    errorBuilder: (_, __, ___) => const Icon(
                      Icons.person,
                      size: 50,
                      color: Color(0xFF8B4513),
                    ),
                  )
                : const Icon(
                    Icons.person,
                    size: 50,
                    color: Color(0xFF8B4513),
                  ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B4513),
        automaticallyImplyLeading: false,
        title: const Text(
          'My Account',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        elevation: 0,
        centerTitle: true,
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF8B4513)))
          : RefreshIndicator(
              onRefresh: _loadData,
              color: const Color(0xFF8B4513),
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                child: Column(
                  children: [
                    // ── Header ──
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(24),
                      decoration: const BoxDecoration(
                        color: Color(0xFF8B4513),
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(30),
                          bottomRight: Radius.circular(30),
                        ),
                      ),
                      child: Column(
                        children: [
                          GestureDetector(
                            onTap: _isUploadingImage ? null : _pickImage,
                            child: Stack(
                              children: [
                                _buildAvatar(),
                                if (!_isUploadingImage)
                                  Positioned(
                                    bottom: 0,
                                    right: 0,
                                    child: Container(
                                      padding: const EdgeInsets.all(6),
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        shape: BoxShape.circle,
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.black
                                                .withOpacity(0.2),
                                            blurRadius: 4,
                                          ),
                                        ],
                                      ),
                                      child: const Icon(Icons.camera_alt,
                                          size: 18,
                                          color: Color(0xFF8B4513)),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                          if (_profileImageBase64 == null &&
                              !_isUploadingImage)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: Colors.orange.shade100,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.info_outline,
                                      size: 16, color: Colors.orange),
                                  SizedBox(width: 6),
                                  Text(
                                    'Tap to add a profile photo',
                                    style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.orange,
                                        fontWeight: FontWeight.w500),
                                  ),
                                ],
                              ),
                            ),
                          const SizedBox(height: 12),
                          Text(
                            _studentData?['fullName'] ?? 'Student',
                            style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                FirebaseAuth.instance.currentUser?.email ??
                                    '',
                                style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.white.withOpacity(0.8)),
                              ),
                              const SizedBox(width: 6),
                              Tooltip(
                                message:
                                    'Your email won\'t be revealed to anyone',
                                child: Icon(Icons.info_outline,
                                    size: 16,
                                    color: Colors.white.withOpacity(0.8)),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 24),

                    // ── Settings ──
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Settings',
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF8B4513)),
                          ),
                          const SizedBox(height: 16),
                          InkWell(
                            onTap: _logout,
                            borderRadius: BorderRadius.circular(16),
                            child: Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.05),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      color: Colors.red.shade50,
                                      borderRadius:
                                          BorderRadius.circular(12),
                                    ),
                                    child: const Icon(Icons.logout,
                                        color: Colors.red, size: 22),
                                  ),
                                  const SizedBox(width: 16),
                                  const Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text('Logout',
                                            style: TextStyle(
                                                fontSize: 15,
                                                fontWeight: FontWeight.w600,
                                                color: Colors.red)),
                                        SizedBox(height: 4),
                                        Text('Log out of your account',
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.grey)),
                                      ],
                                    ),
                                  ),
                                  const Icon(Icons.arrow_forward_ios,
                                      size: 16, color: Colors.grey),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
    );
  }
}
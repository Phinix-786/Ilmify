import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

const _kOneSignalAppId      = 'your-onesignal-app-id';
const _kOneSignalRestApiKey = 'YOUR_ONESIGNAL_REST_API_KEY';

class RequestsStudent extends StatefulWidget {
  const RequestsStudent({super.key});

  @override
  State<RequestsStudent> createState() => _RequestsStudentState();
}

class _RequestsStudentState extends State<RequestsStudent> {
  final _dbRef = FirebaseDatabase.instance.ref();
  String _studentEmailKey = '';

  @override
  void initState() {
    super.initState();
    _loadStudentKey();
  }

  void _loadStudentKey() {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      setState(() {
        _studentEmailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');
      });
    }
  }

  // Combined stream for all requests
  Stream<List<Map<String, dynamic>>> _getAllRequestsStream() {
    if (_studentEmailKey.isEmpty) {
      return Stream.value([]);
    }

    return Stream.value([]).asyncMap((_) async {
      final List<Map<String, dynamic>> allRequests = [];

      try {
        // Get received requests (from teachers)
        final receivedSnapshot = await _dbRef
            .child('studentRequests')
            .child(_studentEmailKey)
            .get();

        if (receivedSnapshot.exists) {
          final data = Map<String, dynamic>.from(receivedSnapshot.value as Map);
          data.forEach((key, value) {
            final requestData = Map<String, dynamic>.from(value as Map);
            allRequests.add({
              'requestId': key,
              'type': 'received', // received from teacher
              ...requestData,
            });
          });
        }

        // Get sent requests (to teachers)
        final sentSnapshot = await _dbRef
            .child('studentSentRequests')
            .child(_studentEmailKey)
            .get();

        if (sentSnapshot.exists) {
          final data = Map<String, dynamic>.from(sentSnapshot.value as Map);
          data.forEach((key, value) {
            final requestData = Map<String, dynamic>.from(value as Map);
            allRequests.add({
              'requestId': key,
              'type': 'sent', // sent to teacher
              ...requestData,
            });
          });
        }

        // Sort by status (pending first), then by date (newest first)
        allRequests.sort((a, b) {
          final statusA = a['status'] ?? 'pending';
          final statusB = b['status'] ?? 'pending';
          
          // Pending comes before accepted/rejected
          if (statusA == 'pending' && statusB != 'pending') return -1;
          if (statusA != 'pending' && statusB == 'pending') return 1;
          
          // If same status, sort by date (newest first)
          return b['requestedAt'].compareTo(a['requestedAt']);
        });
      } catch (e) {
        print('Error fetching requests: $e');
      }

      return allRequests;
    }).asBroadcastStream();
  }

  Future<void> _sendPush({
    required String recipientOneSignalId,
    required String title,
    required String body,
    String type = 'request_accepted',
  }) async {
    try {
      await http.post(
        Uri.parse('https://onesignal.com/api/v1/notifications'),
        headers: {
          'Content-Type':  'application/json',
          'Authorization': 'Basic $_kOneSignalRestApiKey',
        },
        body: jsonEncode({
          'app_id':                   _kOneSignalAppId,
          'include_subscription_ids': [recipientOneSignalId],
          'headings':                 {'en': title},
          'contents':                 {'en': body},
          'data':                     {'type': type},
        }),
      );
    } catch (_) {}
  }

  Future<void> _handleReceivedRequest(String requestId, String teacherEmailKey, bool accept) async {
    try {
      final status = accept ? 'accepted' : 'rejected';
      
      await _dbRef
          .child('studentRequests')
          .child(_studentEmailKey)
          .child(requestId)
          .update({'status': status});
      
      await _dbRef
          .child('teacherSentRequests')
          .child(teacherEmailKey)
          .child(requestId)
          .update({'status': status});

      // Notify the teacher
      final teacherSnap = await _dbRef.child('teachers').child(teacherEmailKey).get();
      if (teacherSnap.exists) {
        final teacherRecord = Map<String, dynamic>.from(teacherSnap.value as Map);
        final osId = teacherRecord['oneSignalId'] as String?;
        if (osId != null) {
          final studentSnap = await _dbRef.child('students').child(_studentEmailKey).get();
          final studentName = studentSnap.exists
              ? (Map<String, dynamic>.from(studentSnap.value as Map)['fullName'] ?? 'A student')
              : 'A student';
          await _sendPush(
            recipientOneSignalId: osId,
            title: accept ? 'Request Accepted' : 'Request Rejected',
            body:  accept
                ? '$studentName accepted your request!'
                : '$studentName rejected your request.',
            type: accept ? 'request_accepted' : 'request_rejected',
          );
        }
      }
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(accept ? 'Request accepted!' : 'Request rejected'),
            backgroundColor: accept ? Colors.green : Colors.orange,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _cancelSentRequest(String requestId, String teacherEmailKey) async {
    try {
      await _dbRef
          .child('studentSentRequests')
          .child(_studentEmailKey)
          .child(requestId)
          .remove();
      
      await _dbRef
          .child('teacherRequests')
          .child(teacherEmailKey)
          .child(requestId)
          .remove();
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Request cancelled'),
            backgroundColor: Colors.orange,
            duration: Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  String _formatDateTime(String isoString) {
    try {
      final dateTime = DateTime.parse(isoString);
      final now = DateTime.now();
      final difference = now.difference(dateTime);

      if (difference.inDays == 0) {
        if (difference.inHours == 0) {
          return '${difference.inMinutes} min ago';
        }
        return '${difference.inHours}h ago';
      } else if (difference.inDays == 1) {
        return 'Yesterday';
      } else if (difference.inDays < 7) {
        return '${difference.inDays} days ago';
      } else {
        return '${dateTime.day}/${dateTime.month}/${dateTime.year}';
      }
    } catch (e) {
      return 'Recently';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B4513),
        automaticallyImplyLeading: false,
        title: const Text(
          'Requests',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        elevation: 0,
        centerTitle: true,
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: _getAllRequestsStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(color: Color(0xFF8B4513)),
            );
          }

          if (snapshot.hasError) {
            return Center(
              child: Text(
                'Error loading requests',
                style: TextStyle(color: Colors.brown.shade600),
              ),
            );
          }

          final requests = snapshot.data ?? [];

          if (requests.isEmpty) {
            return _buildEmptyState();
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: requests.length,
            itemBuilder: (context, index) {
              final request = requests[index];
              return _buildRequestCard(request);
            },
          );
        },
      ),
    );
  }

  Widget _buildRequestCard(Map<String, dynamic> request) {
    final type = request['type']; // 'received' or 'sent'
    final status = request['status'] ?? 'pending';
    final subjects = List<String>.from(request['teacherSubjects'] ?? []);
    final isReceived = type == 'received';

    // Determine card color based on type and status
    Color borderColor;
    Color headerColor;
    String actionText;

    if (isReceived) {
      // Received requests (from teachers)
      if (status == 'accepted') {
        borderColor = Colors.green.shade300;
        headerColor = Colors.green.shade50;
        actionText = '${request['teacherName']} sent you request';
      } else if (status == 'pending') {
        borderColor = Colors.green.shade300;
        headerColor = Colors.green.shade50;
        actionText = '${request['teacherName']} sent you request';
      } else {
        borderColor = Colors.grey.shade300;
        headerColor = Colors.grey.shade50;
        actionText = '${request['teacherName']} sent you request';
      }
    } else {
      // Sent requests (to teachers)
      if (status == 'accepted') {
        borderColor = Colors.green.shade300;
        headerColor = Colors.green.shade50;
        actionText = 'You sent request to ${request['teacherName']}';
      } else {
        borderColor = Colors.yellow.shade600;
        headerColor = Colors.yellow.shade50;
        actionText = 'You sent request to ${request['teacherName']}';
      }
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: borderColor, width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with colored background
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: headerColor,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(10),
                topRight: Radius.circular(10),
              ),
            ),
            child: Row(
              children: [
                Icon(
                  isReceived ? Icons.call_received : Icons.call_made,
                  size: 16,
                  color: status == 'accepted' 
                      ? Colors.green.shade700 
                      : (isReceived ? Colors.green.shade700 : Colors.yellow.shade900),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    actionText,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: status == 'accepted'
                          ? Colors.green.shade700
                          : (isReceived ? Colors.green.shade700 : Colors.yellow.shade900),
                    ),
                  ),
                ),
                _buildStatusBadge(status),
              ],
            ),
          ),
          
          // Content
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF8E7),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(
                        Icons.person_outline,
                        color: Color(0xFF8B4513),
                        size: 24,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            request['teacherName'] ?? 'Unknown',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF8B4513),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            request['teacherExperience'] ?? 'Teacher',
                            style: TextStyle(
                              fontSize: 13,
                              color: Colors.brown.shade600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                if (subjects.isNotEmpty) ...[
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: subjects.take(3).map((subject) {
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFF8E7),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: Colors.brown.shade300),
                        ),
                        child: Text(
                          subject,
                          style: TextStyle(
                            fontSize: 11,
                            color: Colors.brown.shade700,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 12),
                ],
                Row(
                  children: [
                    Icon(Icons.access_time, size: 14, color: Colors.grey.shade600),
                    const SizedBox(width: 4),
                    Text(
                      _formatDateTime(request['requestedAt'] ?? ''),
                      style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                    ),
                  ],
                ),
                if (status == 'pending') ...[
                  const SizedBox(height: 12),
                  if (isReceived)
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => _handleReceivedRequest(
                              request['requestId'],
                              request['teacherEmailKey'],
                              false,
                            ),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.red,
                              side: const BorderSide(color: Colors.red, width: 1.5),
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: const Text('Reject', style: TextStyle(fontSize: 14)),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          flex: 2,
                          child: ElevatedButton(
                            onPressed: () => _handleReceivedRequest(
                              request['requestId'],
                              request['teacherEmailKey'],
                              true,
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: const Text(
                              'Accept',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ],
                    )
                  else
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton(
                        onPressed: () => _cancelSentRequest(
                          request['requestId'],
                          request['teacherEmailKey'],
                        ),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.red,
                          side: const BorderSide(color: Colors.red, width: 1.5),
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: const Text('Cancel Request', style: TextStyle(fontSize: 14)),
                      ),
                    ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusBadge(String status) {
    Color bgColor;
    Color borderColor;
    Color textColor;
    String label;

    switch (status) {
      case 'accepted':
        bgColor = Colors.green.shade50;
        borderColor = Colors.green.shade200;
        textColor = Colors.green.shade700;
        label = 'Accepted';
        break;
      case 'rejected':
        bgColor = Colors.red.shade50;
        borderColor = Colors.red.shade200;
        textColor = Colors.red.shade700;
        label = 'Rejected';
        break;
      default:
        bgColor = Colors.orange.shade50;
        borderColor = Colors.orange.shade200;
        textColor = Colors.orange.shade700;
        label = 'Pending';
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: borderColor),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: textColor,
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(32),
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.brown.shade200.withOpacity(0.3),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: const Icon(
                Icons.inbox_outlined,
                size: 80,
                color: Color(0xFF8B4513),
              ),
            ),
            const SizedBox(height: 32),
            const Text(
              'No Requests Yet',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color(0xFF8B4513),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Your requests will appear here',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 15,
                color: Colors.brown.shade600,
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
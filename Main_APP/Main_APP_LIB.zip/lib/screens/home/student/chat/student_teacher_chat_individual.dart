import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'teacher_chat_info.dart';

class StudentTeacherChatIndividual extends StatefulWidget {
  final Map<String, dynamic> teacherData;
  
  const StudentTeacherChatIndividual({
    super.key,
    required this.teacherData,
  });

  @override
  State<StudentTeacherChatIndividual> createState() => _StudentTeacherChatIndividualState();
}

class _StudentTeacherChatIndividualState extends State<StudentTeacherChatIndividual> {
  final _dbRef = FirebaseDatabase.instance.ref();
  String _studentEmailKey = '';
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _chatScrollController = ScrollController();
  String? _teacherProfileImageUrl;

  @override
  void initState() {
    super.initState();
    _loadStudentData();
    _loadTeacherProfileImage();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _chatScrollController.dispose();
    super.dispose();
  }

  Future<void> _loadStudentData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final emailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');
      
      try {
        final snapshot = await _dbRef.child('students').child(emailKey).get();
        if (snapshot.exists) {
          setState(() {
            _studentEmailKey = emailKey;
          });
        }
      } catch (e) {
        print('Error loading student data: $e');
        setState(() {
          _studentEmailKey = emailKey;
        });
      }
    }
  }

  Future<void> _loadTeacherProfileImage() async {
    try {
      final teacherEmailKey = widget.teacherData['teacherEmailKey'];
      final snapshot = await _dbRef
          .child('teachers')
          .child(teacherEmailKey)
          .child('profileImageUrl')
          .get();

      if (snapshot.exists && mounted) {
        setState(() {
          _teacherProfileImageUrl = snapshot.value?.toString();
        });
      }
    } catch (e) {
      print('Error loading teacher profile image: $e');
    }
  }

  Stream<List<Map<String, dynamic>>> _getChatMessagesStream(String teacherEmailKey) {
    if (_studentEmailKey.isEmpty || teacherEmailKey.isEmpty) {
      return Stream.value([]);
    }

    final chatId = _generateChatId(_studentEmailKey, teacherEmailKey);

    return _dbRef
        .child('chats')
        .child(chatId)
        .child('messages')
        .onValue
        .map((event) {
      final List<Map<String, dynamic>> messages = [];

      if (event.snapshot.value != null) {
        final data = Map<String, dynamic>.from(event.snapshot.value as Map);

        data.forEach((key, value) {
          final message = Map<String, dynamic>.from(value as Map);
          messages.add({
            'messageId': key,
            ...message,
          });
        });

        messages.sort((a, b) => 
          (a['timestamp'] ?? 0).compareTo(b['timestamp'] ?? 0));
      }

      return messages;
    }).asBroadcastStream();
  }

  String _generateChatId(String studentKey, String teacherKey) {
    final keys = [studentKey, teacherKey]..sort();
    return '${keys[0]}_${keys[1]}';
  }

  Future<void> _sendMessage() async {
    if (_messageController.text.trim().isEmpty) {
      return;
    }

    try {
      final chatId = _generateChatId(
        _studentEmailKey,
        widget.teacherData['teacherEmailKey'],
      );

      final messageRef = _dbRef
          .child('chats')
          .child(chatId)
          .child('messages')
          .push();

      await messageRef.set({
        'text': _messageController.text.trim(),
        'senderType': 'student',
        'senderEmailKey': _studentEmailKey,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
        'read': false,
      });

      await _dbRef.child('chats').child(chatId).update({
        'studentEmailKey': _studentEmailKey,
        'teacherEmailKey': widget.teacherData['teacherEmailKey'],
        'lastMessage': _messageController.text.trim(),
        'lastMessageTime': DateTime.now().millisecondsSinceEpoch,
        'lastMessageSender': 'student',
      });

      _messageController.clear();

      Future.delayed(const Duration(milliseconds: 100), () {
        if (_chatScrollController.hasClients) {
          _chatScrollController.animateTo(
            _chatScrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
          );
        }
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error sending message: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  String _formatMessageTime(int timestamp) {
    final dateTime = DateTime.fromMillisecondsSinceEpoch(timestamp);
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inDays == 0) {
      final hour = dateTime.hour;
      final minute = dateTime.minute.toString().padLeft(2, '0');
      final period = hour >= 12 ? 'PM' : 'AM';
      final displayHour = hour > 12 ? hour - 12 : (hour == 0 ? 12 : hour);
      return '$displayHour:$minute $period';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return '${dateTime.day}/${dateTime.month}/${dateTime.year}';
    }
  }

  @override
  Widget build(BuildContext context) {
    final profileImageUrl = _teacherProfileImageUrl ?? 
                           widget.teacherData['teacherProfileImage'];

    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B4513),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
              ),
              child: ClipOval(
                child: profileImageUrl != null &&
                        profileImageUrl.toString().isNotEmpty
                    ? Image.network(
                        profileImageUrl,
                        fit: BoxFit.cover,
                        width: 36,
                        height: 36,
                        loadingBuilder: (context, child, loadingProgress) {
                          if (loadingProgress == null) return child;
                          return Container(
                            color: Colors.white,
                            child: const Center(
                              child: SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(
                                  color: Color(0xFF8B4513),
                                  strokeWidth: 2,
                                ),
                              ),
                            ),
                          );
                        },
                        errorBuilder: (context, error, stackTrace) {
                          return Container(
                            color: Colors.white,
                            child: Center(
                              child: Text(
                                (widget.teacherData['teacherName'] ?? 'T')[0].toUpperCase(),
                                style: const TextStyle(
                                  color: Color(0xFF8B4513),
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          );
                        },
                      )
                    : Container(
                        color: Colors.white,
                        child: Center(
                          child: Text(
                            (widget.teacherData['teacherName'] ?? 'T')[0].toUpperCase(),
                            style: const TextStyle(
                              color: Color(0xFF8B4513),
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.teacherData['teacherName'] ?? 'Unknown',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    widget.teacherData['teacherExperience'] ?? '',
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.white70,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline, color: Colors.white),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => TeacherChatInfo(
                    teacherData: widget.teacherData,
                  ),
                ),
              );
            },
          ),
        ],
        elevation: 0,
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<List<Map<String, dynamic>>>(
              stream: _getChatMessagesStream(widget.teacherData['teacherEmailKey']),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: CircularProgressIndicator(color: Color(0xFF8B4513)),
                  );
                }

                final messages = snapshot.data ?? [];

                if (messages.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.message_outlined,
                          size: 64,
                          color: Colors.grey.shade400,
                        ),
                        const SizedBox(height: 20),
                        Text(
                          'No messages yet',
                          style: TextStyle(
                            fontSize: 17,
                            color: Colors.grey.shade600,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'Start the conversation!',
                          style: TextStyle(
                            fontSize: 15,
                            color: Colors.grey.shade500,
                          ),
                        ),
                      ],
                    ),
                  );
                }

                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (_chatScrollController.hasClients) {
                    _chatScrollController.animateTo(
                      _chatScrollController.position.maxScrollExtent,
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeOut,
                    );
                  }
                });

                return ListView.builder(
                  controller: _chatScrollController,
                  padding: const EdgeInsets.all(20),
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    final message = messages[index];
                    final isStudent = message['senderType'] == 'student';

                    return _buildMessageBubble(message, isStudent);
                  },
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 5,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF8E7),
                      borderRadius: BorderRadius.circular(26),
                      border: Border.all(color: Colors.brown.shade200),
                    ),
                    child: TextField(
                      controller: _messageController,
                      decoration: InputDecoration(
                        hintText: 'Type a message...',
                        hintStyle: TextStyle(color: Colors.grey.shade500, fontSize: 15),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 22,
                          vertical: 14,
                        ),
                      ),
                      maxLines: null,
                      textCapitalization: TextCapitalization.sentences,
                      onSubmitted: (_) => _sendMessage(),
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Container(
                  decoration: const BoxDecoration(
                    color: Color(0xFF8B4513),
                    shape: BoxShape.circle,
                  ),
                  child: IconButton(
                    icon: const Icon(Icons.send, color: Colors.white, size: 22),
                    onPressed: _sendMessage,
                    padding: const EdgeInsets.all(12),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(Map<String, dynamic> message, bool isStudent) {
    return Align(
      alignment: isStudent ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.65,
        ),
        child: Column(
          crossAxisAlignment:
              isStudent ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
              decoration: BoxDecoration(
                color: isStudent
                    ? const Color(0xFF8B4513)
                    : Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(18),
                  topRight: const Radius.circular(18),
                  bottomLeft: isStudent
                      ? const Radius.circular(18)
                      : const Radius.circular(4),
                  bottomRight: isStudent
                      ? const Radius.circular(4)
                      : const Radius.circular(18),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.06),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Text(
                message['text'] ?? '',
                style: TextStyle(
                  fontSize: 15,
                  color: isStudent ? Colors.white : Colors.black87,
                  height: 1.4,
                ),
              ),
            ),
            const SizedBox(height: 6),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Text(
                _formatMessageTime(message['timestamp'] ?? 0),
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
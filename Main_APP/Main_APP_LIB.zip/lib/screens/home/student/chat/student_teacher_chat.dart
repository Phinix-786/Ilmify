import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

const _kOneSignalAppId      = 'your-onesignal-app-id'; // Dashboard → Settings → Keys & IDs
const _kOneSignalRestApiKey = 'YOUR_ONESIGNAL_REST_API_KEY';

class StudentTeacherChatStudent extends StatefulWidget {
  const StudentTeacherChatStudent({super.key});

  @override
  State<StudentTeacherChatStudent> createState() => _StudentTeacherChatStudentState();
}

class _StudentTeacherChatStudentState extends State<StudentTeacherChatStudent> {
  final _dbRef = FirebaseDatabase.instance.ref();
  String _studentEmailKey = '';
  Map<String, dynamic>? _selectedTeacher;
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _chatScrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _loadStudentData();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _chatScrollController.dispose();
    super.dispose();
  }

  Future<void> _loadStudentData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final emailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');
      try {
        final snapshot = await _dbRef.child('students').child(emailKey).get();
        if (snapshot.exists) {
          setState(() => _studentEmailKey = emailKey);
        }
      } catch (e) {
        setState(() => _studentEmailKey = emailKey);
      }
    }
  }

  Stream<List<Map<String, dynamic>>> _getAcceptedTeachersStream() {
    if (_studentEmailKey.isEmpty) return Stream.value([]);

    return Stream.value([]).asyncMap((_) async {
      final List<Map<String, dynamic>> acceptedTeachers = [];
      final Set<String> addedTeachers = {};

      try {
        final receivedSnapshot = await _dbRef
            .child('studentRequests')
            .child(_studentEmailKey)
            .get();

        if (receivedSnapshot.exists) {
          final data = Map<String, dynamic>.from(receivedSnapshot.value as Map);
          data.forEach((key, value) {
            final request = Map<String, dynamic>.from(value as Map);
            if (request['status'] == 'accepted' &&
                !addedTeachers.contains(request['teacherEmailKey'])) {
              acceptedTeachers.add({
                'teacherName':         request['teacherName'],
                'teacherEmail':        request['teacherEmail'],
                'teacherEmailKey':     request['teacherEmailKey'],
                'teacherExperience':   request['teacherExperience'],
                'teacherProfileImage': request['teacherProfileImage'],
              });
              addedTeachers.add(request['teacherEmailKey']);
            }
          });
        }

        final sentSnapshot = await _dbRef
            .child('studentSentRequests')
            .child(_studentEmailKey)
            .get();

        if (sentSnapshot.exists) {
          final data = Map<String, dynamic>.from(sentSnapshot.value as Map);
          data.forEach((key, value) {
            final request = Map<String, dynamic>.from(value as Map);
            if (request['status'] == 'accepted' &&
                !addedTeachers.contains(request['teacherEmailKey'])) {
              acceptedTeachers.add({
                'teacherName':         request['teacherName'],
                'teacherEmail':        request['teacherEmail'],
                'teacherEmailKey':     request['teacherEmailKey'],
                'teacherExperience':   request['teacherExperience'],
                'teacherProfileImage': request['teacherProfileImage'],
              });
              addedTeachers.add(request['teacherEmailKey']);
            }
          });
        }

        acceptedTeachers.sort((a, b) =>
            (a['teacherName'] ?? '').compareTo(b['teacherName'] ?? ''));
      } catch (e) {
        print('Error fetching accepted teachers: $e');
      }

      return acceptedTeachers;
    }).asBroadcastStream();
  }

  Stream<List<Map<String, dynamic>>> _getChatMessagesStream(String teacherEmailKey) {
    if (_studentEmailKey.isEmpty || teacherEmailKey.isEmpty) return Stream.value([]);

    final chatId = _generateChatId(_studentEmailKey, teacherEmailKey);

    return _dbRef
        .child('chats')
        .child(chatId)
        .child('messages')
        .onValue
        .map((event) {
      final List<Map<String, dynamic>> messages = [];
      if (event.snapshot.value != null) {
        final data = Map<String, dynamic>.from(event.snapshot.value as Map);
        data.forEach((key, value) {
          messages.add({'messageId': key, ...Map<String, dynamic>.from(value as Map)});
        });
        messages.sort((a, b) => (a['timestamp'] ?? 0).compareTo(b['timestamp'] ?? 0));
      }
      return messages;
    }).asBroadcastStream();
  }

  String _generateChatId(String studentKey, String teacherKey) {
    final keys = [studentKey, teacherKey]..sort();
    return '${keys[0]}_${keys[1]}';
  }

  // ── Push notification helper ───────────────────────────────────────────────
  Future<void> _sendPush({
    required String recipientOneSignalId,
    required String title,
    required String body,
  }) async {
    try {
      await http.post(
        Uri.parse('https://onesignal.com/api/v1/notifications'),
        headers: {
          'Content-Type':  'application/json',
          'Authorization': 'Basic $_kOneSignalRestApiKey',
        },
        body: jsonEncode({
          'app_id':                   _kOneSignalAppId,
          'include_subscription_ids': [recipientOneSignalId],
          'headings':                 {'en': title},
          'contents':                 {'en': body},
          'data':                     {'type': 'chat_message'},
        }),
      );
    } catch (_) {
      // Non-fatal — message was already saved
    }
  }
  // ──────────────────────────────────────────────────────────────────────────

  Future<void> _sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty || _selectedTeacher == null) return;

    try {
      final chatId = _generateChatId(
        _studentEmailKey,
        _selectedTeacher!['teacherEmailKey'],
      );

      final messageRef = _dbRef.child('chats').child(chatId).child('messages').push();

      await messageRef.set({
        'text':           text,
        'senderType':     'student',
        'senderEmailKey': _studentEmailKey,
        'timestamp':      DateTime.now().millisecondsSinceEpoch,
        'read':           false,
      });

      await _dbRef.child('chats').child(chatId).update({
        'studentEmailKey':   _studentEmailKey,
        'teacherEmailKey':   _selectedTeacher!['teacherEmailKey'],
        'lastMessage':       text,
        'lastMessageTime':   DateTime.now().millisecondsSinceEpoch,
        'lastMessageSender': 'student',
      });

      _messageController.clear();

      // ── Notify the teacher ──────────────────────────────────────────────
      final teacherSnapshot = await _dbRef
          .child('teachers')
          .child(_selectedTeacher!['teacherEmailKey'])
          .get();

      if (teacherSnapshot.exists) {
        final teacherRecord = Map<String, dynamic>.from(teacherSnapshot.value as Map);
        final teacherOsId   = teacherRecord['oneSignalId'] as String?;

        if (teacherOsId != null) {
          // Get student's display name for the notification
          final studentSnapshot = await _dbRef.child('students').child(_studentEmailKey).get();
          final studentName = studentSnapshot.exists
              ? (Map<String, dynamic>.from(studentSnapshot.value as Map)['fullName'] ?? 'A student')
              : 'A student';

          await _sendPush(
            recipientOneSignalId: teacherOsId,
            title: studentName,
            body:  text,
          );
        }
      }
      // ───────────────────────────────────────────────────────────────────

      Future.delayed(const Duration(milliseconds: 100), () {
        if (_chatScrollController.hasClients) {
          _chatScrollController.animateTo(
            _chatScrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
          );
        }
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error sending message: ${e.toString()}'), backgroundColor: Colors.red),
        );
      }
    }
  }

  String _formatMessageTime(int timestamp) {
    final dateTime  = DateTime.fromMillisecondsSinceEpoch(timestamp);
    final now       = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inDays == 0) {
      final hour        = dateTime.hour;
      final minute      = dateTime.minute.toString().padLeft(2, '0');
      final period      = hour >= 12 ? 'PM' : 'AM';
      final displayHour = hour > 12 ? hour - 12 : (hour == 0 ? 12 : hour);
      return '$displayHour:$minute $period';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return '${dateTime.day}/${dateTime.month}/${dateTime.year}';
    }
  }

  @override
  Widget build(BuildContext context) {
    return _selectedTeacher == null ? _buildContactsList() : _buildChatScreen();
  }

  Widget _buildContactsList() {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B4513),
        automaticallyImplyLeading: false,
        title: const Text('Messages',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
        elevation: 0,
        centerTitle: true,
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: _getAcceptedTeachersStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: Color(0xFF8B4513)));
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error loading teachers', style: TextStyle(color: Colors.red.shade700)));
          }

          final teachers = snapshot.data ?? [];

          if (teachers.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(40),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(32),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        boxShadow: [BoxShadow(color: Colors.brown.shade200.withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 8))],
                      ),
                      child: const Icon(Icons.contacts_outlined, size: 80, color: Color(0xFF8B4513)),
                    ),
                    const SizedBox(height: 32),
                    const Text('No Teachers Yet', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFF8B4513))),
                    const SizedBox(height: 12),
                    Text('Accept teacher requests to start chatting',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 15, color: Colors.brown.shade600, height: 1.5)),
                  ],
                ),
              ),
            );
          }

          return ListView.builder(
            itemCount: teachers.length,
            itemBuilder: (context, index) {
              final teacher = teachers[index];
              return InkWell(
                onTap: () => setState(() => _selectedTeacher = teacher),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 28,
                        backgroundColor: const Color(0xFF8B4513),
                        backgroundImage: teacher['teacherProfileImage'] != null &&
                                teacher['teacherProfileImage'].toString().isNotEmpty
                            ? NetworkImage(teacher['teacherProfileImage'])
                            : null,
                        child: teacher['teacherProfileImage'] == null ||
                                teacher['teacherProfileImage'].toString().isEmpty
                            ? Text((teacher['teacherName'] ?? 'T')[0].toUpperCase(),
                                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20))
                            : null,
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(teacher['teacherName'] ?? 'Unknown',
                                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black87),
                                maxLines: 1, overflow: TextOverflow.ellipsis),
                            const SizedBox(height: 4),
                            Text(teacher['teacherExperience'] ?? '',
                                style: TextStyle(fontSize: 14, color: Colors.grey.shade600),
                                maxLines: 1, overflow: TextOverflow.ellipsis),
                          ],
                        ),
                      ),
                      Icon(Icons.chevron_right, color: Colors.grey.shade400),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildChatScreen() {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B4513),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => setState(() => _selectedTeacher = null),
        ),
        title: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: Colors.white,
              backgroundImage: _selectedTeacher!['teacherProfileImage'] != null &&
                      _selectedTeacher!['teacherProfileImage'].toString().isNotEmpty
                  ? NetworkImage(_selectedTeacher!['teacherProfileImage'])
                  : null,
              child: _selectedTeacher!['teacherProfileImage'] == null ||
                      _selectedTeacher!['teacherProfileImage'].toString().isEmpty
                  ? Text((_selectedTeacher!['teacherName'] ?? 'T')[0].toUpperCase(),
                      style: const TextStyle(color: Color(0xFF8B4513), fontWeight: FontWeight.bold, fontSize: 16))
                  : null,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_selectedTeacher!['teacherName'] ?? 'Unknown',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  Text(_selectedTeacher!['teacherExperience'] ?? '',
                      style: const TextStyle(fontSize: 12, color: Colors.white70),
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
          ],
        ),
        elevation: 0,
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<List<Map<String, dynamic>>>(
              stream: _getChatMessagesStream(_selectedTeacher!['teacherEmailKey']),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator(color: Color(0xFF8B4513)));
                }

                final messages = snapshot.data ?? [];

                if (messages.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.message_outlined, size: 64, color: Colors.grey.shade400),
                        const SizedBox(height: 20),
                        Text('No messages yet', style: TextStyle(fontSize: 17, color: Colors.grey.shade600)),
                        const SizedBox(height: 10),
                        Text('Start the conversation!', style: TextStyle(fontSize: 15, color: Colors.grey.shade500)),
                      ],
                    ),
                  );
                }

                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (_chatScrollController.hasClients) {
                    _chatScrollController.animateTo(
                      _chatScrollController.position.maxScrollExtent,
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeOut,
                    );
                  }
                });

                return ListView.builder(
                  controller: _chatScrollController,
                  padding: const EdgeInsets.all(20),
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    final message = messages[index];
                    return _buildMessageBubble(message, message['senderType'] == 'student');
                  },
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 5, offset: const Offset(0, -2))],
            ),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF8E7),
                      borderRadius: BorderRadius.circular(26),
                      border: Border.all(color: Colors.brown.shade200),
                    ),
                    child: TextField(
                      controller: _messageController,
                      decoration: InputDecoration(
                        hintText: 'Type a message...',
                        hintStyle: TextStyle(color: Colors.grey.shade500, fontSize: 15),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
                      ),
                      maxLines: null,
                      textCapitalization: TextCapitalization.sentences,
                      onSubmitted: (_) => _sendMessage(),
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Container(
                  decoration: const BoxDecoration(color: Color(0xFF8B4513), shape: BoxShape.circle),
                  child: IconButton(
                    icon: const Icon(Icons.send, color: Colors.white, size: 22),
                    onPressed: _sendMessage,
                    padding: const EdgeInsets.all(12),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(Map<String, dynamic> message, bool isStudent) {
    return Align(
      alignment: isStudent ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.65),
        child: Column(
          crossAxisAlignment: isStudent ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
              decoration: BoxDecoration(
                color: isStudent ? const Color(0xFF8B4513) : Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft:     const Radius.circular(18),
                  topRight:    const Radius.circular(18),
                  bottomLeft:  isStudent ? const Radius.circular(18) : const Radius.circular(4),
                  bottomRight: isStudent ? const Radius.circular(4)  : const Radius.circular(18),
                ),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 6, offset: const Offset(0, 2))],
              ),
              child: Text(message['text'] ?? '',
                  style: TextStyle(fontSize: 15, color: isStudent ? Colors.white : Colors.black87, height: 1.4)),
            ),
            const SizedBox(height: 6),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Text(_formatMessageTime(message['timestamp'] ?? 0),
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
            ),
          ],
        ),
      ),
    );
  }
}
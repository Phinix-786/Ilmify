import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'teacher_info_location.dart';

class TeacherChatInfo extends StatefulWidget {
  final Map<String, dynamic> teacherData;

  const TeacherChatInfo({
    super.key,
    required this.teacherData,
  });

  @override
  State<TeacherChatInfo> createState() => _TeacherChatInfoState();
}

class _TeacherChatInfoState extends State<TeacherChatInfo> {
  final _dbRef = FirebaseDatabase.instance.ref();
  Map<String, dynamic>? _fullTeacherData;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadFullTeacherData();
  }

  Future<void> _loadFullTeacherData() async {
    try {
      final teacherEmailKey = widget.teacherData['teacherEmailKey'];
      final snapshot = await _dbRef.child('teachers').child(teacherEmailKey).get();

      if (snapshot.exists) {
        setState(() {
          _fullTeacherData = Map<String, dynamic>.from(snapshot.value as Map);
          _isLoading = false;
        });
      } else {
        setState(() => _isLoading = false);
      }
    } catch (e) {
      print('Error loading teacher data: $e');
      setState(() => _isLoading = false);
    }
  }

  void _viewLocation() {
    if (_fullTeacherData?['latitude'] != null && 
        _fullTeacherData?['longitude'] != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => TeacherInfoLocation(
            teacherName: _fullTeacherData?['fullName'] ?? 'Teacher',
            latitude: double.parse(_fullTeacherData!['latitude']),
            longitude: double.parse(_fullTeacherData!['longitude']),
          ),
        ),
      );
    }
  }

  String _getExperienceText() {
    final years = int.tryParse(_fullTeacherData?['experienceYears']?.toString() ?? '0') ?? 0;
    final months = int.tryParse(_fullTeacherData?['experienceMonths']?.toString() ?? '0') ?? 0;
    
    if (years == 0 && months == 0) return 'New to teaching';
    if (years == 0) return '$months month${months > 1 ? 's' : ''} of experience';
    if (months == 0) return '$years year${years > 1 ? 's' : ''} of experience';
    return '$years year${years > 1 ? 's' : ''} and $months month${months > 1 ? 's' : ''} of experience';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B4513),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Teacher Information',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        elevation: 0,
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF8B4513)),
            )
          : SingleChildScrollView(
              child: Column(
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(24),
                    decoration: const BoxDecoration(
                      color: Color(0xFF8B4513),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(30),
                        bottomRight: Radius.circular(30),
                      ),
                    ),
                    child: Column(
                      children: [
                        Container(
                          width: 100,
                          height: 100,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 3),
                          ),
                          child: ClipOval(
                            child: _fullTeacherData?['profileImageUrl'] != null &&
                                    _fullTeacherData!['profileImageUrl'].toString().isNotEmpty
                                ? Image.network(
                                    _fullTeacherData!['profileImageUrl'],
                                    fit: BoxFit.cover,
                                    loadingBuilder: (context, child, loadingProgress) {
                                      if (loadingProgress == null) return child;
                                      return Container(
                                        color: Colors.white,
                                        child: const Center(
                                          child: CircularProgressIndicator(
                                            color: Color(0xFF8B4513),
                                            strokeWidth: 2,
                                          ),
                                        ),
                                      );
                                    },
                                    errorBuilder: (context, error, stackTrace) {
                                      return Container(
                                        color: Colors.white,
                                        child: Center(
                                          child: Text(
                                            (_fullTeacherData?['fullName'] ?? 'T')[0].toUpperCase(),
                                            style: const TextStyle(
                                              color: Color(0xFF8B4513),
                                              fontWeight: FontWeight.bold,
                                              fontSize: 40,
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  )
                                : Container(
                                    color: Colors.white,
                                    child: Center(
                                      child: Text(
                                        (_fullTeacherData?['fullName'] ?? 'T')[0].toUpperCase(),
                                        style: const TextStyle(
                                          color: Color(0xFF8B4513),
                                          fontWeight: FontWeight.bold,
                                          fontSize: 40,
                                        ),
                                      ),
                                    ),
                                  ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          _fullTeacherData?['fullName'] ?? 'Teacher',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _getExperienceText(),
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.white70,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildInfoCard(
                          icon: Icons.person_outline,
                          title: 'Personal Information',
                          children: [
                            _buildInfoRow('Full Name', _fullTeacherData?['fullName']),
                            _buildInfoRow('Date of Birth', _fullTeacherData?['dateOfBirth']),
                            _buildInfoRow('City', _fullTeacherData?['city']),
                            _buildInfoRow('Phone', _fullTeacherData?['phoneNumber']),
                          ],
                        ),
                        const SizedBox(height: 16),
                        _buildInfoCard(
                          icon: Icons.menu_book_outlined,
                          title: 'Teaching Details',
                          children: [
                            _buildSubjectsRow('Subjects', _fullTeacherData?['subjects']),
                            const SizedBox(height: 12),
                            _buildDegreesRow('Qualifications', _fullTeacherData?['degrees']),
                          ],
                        ),
                        const SizedBox(height: 16),
                        _buildInfoCard(
                          icon: Icons.attach_money_outlined,
                          title: 'Pricing & Hours',
                          children: [
                            _buildInfoRow('Monthly Charge', 'Rs ${_fullTeacherData?['chargePerStudent']}/student'),
                            _buildInfoRow('Daily Hours', '${_fullTeacherData?['hoursPerDay']}h ${_fullTeacherData?['minutesPerDay']}m'),
                          ],
                        ),
                        const SizedBox(height: 16),
                        if (_fullTeacherData?['latitude'] != null &&
                            _fullTeacherData?['longitude'] != null)
                          InkWell(
                            onTap: _viewLocation,
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.05),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFFFF8E7),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: const Icon(
                                      Icons.location_on_outlined,
                                      color: Color(0xFF8B4513),
                                      size: 24,
                                    ),
                                  ),
                                  const SizedBox(width: 16),
                                  const Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'View Location',
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                            color: Color(0xFF8B4513),
                                          ),
                                        ),
                                        SizedBox(height: 4),
                                        Text(
                                          'See teacher\'s location on map',
                                          style: TextStyle(
                                            fontSize: 13,
                                            color: Colors.grey,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const Icon(
                                    Icons.arrow_forward_ios,
                                    size: 16,
                                    color: Colors.grey,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        const SizedBox(height: 24),
                      ],
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildInfoCard({
    required IconData icon,
    required String title,
    required List<Widget> children,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF8E7),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: const Color(0xFF8B4513), size: 20),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF8B4513),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...children,
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, dynamic value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value?.toString() ?? 'N/A',
              style: const TextStyle(
                fontSize: 14,
                color: Colors.black87,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSubjectsRow(String label, dynamic subjects) {
    final subjectList = subjects is List ? subjects : [];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey[600],
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: subjectList.map<Widget>((subject) {
            return Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF8E7),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.brown.shade300),
              ),
              child: Text(
                subject.toString(),
                style: const TextStyle(
                  fontSize: 12,
                  color: Color(0xFF8B4513),
                  fontWeight: FontWeight.w600,
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildDegreesRow(String label, dynamic degrees) {
    final degreeList = degrees is List ? degrees : [];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey[600],
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 8),
        ...degreeList.map<Widget>((degree) {
          return Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFFFFF8E7),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.brown.shade200),
            ),
            child: Row(
              children: [
                Icon(Icons.check_circle_outline, size: 16, color: Colors.brown.shade600),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    degree.toString(),
                    style: TextStyle(
                      fontSize: 13,
                      color: Colors.brown.shade700,
                    ),
                  ),
                ),
              ],
            ),
          );
        }),
      ],
    );
  }
}
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'student_teacher_chat_individual.dart';

class StudentChatList extends StatefulWidget {
  const StudentChatList({super.key});

  @override
  State<StudentChatList> createState() => _StudentChatListState();
}

class _StudentChatListState extends State<StudentChatList> {
  final _dbRef = FirebaseDatabase.instance.ref();
  String _studentEmailKey = '';

  @override
  void initState() {
    super.initState();
    _loadStudentData();
  }

  Future<void> _loadStudentData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final emailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');
      
      try {
        final snapshot = await _dbRef.child('students').child(emailKey).get();
        if (snapshot.exists) {
          setState(() {
            _studentEmailKey = emailKey;
          });
        }
      } catch (e) {
        print('Error loading student data: $e');
        setState(() {
          _studentEmailKey = emailKey;
        });
      }
    }
  }

  // Generate unique chat ID for student-teacher pair
  String _generateChatId(String studentKey, String teacherKey) {
    final keys = [studentKey, teacherKey]..sort();
    return '${keys[0]}_${keys[1]}';
  }

  // Delete teacher and all related data
  Future<void> _deleteTeacher(Map<String, dynamic> teacher) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.orange),
            SizedBox(width: 8),
            Text('Delete Teacher?'),
          ],
        ),
        content: Text(
          'Are you sure you want to delete ${teacher['teacherName']}?\n\n'
          'This will permanently delete:\n'
          '• All chat messages\n'
          '• Request history\n'
          '• Connection with this teacher\n\n'
          'You can send a new request later if needed.',
          style: const TextStyle(fontSize: 14),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text('Delete', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    try {
      // Show loading indicator
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const Center(
          child: Card(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(color: Color(0xFF8B4513)),
                  SizedBox(height: 16),
                  Text('Deleting...'),
                ],
              ),
            ),
          ),
        ),
      );

      final teacherEmailKey = teacher['teacherEmailKey'];
      
      // 1. Delete chat messages
      final chatId = _generateChatId(_studentEmailKey, teacherEmailKey);
      await _dbRef.child('chats').child(chatId).remove();

      // 2. Delete from studentRequests (received from teacher)
      final receivedSnapshot = await _dbRef
          .child('studentRequests')
          .child(_studentEmailKey)
          .get();
      
      if (receivedSnapshot.exists) {
        final data = Map<String, dynamic>.from(receivedSnapshot.value as Map);
        for (var entry in data.entries) {
          final request = Map<String, dynamic>.from(entry.value as Map);
          if (request['teacherEmailKey'] == teacherEmailKey) {
            await _dbRef
                .child('studentRequests')
                .child(_studentEmailKey)
                .child(entry.key)
                .remove();
          }
        }
      }

      // 3. Delete from studentSentRequests (sent to teacher)
      final sentSnapshot = await _dbRef
          .child('studentSentRequests')
          .child(_studentEmailKey)
          .get();
      
      if (sentSnapshot.exists) {
        final data = Map<String, dynamic>.from(sentSnapshot.value as Map);
        for (var entry in data.entries) {
          final request = Map<String, dynamic>.from(entry.value as Map);
          if (request['teacherEmailKey'] == teacherEmailKey) {
            await _dbRef
                .child('studentSentRequests')
                .child(_studentEmailKey)
                .child(entry.key)
                .remove();
          }
        }
      }

      // 4. Delete from teacherRequests (teacher's received requests)
      final teacherReceivedSnapshot = await _dbRef
          .child('teacherRequests')
          .child(teacherEmailKey)
          .get();
      
      if (teacherReceivedSnapshot.exists) {
        final data = Map<String, dynamic>.from(teacherReceivedSnapshot.value as Map);
        for (var entry in data.entries) {
          final request = Map<String, dynamic>.from(entry.value as Map);
          if (request['studentEmailKey'] == _studentEmailKey) {
            await _dbRef
                .child('teacherRequests')
                .child(teacherEmailKey)
                .child(entry.key)
                .remove();
          }
        }
      }

      // 5. Delete from teacherSentRequests (teacher's sent requests)
      final teacherSentSnapshot = await _dbRef
          .child('teacherSentRequests')
          .child(teacherEmailKey)
          .get();
      
      if (teacherSentSnapshot.exists) {
        final data = Map<String, dynamic>.from(teacherSentSnapshot.value as Map);
        for (var entry in data.entries) {
          final request = Map<String, dynamic>.from(entry.value as Map);
          if (request['studentEmailKey'] == _studentEmailKey) {
            await _dbRef
                .child('teacherSentRequests')
                .child(teacherEmailKey)
                .child(entry.key)
                .remove();
          }
        }
      }

      if (mounted) {
        Navigator.pop(context); // Close loading dialog
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${teacher['teacherName']} deleted successfully'),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context); // Close loading dialog
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error deleting teacher: ${e.toString()}'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    }
  }

  // Get all accepted teachers (both sent and received requests)
  Stream<List<Map<String, dynamic>>> _getAcceptedTeachersStream() {
    if (_studentEmailKey.isEmpty) {
      return Stream.value([]);
    }

    return Stream.value([]).asyncMap((_) async {
      final List<Map<String, dynamic>> acceptedTeachers = [];
      final Set<String> addedTeachers = {};

      try {
        // Get accepted requests from teachers (received by student)
        final receivedSnapshot = await _dbRef
            .child('studentRequests')
            .child(_studentEmailKey)
            .get();

        if (receivedSnapshot.exists) {
          final data = Map<String, dynamic>.from(receivedSnapshot.value as Map);
          for (var entry in data.entries) {
            final request = Map<String, dynamic>.from(entry.value as Map);
            if (request['status'] == 'accepted' && 
                !addedTeachers.contains(request['teacherEmailKey'])) {
              
              // Load teacher profile image from teachers database
              String? profileImageUrl;
              try {
                final teacherSnapshot = await _dbRef
                    .child('teachers')
                    .child(request['teacherEmailKey'])
                    .child('profileImageUrl')
                    .get();
                
                if (teacherSnapshot.exists) {
                  profileImageUrl = teacherSnapshot.value?.toString();
                }
              } catch (e) {
                print('Error loading profile image: $e');
              }

              acceptedTeachers.add({
                'teacherName': request['teacherName'],
                'teacherEmail': request['teacherEmail'],
                'teacherEmailKey': request['teacherEmailKey'],
                'teacherExperience': request['teacherExperience'],
                'teacherProfileImage': profileImageUrl ?? request['teacherProfileImage'],
              });
              addedTeachers.add(request['teacherEmailKey']);
            }
          }
        }

        // Get accepted requests sent to teachers (sent by student)
        final sentSnapshot = await _dbRef
            .child('studentSentRequests')
            .child(_studentEmailKey)
            .get();

        if (sentSnapshot.exists) {
          final data = Map<String, dynamic>.from(sentSnapshot.value as Map);
          for (var entry in data.entries) {
            final request = Map<String, dynamic>.from(entry.value as Map);
            if (request['status'] == 'accepted' && 
                !addedTeachers.contains(request['teacherEmailKey'])) {
              
              // Load teacher profile image from teachers database
              String? profileImageUrl;
              try {
                final teacherSnapshot = await _dbRef
                    .child('teachers')
                    .child(request['teacherEmailKey'])
                    .child('profileImageUrl')
                    .get();
                
                if (teacherSnapshot.exists) {
                  profileImageUrl = teacherSnapshot.value?.toString();
                }
              } catch (e) {
                print('Error loading profile image: $e');
              }

              acceptedTeachers.add({
                'teacherName': request['teacherName'],
                'teacherEmail': request['teacherEmail'],
                'teacherEmailKey': request['teacherEmailKey'],
                'teacherExperience': request['teacherExperience'],
                'teacherProfileImage': profileImageUrl ?? request['teacherProfileImage'],
              });
              addedTeachers.add(request['teacherEmailKey']);
            }
          }
        }

        // Sort by teacher name
        acceptedTeachers.sort((a, b) => 
          (a['teacherName'] ?? '').compareTo(b['teacherName'] ?? ''));
      } catch (e) {
        print('Error fetching accepted teachers: $e');
      }

      return acceptedTeachers;
    }).asBroadcastStream();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B4513),
        automaticallyImplyLeading: false,
        title: const Text(
          'Messages',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        elevation: 0,
        centerTitle: true,
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: _getAcceptedTeachersStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(color: Color(0xFF8B4513)),
            );
          }

          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Text(
                  'Error loading teachers',
                  style: TextStyle(color: Colors.red.shade700),
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }

          final teachers = snapshot.data ?? [];

          if (teachers.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(40),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(32),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.brown.shade200.withOpacity(0.3),
                            blurRadius: 20,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.contacts_outlined,
                        size: 80,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 32),
                    const Text(
                      'No Teachers Yet',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Accept teacher requests to start chatting',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.brown.shade600,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }

          return ListView.builder(
            itemCount: teachers.length,
            itemBuilder: (context, index) {
              final teacher = teachers[index];
              return InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => StudentTeacherChatIndividual(
                        teacherData: teacher,
                      ),
                    ),
                  );
                },
                onLongPress: () => _deleteTeacher(teacher),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border(
                      bottom: BorderSide(
                        color: Colors.grey.shade200,
                        width: 1,
                      ),
                    ),
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  child: Row(
                    children: [
                      // Profile Picture
                      Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: const Color(0xFF8B4513).withOpacity(0.2),
                            width: 2,
                          ),
                        ),
                        child: ClipOval(
                          child: teacher['teacherProfileImage'] != null &&
                                  teacher['teacherProfileImage'].toString().isNotEmpty
                              ? Image.network(
                                  teacher['teacherProfileImage'],
                                  fit: BoxFit.cover,
                                  width: 56,
                                  height: 56,
                                  loadingBuilder: (context, child, loadingProgress) {
                                    if (loadingProgress == null) return child;
                                    return Container(
                                      color: const Color(0xFF8B4513),
                                      child: const Center(
                                        child: CircularProgressIndicator(
                                          color: Colors.white,
                                          strokeWidth: 2,
                                        ),
                                      ),
                                    );
                                  },
                                  errorBuilder: (context, error, stackTrace) {
                                    return Container(
                                      color: const Color(0xFF8B4513),
                                      child: Center(
                                        child: Text(
                                          (teacher['teacherName'] ?? 'T')[0].toUpperCase(),
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 24,
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                )
                              : Container(
                                  color: const Color(0xFF8B4513),
                                  child: Center(
                                    child: Text(
                                      (teacher['teacherName'] ?? 'T')[0].toUpperCase(),
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 24,
                                      ),
                                    ),
                                  ),
                                ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              teacher['teacherName'] ?? 'Unknown',
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Colors.black87,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              teacher['teacherExperience'] ?? '',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey.shade600,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      Icon(
                        Icons.chevron_right,
                        color: Colors.grey.shade400,
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'student_teacher_info.dart';

class TeachersListStudent extends StatefulWidget {
  const TeachersListStudent({super.key});

  @override
  State<TeachersListStudent> createState() => _TeachersListStudentState();
}

class _TeachersListStudentState extends State<TeachersListStudent> {
  final _dbRef = FirebaseDatabase.instance.ref();
  String _studentCity = '';
  // ignore: unused_field
  String _studentEmailKey = '';
  bool _isLoading = true;
  Set<String> _requestedTeacherKeys = {};

  @override
  void initState() {
    super.initState();
    _loadStudentData();
    _listenToSentRequests();
  }

  Future<void> _loadStudentData() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final emailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');
      setState(() => _studentEmailKey = emailKey);

      final snapshot = await _dbRef.child('students').child(emailKey).child('city').get();

      if (snapshot.exists) {
        setState(() {
          _studentCity = snapshot.value.toString();
          _isLoading = false;
        });
      } else {
        setState(() => _isLoading = false);
      }
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  void _listenToSentRequests() {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final emailKey = user.email!.replaceAll('.', '_').replaceAll('@', '_at_');
    
    // Listen to student's sent requests
    _dbRef
        .child('studentSentRequests')
        .child(emailKey)
        .onValue
        .listen((event) {
      if (mounted) {
        final Set<String> teacherKeys = {};
        
        if (event.snapshot.value != null) {
          final data = Map<String, dynamic>.from(event.snapshot.value as Map);
          
          data.forEach((key, value) {
            final request = Map<String, dynamic>.from(value as Map);
            final status = request['status'] ?? '';
            
            // Filter out teachers with pending or accepted requests
            if (status == 'pending' || status == 'accepted') {
              teacherKeys.add(request['teacherEmailKey']);
            }
          });
        }
        
        setState(() => _requestedTeacherKeys = teacherKeys);
      }
    });
  }

  Stream<List<Map<String, dynamic>>> _getTeachersStream() {
    return _dbRef.child('teachers').onValue.asBroadcastStream().map((event) {
      final List<Map<String, dynamic>> teachers = [];
      
      if (event.snapshot.value != null) {
        final data = Map<String, dynamic>.from(event.snapshot.value as Map);
        
        data.forEach((key, value) {
          final teacherData = Map<String, dynamic>.from(value as Map);
          final teacherCity = teacherData['city'] ?? '';
          
          // Only show teachers from the same city AND who don't have pending/accepted requests
          if (teacherCity == _studentCity && !_requestedTeacherKeys.contains(key)) {
            teachers.add({
              'key': key,
              ...teacherData,
            });
          }
        });
      }
      
      return teachers;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        backgroundColor: Color(0xFFFFF8E7),
        body: Center(
          child: CircularProgressIndicator(
            color: Color(0xFF8B4513),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B4513),
        automaticallyImplyLeading: false,
        title: const Text(
          'Find Teachers',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        elevation: 0,
        centerTitle: true,
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: _getTeachersStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(
                color: Color(0xFF8B4513),
              ),
            );
          }

          if (snapshot.hasError) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(
                    Icons.error_outline,
                    size: 64,
                    color: Colors.red,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Error loading teachers',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.brown.shade600,
                    ),
                  ),
                ],
              ),
            );
          }

          final teachers = snapshot.data ?? [];

          if (teachers.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(40),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(32),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.brown.shade200.withOpacity(0.3),
                            blurRadius: 20,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.person_search_rounded,
                        size: 80,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 32),
                    const Text(
                      'No Teachers Available',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      _requestedTeacherKeys.isEmpty
                          ? 'There are no teachers available in $_studentCity yet.\nCheck back later!'
                          : 'No new teachers available.\nYou\'ve already sent requests to all teachers in $_studentCity.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.brown.shade600,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: teachers.length,
            itemBuilder: (context, index) {
              final teacher = teachers[index];
              final subjects = List<String>.from(teacher['subjects'] ?? []);
              final profileImageUrl = teacher['profileImageUrl'];
              
              return Card(
                margin: const EdgeInsets.only(bottom: 16),
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => StudentTeacherInfo(
                          teacherData: teacher,
                        ),
                      ),
                    );
                  },
                  borderRadius: BorderRadius.circular(16),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        // Profile Picture
                        Container(
                          width: 60,
                          height: 60,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: const Color(0xFFFFF8E7),
                            border: Border.all(
                              color: const Color(0xFF8B4513),
                              width: 2,
                            ),
                          ),
                          child: ClipOval(
                            child: profileImageUrl != null
                                ? Image.network(
                                    profileImageUrl,
                                    fit: BoxFit.cover,
                                    width: 60,
                                    height: 60,
                                    errorBuilder: (context, error, stackTrace) {
                                      return const Icon(
                                        Icons.person,
                                        size: 32,
                                        color: Color(0xFF8B4513),
                                      );
                                    },
                                  )
                                : const Icon(
                                    Icons.person,
                                    size: 32,
                                    color: Color(0xFF8B4513),
                                  ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        
                        // Teacher Info
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Teacher Name
                              Text(
                                teacher['fullName'] ?? 'Unknown',
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFF8B4513),
                                ),
                              ),
                              const SizedBox(height: 8),
                              
                              // Subjects
                              Wrap(
                                spacing: 6,
                                runSpacing: 6,
                                children: subjects.take(2).map((subject) {
                                  return Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 5,
                                    ),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFFFF8E7),
                                      borderRadius: BorderRadius.circular(6),
                                      border: Border.all(
                                        color: Colors.brown.shade300,
                                      ),
                                    ),
                                    child: Text(
                                      subject,
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.brown.shade700,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  );
                                }).toList()
                                  ..addAll(subjects.length > 2
                                      ? [
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 10,
                                              vertical: 5,
                                            ),
                                            decoration: BoxDecoration(
                                              color: const Color(0xFFFFF8E7),
                                              borderRadius: BorderRadius.circular(6),
                                              border: Border.all(
                                                color: Colors.brown.shade300,
                                              ),
                                            ),
                                            child: Text(
                                              '+${subjects.length - 2}',
                                              style: TextStyle(
                                                fontSize: 12,
                                                fontWeight: FontWeight.bold,
                                                color: Colors.brown.shade700,
                                              ),
                                            ),
                                          ),
                                        ]
                                      : []),
                              ),
                            ],
                          ),
                        ),
                        
                        // Arrow Icon
                        const Icon(
                          Icons.arrow_forward_ios,
                          size: 18,
                          color: Color(0xFF8B4513),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
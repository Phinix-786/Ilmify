import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:io';
import 'screens/start_screen.dart';
import 'screens/splash_screen.dart';
import 'screens/home/student/home_student.dart';
import 'screens/home/teacher/home_teacher.dart';
import 'screens/notification_service.dart';

const _kOneSignalAppId = 'your-onesignal-app-id'; // Dashboard → Settings → Keys & IDs

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 1. Firebase first — FCM must be ready before OneSignal
  await Firebase.initializeApp();

  // 2. OneSignal init — ONCE here, never again anywhere else in the app
  OneSignal.initialize(_kOneSignalAppId);

  // 3. Battery optimization — required for killed-app delivery on Android 10
  //    and OEM skins (MIUI, ColorOS, OneUI). Permission is in AndroidManifest.
  await _requestBatteryOptimizationExemption();

  // 4. Notification permission — do NOT await on Android (blocks startup)
  OneSignal.Notifications.requestPermission(true);

  // 5. Show notifications while app is open
  OneSignal.Notifications.addForegroundWillDisplayListener((event) {
    event.notification.display();
  });

  // 6. Handle notification taps
  OneSignal.Notifications.addClickListener(NotificationService.handleClick);

  // 7. If already signed in (app restart), re-link token immediately
  //    before any screen loads — this is the key fix for restart sessions
  await NotificationService.linkUser();

  runApp(const MyApp());
}

Future<void> _requestBatteryOptimizationExemption() async {
  try {
    final status = await Permission.ignoreBatteryOptimizations.status;
    if (!status.isGranted) {
      await Permission.ignoreBatteryOptimizations.request();
    }
  } catch (_) {}
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ilmify',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFF8B4513),
        scaffoldBackgroundColor: const Color(0xFFFFF8E7),
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF8B4513),
          primary: const Color(0xFF8B4513),
          secondary: const Color(0xFFFFE4B5),
        ),
        useMaterial3: true,
      ),
      home: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const SplashScreen();
          }
          if (snapshot.hasData && snapshot.data != null) {
            return const AuthChecker();
          }
          return const StartScreen();
        },
      ),
    );
  }
}

class AuthChecker extends StatefulWidget {
  const AuthChecker({Key? key}) : super(key: key);

  @override
  State<AuthChecker> createState() => _AuthCheckerState();
}

class _AuthCheckerState extends State<AuthChecker> {
  @override
  void initState() {
    super.initState();
    _checkUserProfile();
  }

  Future<void> _checkUserProfile() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        if (mounted) {
          Navigator.pushReplacement(context,
              MaterialPageRoute(builder: (_) => const StartScreen()));
        }
        return;
      }

      final emailKey =
          user.email!.replaceAll('.', '_').replaceAll('@', '_at_');
      final dbRef = FirebaseDatabase.instance.ref();

      final studentSnapshot =
          await dbRef.child('students').child(emailKey).get();

      if (studentSnapshot.exists) {
        // Link token for this student session
        await NotificationService.linkUser();
        if (mounted) {
          Navigator.pushReplacement(context,
              MaterialPageRoute(builder: (_) => const HomeStudent()));
        }
        return;
      }

      final teacherSnapshot =
          await dbRef.child('teachers').child(emailKey).get();

      if (teacherSnapshot.exists) {
        // Link token for this teacher session
        await NotificationService.linkUser();
        if (mounted) {
          Navigator.pushReplacement(context,
              MaterialPageRoute(builder: (_) => const HomeTeacher()));
        }
        return;
      }

      if (mounted) {
        Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (_) => const StartScreen()));
      }
    } catch (e) {
      if (mounted) {
        Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (_) => const StartScreen()));
      }
    }
  }

  @override
  Widget build(BuildContext context) => const SplashScreen();
}